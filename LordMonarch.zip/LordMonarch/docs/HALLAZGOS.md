# Lord Monarch (Mega Drive) — traducción al castellano

## ROMs
- `roms/Lord Monarch (Japan).md`          — 2 MB, original japonesa. MD5 5e06d2de451ecc57a9a91577bb0dc59c
- `roms/Lord Monarch (English v1.0).md`   — 2 MB, traducción inglesa (referencia). MD5 a6a2118f2cf771ac358de37751e22911
- `roms/Lord Monarch (Espanol).md`        — 2 MB, nuestro trabajo previo. MD5 d3c9869e113ee9bdc45116a5aecf3c8f

## Hechos clave (medidos)
1. La ROM "Español" difiere de la **inglesa** en solo 8.310 bytes (1.066 rangos),
   pero de la **japonesa** en ~978 KB. => **Nuestro trabajo anterior partió de la
   ROM inglesa**, no de la japonesa.
2. El texto del juego es **ASCII plano + códigos de control, terminado en 0x00**.
3. Texto de menú en ancho FIJO rellenado con espacios (por eso "Status"->"Estad").
4. Cabecera MD: "SEGA MEGA DRIVE (C)SEGA 1994.APR", checksum 0x0000.

## LA FUENTE (encontrada)
- **Glifos**: en `0x19AEC0`. Formato **2bpp Mega Drive** (4 bytes/fila: plano0 word
  BE + plano1 word BE; bit 15 = pixel izquierdo). **32 bytes por glifo** (8×8).
- **96 glifos** = ASCII 0x20–0x7F. **índice = byte − 0x20** (las rutinas hacen
  `subi #32`).
- **Tabla de anchos** (fuente PROPORCIONAL): en `0x19ADC0`, 256 bytes.
  índice→ancho en px. Índices 0–95 = 4–9 px; 96–127 = "1"; 128–255 = "0".
- **Espacio libre** tras la fuente: 1.027 bytes a cero desde `0x19BAC0`
  (~32 glifos posibles en índices 96–127). Suficiente para los acentos.

### Rutinas de texto (0x1DE…)
- `0x1DE402`  dibuja UN glifo (d3 = índice). `lea 0x19aec0` + `lslw #5` (×32).
- `0x1DE9CE`  dibuja string: `moveb a0@+,d3` → `subib #32` → `bsr 0x1de402`.
- `0x1DEA1C`  dibuja string con wrap (igual: `subib #32`).
- `0x1DE974`  calcula ANCHO del string: `subiw #32` + suma anchos de 0x19adc0.
- `0x1DE996`  setup: `a1 = 0x1DE402`, a2 = 0xb38.
- `0x215E`    dibuja dígitos (UI): `subib #48`, fuente en 0x19aec0.
- Conversión **byte − 0x20** repetida en 0x1DE9DA / 0x1DEA2E / 0x1DE986.

## Plan para acentos (diseñado)
Como la conversión es `índice = byte − 0x20`, los bytes **0x80–0x8F** caen
automáticamente en índices 96–111. Basta con:
1. Dibujar 16 glifos acentuados en índices 96–111 (en 0x19BAC0+).
2. Poner sus anchos en 0x19ADC0[96..111].
3. Usar bytes 0x80–0x8F en el texto (sin tocar el código).

Asignación códigos→carácter (byte → índice = byte−0x20):
```
0x81 á  0x82 é  0x83 í  0x84 ó  0x85 ú  0x86 ñ  0x87 Ñ  0x88 ü
0x89 Ü  0x8A ¡  0x8B ¿  0x8C Á  0x8D É  0x8E Í  0x8F Ó  0x90 Ú
```
⚠️ El índice **96 está RESERVADO**: es el glifo de relleno que usan 0x1de364 y
0x1de388 (movew #96,d3 + bsr 0x1de402) para rellenar el final de línea. Por eso
los acentos empiezan en el byte 0x81 (índice 97), nunca en 0x80.

✅ VERIFICADO: la rutina `0x1DE660` (hook de dibujo de string del diálogo, añadida
por la traducción inglesa sobre la ROM japonesa) lee byte a byte y:
- `0x00` → fin de string
- `0x01` → rellenar hasta fin de línea (bsr 0x1de364)
- `0x06` → insertar número (bsr 0x1de3aa)
- `0x09` → comando especial (jsr 0x1ee0)
- **cualquier otro byte** → `subib #32` y dibuja glifo (bsr 0x1de402)

→ los bytes 0x80–0x8F se dibujan como glifos 96–111. **El sistema ya soporta
acentos**: basta con los glifos + anchos + usar esos bytes en el texto.

Los códigos de control del bytecode (0x03,0x04,0x05,0x08,0x11,0x12…) los procesa
el INTÉRPRETE antes de pasar el texto a 0x1DE660; no colisionan con 0x80+.

## Estructura de diálogo (script)
Prefijo `04 01 05 08 XX` (XX = nº de diálogo), luego texto ASCII, terminador
`11 03`, fin `00`. Nombres de personaje null-terminated en 0x31920–0x31A2F.

## Cajas de texto (cómo ampliarlas)
El ancho de cada caja está codificado en la rutina de texto como un límite de
columnas: `cmpib #N, 0xffffce9d` (contador de columna en 0xffffce9d, incrementado
con `addiw #257,0xffffce9c`). Cuando llega a N, hace wrap (jsr 0x200 = siguiente
línea).

- `0x1DEA1C` — texto normal: `cmpib #8,0xffffce9d` → caja de **8 tiles (64 px)**.
- `0x1DEA78` — texto estrecho: `cmpib #4,0xffffce9d` → caja de **4 tiles (32 px)**.
- `0x1DE660` / `0x1D98` — sin wrap automático (el motor controla los saltos con
  el código 0x01 = `addw d5,d1` interlineado + `jsr 0xb38`).

Para ampliar una caja hay que (a) subir ese `#N` y (b) ampliar el FONDO de la
caja (tiles de fondo, dibujados aparte — pendiente de localizar).

## Tareas
1. [x] Dibujar glifos acentuados (script `tools/build_font.py`).
2. [x] Verificar tratamiento de bytes ≥0x80 por el intérprete (0x1de660).
3. [ ] Ampliar cajas: localizar el fondo de cada caja y subir `#N`.
4. [ ] Mejorar la traducción existente (aplicar acentos al texto).

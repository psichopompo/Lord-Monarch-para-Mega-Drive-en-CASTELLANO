"""dis68k.py — desensamblador 68000 (subconjunto amplio, corregido).

Uso: python3 dis68k.py rom.bin <offset_hex> <n_bytes> [base_hex]
base_hex = dirección lógica a la que se mapea el offset 0 del fichero.
Si se omite, se asume 0 (pc = offset).
"""
import sys

CCS = ['RA','SR','HI','LS','CC','CS','NE','EQ','VC','VS','PL','MI','GE','LT','GT','LE']

def ea(data, pc, m, r):
    """Devuelve (texto, tamaño_extra)."""
    if m == 0: return f"D{r}", 0
    if m == 1: return f"A{r}", 0
    if m == 2: return f"(A{r})", 0
    if m == 3: return f"(A{r})+", 0
    if m == 4: return f"-(A{r})", 0
    if m == 5:
        d = int.from_bytes(data[pc:pc+2],'big',signed=True)
        return f"${d:04X}(A{r})", 2
    if m == 6:
        d = int.from_bytes(data[pc:pc+2],'big',signed=True)
        ex = int.from_bytes(data[pc+2:pc+4],'big')
        ir=(ex>>12)&7; irs='A' if (ex>>15)&1 else 'D'
        return f"${d:04X}(A{r},{irs}{ir})", 4
    if m == 7:
        if r == 0:
            d=int.from_bytes(data[pc:pc+2],'big',signed=True)
            return f"(${d:04X}).W", 2
        if r == 1:
            d=int.from_bytes(data[pc:pc+4],'big')
            return f"(${d:08X}).L", 4
        if r == 2:
            d=int.from_bytes(data[pc:pc+2],'big',signed=True)
            return f"(${pc+2+d:06X})", 2
        if r == 3:
            d=int.from_bytes(data[pc:pc+2],'big',signed=True)
            return f"(${pc+2+d:06X},X)", 2
        if r == 4:
            d=int.from_bytes(data[pc:pc+2],'big',signed=True)
            return f"#${d:04X}", 2
    return f"??{m},{r}", 0

def dis(data, offset, n, base=0):
    out = []
    end = offset + n
    while offset < end and offset + 1 < len(data):
        pc = base + offset
        w = int.from_bytes(data[offset:offset+2],'big')
        text = f"dc.w ${w:04X}"; size = 2
        op = (w>>12)&0xF

        # MOVE.B / MOVE.L / MOVE.W  (dest: mode 8-6, reg 11-9 ; src: mode 5-3, reg 2-0)
        if op in (0x1, 0x2, 0x3):
            sizes = {0x1:'.B', 0x2:'.L', 0x3:'.W'}
            dm=(w>>6)&7; dr=(w>>9)&7
            sm=(w>>3)&7; sr=w&7
            st, ss = ea(data, offset+2, sm, sr)
            dt, ds = ea(data, offset+2, dm, dr)
            text = f"MOVE{sizes[op]} {st},{dt}"; size = 2+ss+ds

        elif op == 0x0:
            # ORI/ANDI/SUBI/ADDI/CMPI/EORI a EA
            if (w & 0xFF00) == 0x0000:
                imm=int.from_bytes(data[offset+2:offset+4],'big')
                dt,ds=ea(data,offset+4,dm if False else (w>>3)&7, w&7)
                # para op=0, el EA es bits 0-5, immediate word sigue
                dt,ds=ea(data,offset+4,(w>>3)&7,w&7)
                text=f"ORI.W #${imm:04X},{dt}"; size=2+2+ds
            elif (w & 0xFF00) == 0x0200:
                imm=int.from_bytes(data[offset+2:offset+4],'big')
                dt,ds=ea(data,offset+4,(w>>3)&7,w&7)
                text=f"ANDI.W #${imm:04X},{dt}"; size=4+ds
            elif (w & 0xFF00) == 0x0C00:
                imm=int.from_bytes(data[offset+2:offset+4],'big')
                dt,ds=ea(data,offset+4,(w>>3)&7,w&7)
                text=f"CMPI.W #${imm:04X},{dt}"; size=4+ds
            else:
                text=f"dc.w ${w:04X}"

        elif op == 0x4:
            if (w & 0xFFC0) == 0x4200: dt,ds=ea(data,offset+2,(w>>3)&7,w&7); text=f"CLR.B {dt}"; size=2+ds
            elif (w & 0xFFC0) == 0x4240: dt,ds=ea(data,offset+2,(w>>3)&7,w&7); text=f"CLR.W {dt}"; size=2+ds
            elif (w & 0xFFC0) == 0x4280: dt,ds=ea(data,offset+2,(w>>3)&7,w&7); text=f"CLR.L {dt}"; size=2+ds
            elif (w & 0xFFC0) == 0x4A00: dt,ds=ea(data,offset+2,(w>>3)&7,w&7); text=f"TST.B {dt}"; size=2+ds
            elif (w & 0xFFC0) == 0x4A40: dt,ds=ea(data,offset+2,(w>>3)&7,w&7); text=f"TST.W {dt}"; size=2+ds
            elif (w & 0xFFC0) == 0x4A80: dt,ds=ea(data,offset+2,(w>>3)&7,w&7); text=f"TST.L {dt}"; size=2+ds
            elif w == 0x4E75: text="RTS"
            elif w == 0x4E71: text="NOP"
            elif w == 0x4E73: text="RTE"
            elif w == 0x4E77: text="RTR"
            elif w == 0x4E70: text="RESET"
            elif w == 0x4E76: text="TRAPV"
            elif (w & 0xFFC0) == 0x4E80: text=f"JSR (A{w&7})"
            elif (w & 0xFFC0) == 0x4EC0: text=f"JMP (A{w&7})"
            elif w == 0x4EB8: d=int.from_bytes(data[offset+2:offset+4],'big'); text=f"JSR (${d:06X}).W"; size=4
            elif w == 0x4EB9: d=int.from_bytes(data[offset+2:offset+6],'big'); text=f"JSR (${d:08X}).L"; size=6
            elif w == 0x4EF8: d=int.from_bytes(data[offset+2:offset+4],'big'); text=f"JMP (${d:06X}).W"; size=4
            elif w == 0x4EF9: d=int.from_bytes(data[offset+2:offset+6],'big'); text=f"JMP (${d:08X}).L"; size=6
            elif (w & 0xFFF8) == 0x4E50: text=f"LINK A{w&7},#"
            elif (w & 0xFFF8) == 0x4E58: text=f"UNLK A{w&7}"
            elif (w & 0xFFC0) == 0x4840: text=f"SWAP D{w&7}"
            elif (w & 0xFFC0) == 0x4880: text=f"EXT.W D{w&7}"
            elif (w & 0xFFC0) == 0x48C0: text=f"EXT.L D{w&7}"
            elif (w & 0xFFC0) == 0x46C0: text=f"MOVE.W SR,D{w&7}"
            elif (w & 0xFFC0) == 0x44C0: text=f"MOVE.W CCR,{ea(data,offset+2,(w>>3)&7,w&7)[0]}"
            elif (w & 0xFFC0) == 0x40C0: text=f"MOVE.W SR,{ea(data,offset+2,(w>>3)&7,w&7)[0]}"
            elif (w & 0xFFF0) == 0x4E40: text=f"TRAP #{w&0xF}"
            elif (w & 0xFFC0) == 0x4A80: text=f"TST.L D{w&7}"
            else: text=f"dc.w ${w:04X}"

        elif op == 0x5:
            if (w & 0xF100) == 0x5000 or (w & 0xF100) == 0x5100:
                n=(w>>9)&7; v=(w>>3)&7; v=8 if v==0 else v
                szs={0:'.B',1:'.W',2:'.L'}
                o=('ADDQ' if (w>>8)&1==0 else 'SUBQ')
                dt,ds=ea(data,offset+2,(w>>3)&7,w&7)
                text=f"{o}{szs[(w>>7)&3]} #{v},{dt}"; size=2+ds
            elif (w & 0xFFC0) == 0x50C0:
                text=f"S{CCS[(w>>8)&0xF]} D{w&7}"
            elif (w & 0xFFC0) == 0x51C8:
                text=f"DBF D{w&7},..."  # aproximado
            else: text=f"dc.w ${w:04X}"

        elif op == 0x6:
            d=(w&0xFF); d=d-256 if d&0x80 else d
            if (w & 0xFF00) == 0x6100: text=f"BSR ${pc+2+d:06X}"
            elif (w & 0xFF00) == 0x6000: text=f"BRA ${pc+2+d:06X}"
            elif (w & 0xF000) == 0x6000: text=f"B{CCS[(w>>8)&0xF]} ${pc+2+d:06X}"
            else: text=f"dc.w ${w:04X}"

        elif op == 0x7:
            text=f"MOVEQ #${w&0xFF:02X},D{(w>>9)&7}"

        elif op == 0x8:
            # OR/SUB/CMP: <ea>,Dn  (AND también)
            if (w & 0xF000) == 0x8000 and (w>>6)&7 == 0: text=f"OR.B {ea(data,offset+2,(w>>3)&7,w&7)[0]},D{(w>>9)&7}"
            elif (w & 0xF000) == 0x8000: text=f"OR {ea(data,offset+2,(w>>3)&7,w&7)[0]},D{(w>>9)&7}"
            elif (w & 0xF000) == 0x9000: text=f"SUB {ea(data,offset+2,(w>>3)&7,w&7)[0]},D{(w>>9)&7}"
            elif (w & 0xF000) == 0xB000: text=f"CMP {ea(data,offset+2,(w>>3)&7,w&7)[0]},D{(w>>9)&7}"
            elif (w & 0xF000) == 0xC000: text=f"AND {ea(data,offset+2,(w>>3)&7,w&7)[0]},D{(w>>9)&7}"
            else: text=f"dc.w ${w:04X}"

        elif op == 0x9:
            # SUB Dn,<ea>
            text=f"dc.w ${w:04X}"

        elif op == 0xB:
            if (w & 0xF000) == 0xB000:
                text=f"CMP {ea(data,offset+2,(w>>3)&7,w&7)[0]},D{(w>>9)&7}"
            elif (w & 0xF000) == 0xE000:
                text=f"CMP {ea(data,offset+2,(w>>3)&7,w&7)[0]},A{(w>>9)&7}"
            else: text=f"dc.w ${w:04X}"

        elif op == 0xC:
            if (w & 0xFFC0) == 0xC1C0:
                pass
            text=f"dc.w ${w:04X}"

        elif op == 0xD:
            # ADD/SUB <ea>,Dn ; ADD Dn,<ea> etc
            if (w & 0xF000) == 0xD000: text=f"ADD {ea(data,offset+2,(w>>3)&7,w&7)[0]},D{(w>>9)&7}"
            else: text=f"dc.w ${w:04X}"

        elif op == 0xE:
            # shifts/rotates; ASL/ASR/LSL/LSR/ROL/ROR + IMM o Dn, reg
            if (w & 0xF000) == 0xE000:
                pass
            text=f"dc.w ${w:04X}"

        else:
            text=f"dc.w ${w:04X}"

        out.append((pc, size, text))
        offset += size
    return out

if __name__ == '__main__':
    rom = open(sys.argv[1],'rb').read()
    off = int(sys.argv[2],16)
    n = int(sys.argv[3],16)
    base = int(sys.argv[4],16) if len(sys.argv)>4 else 0
    for pc, size, s in dis(rom, off, n, base):
        print(f"{pc:06X}  {s}")

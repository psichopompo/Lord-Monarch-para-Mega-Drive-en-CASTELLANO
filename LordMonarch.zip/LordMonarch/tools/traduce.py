"""traduce.py — aplica tildes y signos ¡¿ al texto de Lord Monarch (MD).

La fuente (0x19AEC0) mapea byte -> glifo como índice = byte - 0x20. Añadimos
glifos acentuados en índices 97-112, mapeados a bytes 0x81-0x90 (ver
build_font.py). Aquí convertimos el texto traducido para usar esos bytes.

Uso: python3 traduce.py <rom_in> <rom_out>
"""
import sys

# byte -> carácter acentuado
AC = {'á':0x81,'é':0x82,'í':0x83,'ó':0x84,'ú':0x85,'ñ':0x86,'Ñ':0x87,
      'ü':0x88,'Ü':0x89,'¡':0x8A,'¿':0x8B,'Á':0x8C,'É':0x8D,'Í':0x8E,
      'Ó':0x8F,'Ú':0x90}

def enc(s):
    """Codifica un string (con tildes) a bytes del juego."""
    out = bytearray()
    for ch in s:
        out.append(AC.get(ch, ord(ch)))
    return bytes(out)

# Reemplazos: (subcadena_original_ascii, subcadena_con_tildes)
# SOLO tildes (misma longitud). Las subcadenas incluyen contexto para ser únicas.
REPLACES = [
    # diálogo de apertura
    ("A ver... Que hacemos?", "A ver... Qué hacemos?"),
    ("Comportese, joven amo", "Compórtese, joven amo"),
    ("amo! Esta", "amo! Está"),
    ("ante Su Majestad", "ante Su Majestad"),
    ("No aceptaria a un debilucho", "No aceptaría a un débilucho"),
    ("principe de Monarch", "príncipe de Monarch"),
    ("te echare del reino", "te echaré del reino"),
    ("Cuando tenia tu edad", "Cuando tenía tu edad"),
    ("el joven mas guapo", "el joven más guapo"),
    ("paises vecinos", "países vecinos"),
    ("Tienes 160 dias", "Tienes 160 días"),
    ("Usalos bien", "Úsalos bien"),
    ("Si, si. Vencere", "Sí, sí. Venceré"),
    ("volvere antes", "volveré antes"),
    ("Si, Majestad! Puede", "Sí, Majestad! Puede"),
    ("Daria mi vida", "Daría mi vida"),
    ("Esperameeeeee", "Espérameeeeee"),  # Espéra + m + 6 e's (misma longitud)
    ("Por que no me muestra", "Por qué no me muestra"),
    ("monstruos de aqui", "monstruos de aquí"),
    ("Luchare contra otros", "Lucharé contra otros"),
    ("preparacion es peligrosa", "preparación es peligrosa"),
    ("ya vera.", "ya verá."),
    ("vencere a los bandidos", "venceré a los bandidos"),
    ("Que te pasa, viejo", "Qué te pasa, viejo"),
    ("formal para ser tu.", "formal para ser tú."),
    ("Que pasa con nuestras", "Qué pasa con nuestras"),
    ("hijo, si? ", "hijo, ¿sí?"),   # ¿ delante de sí + tilde (misma longitud)
]

# Signos de apertura ¡ ¿ : se añade el signo al inicio y se quita UN espacio
# del relleno final (buscar = "texto " con 1 espacio; reemplazar = "signo"+"texto").
# Formato: (texto_sin_signo, signo)
BANG = [
    ("A ver... Qué hacemos?", "¿"),
    ("Qué te pasa, viejo?", "¿"),
    ("Compórtese, joven amo!", "¡"),
    ("P-P-Por favor, Majestad!", "¡"),
    ("Qué pasa con nuestras", "¿"),
    ("Espérameeeeee!", "¡"),
    ("Comencemos!", "¡"),
    ("Por qué no me muestra", "¿"),
]

def apply(rom):
    data = bytearray(rom)
    for orig, nuevo in REPLACES:
        b_orig = orig.encode('ascii')
        b_nuevo = enc(nuevo)
        assert len(b_orig) == len(b_nuevo), f"longitud distinta: {orig!r}"
        idx = data.find(b_orig)
        if idx < 0:
            print(f"  ¡NO ENCONTRADO! {orig!r}")
            continue
        idx2 = data.find(b_orig, idx+1)
        if idx2 >= 0:
            print(f"  ¡MÚLTIPLES! {orig!r} en {idx:06X} y {idx2:06X}")
            continue
        data[idx:idx+len(b_orig)] = b_nuevo
        print(f"  OK {idx:06X}: {orig!r} -> {nuevo!r}")
    # fase ¡¿ : "texto " -> "signo"+"texto" (misma longitud total)
    for texto, signo in BANG:
        b_texto = enc(texto)          # ya con tildes
        b_buscar = b_texto + b' '      # + 1 espacio del relleno
        b_reem = enc(signo) + b_texto
        assert len(b_buscar) == len(b_reem)
        idx = data.find(b_buscar)
        if idx < 0:
            print(f"  ¡NO ENCONTRADO (¡¿)! {texto!r}")
            continue
        idx2 = data.find(b_buscar, idx+1)
        if idx2 >= 0:
            print(f"  ¡MÚLTIPLES (¡¿)! {texto!r}")
            continue
        data[idx:idx+len(b_buscar)] = b_reem
        print(f"  OK {idx:06X}: {signo}{texto!r}")
    return bytes(data)

if __name__ == '__main__':
    rom = open(sys.argv[1], 'rb').read()
    out = apply(rom)
    open(sys.argv[2], 'wb').write(out)
    print(f"escrito {sys.argv[2]}")

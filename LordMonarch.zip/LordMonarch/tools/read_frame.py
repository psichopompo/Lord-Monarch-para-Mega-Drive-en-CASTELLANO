"""read_frame.py — "lee" el texto de un frame del emulador comparando contra la fuente.

Uso: python3 read_frame.py frame.png rom.md [y0]

Sin visión, la forma de "ver" el texto renderizado es comparar píxel a píxel
el frame del emulador contra los glifos de la fuente (0x19AEC0, 2bpp, índice=
byte-0x20). Reconstruye el texto ASCII que aparece en pantalla.

Funciona con texto de 1 color (binariza por el color claro del texto) y para
los glifos base (sin antialias fino). Para los acentos (glifos 97+), usa el
mismo índice = byte - 0x20 con bytes 0x81-0x90.
"""
import sys
from PIL import Image

FONT = 0x19AEC0
WIDTH = 0x19ADC0

# byte -> carácter (para reconstruir texto)
CHAR = {i+0x20: chr(i+0x20) for i in range(0, 96)}  # 0x20-0x7F
ACC = {0x81:'á',0x82:'é',0x83:'í',0x84:'ó',0x85:'ú',0x86:'ñ',0x87:'Ñ',
       0x88:'ü',0x89:'Ü',0x8A:'¡',0x8B:'¿',0x8C:'Á',0x8D:'É',0x8E:'Í',
       0x8F:'Ó',0x90:'Ú'}
CHAR.update(ACC)

def load_font(rom):
    """Devuelve dict byte -> matriz 8x8 de bits (1 = pixel)."""
    glyphs = {}
    for code in range(0x20, 0x100):
        idx = code - 0x20
        if idx > 111:  # solo tenemos glifos hasta 112
            break
        off = FONT + idx*32
        m = [[0]*8 for _ in range(8)]
        for r in range(8):
            w0 = rom[off+r*4]<<8 | rom[off+r*4+1]
            w1 = rom[off+r*4+2]<<8 | rom[off+r*4+3]
            for c in range(8):
                p0 = (w0>>(15-c))&1
                p1 = (w1>>(15-c))&1
                m[r][c] = 1 if (p1|p0) else 0
        if any(any(row) for row in m):  # saltar glifos vacíos (evita falsos positivos)
            glyphs[code] = m
    return glyphs

def binarize(frame, thr=180):
    """Píxel 'claro' = texto. Devuelve matriz de bits."""
    g = frame.convert('L')
    px = g.load()
    w,h = g.size
    return [[1 if px[x,y] > thr else 0 for x in range(w)] for y in range(h)]

def match_glyph(binimg, x, y, m):
    """¿El tile 8x8 en (x,y) coincide con el glifo m? (con tolerancia)."""
    miss = 0
    for r in range(8):
        for c in range(8):
            if y+r >= len(binimg) or x+c >= len(binimg[0]):
                return False
            if binimg[y+r][x+c] != m[r][c]:
                miss += 1
    return miss <= 6  # tolerancia por antialias

def scan(frame, glyphs, x0=0, y0=0, x1=None, y1=None, step=1):
    """Escanea el frame buscando glifos. Devuelve lista de (x,y,char)."""
    b = binarize(frame)
    w,h = frame.size
    if x1 is None: x1 = w
    if y1 is None: y1 = h
    found = []
    for y in range(y0, y1, step):
        for x in range(x0, x1, step):
            for code, m in glyphs.items():
                if code == 0x20:  # espacio no se detecta por glifo
                    continue
                if match_glyph(b, x, y, m):
                    found.append((x, y, CHAR.get(code, chr(code))))
    return found

def reconstruct(found, tol_x=8, tol_y=8):
    """Agrupa coincidencias en líneas de texto."""
    if not found:
        return []
    found.sort(key=lambda p:(round(p[1]/tol_y), p[0]))
    lines = []
    cur = []
    last_y = None
    for x,y,ch in found:
        if last_y is None or abs(y-last_y) <= tol_y:
            cur.append((x,y,ch))
        else:
            lines.append(sorted(cur))
            cur = [(x,y,ch)]
        last_y = y
    if cur: lines.append(sorted(cur))
    out = []
    for line in lines:
        line.sort(key=lambda p:p[0])
        # colapsar caracteres que comparten posición (elegir el más 'raro')
        text = ''
        prev_x = None
        for x,y,ch in line:
            if prev_x is not None and x - prev_x < 4:
                # solapado, saltar
                continue
            text += ch
            prev_x = x
        out.append((line[0][1], text))
    return out

if __name__ == '__main__':
    frame = Image.open(sys.argv[1]).convert('RGB')
    rom = open(sys.argv[2],'rb').read()
    glyphs = load_font(rom)
    y0 = int(sys.argv[3], 0) if len(sys.argv) > 3 else 0
    found = scan(frame, glyphs, y0=y0)
    for y, text in reconstruct(found):
        print(f'y={y:3d}: {text}')

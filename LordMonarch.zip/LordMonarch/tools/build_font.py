"""build_font.py — añade glifos acentuados a la fuente de Lord Monarch (MD).

Fuente 2bpp en 0x19AEC0, 32 bytes/glifo (8 filas x [plano0 word BE, plano1 word BE]).
índice = ASCII - 0x20. Tabla de anchos en 0x19ADC0 (byte/glifo).

Añade 16 glifos en índices 96-111, mapeados a bytes 0x80-0x8F (índice = byte-0x20).
"""
import sys

FONT = 0x19AEC0
WIDTH = 0x19ADC0
BYTES_PER_GLYPH = 32

# byte (código) -> (glifo base, tipo). bytes 0x81-0x90 -> índices 97-112.
# (0x80 -> índice 96 está RESERVADO: es el glifo de relleno de 0x1de364/0x1de388.)
ACCENTS = [
    (0x81, 'a', 'tilde'), (0x82, 'e', 'tilde'), (0x83, 'i', 'tilde'),
    (0x84, 'o', 'tilde'), (0x85, 'u', 'tilde'), (0x86, 'n', 'tilde'),
    (0x87, 'N', 'tilde'), (0x88, 'u', 'dieresis'), (0x89, 'U', 'dieresis'),
    (0x8A, '!', 'bang'), (0x8B, '?', 'iquest'),
    (0x8C, 'A', 'tilde'), (0x8D, 'E', 'tilde'), (0x8E, 'I', 'tilde'),
    (0x8F, 'O', 'tilde'), (0x90, 'U', 'tilde'),
]

def glyph_index(ch):
    return ord(ch) - 0x20

def read_glyph(data, idx):
    """Devuelve matriz 8x8 de ints 0-3."""
    off = FONT + idx * BYTES_PER_GLYPH
    m = [[0]*8 for _ in range(8)]
    for r in range(8):
        w0 = data[off + r*4] << 8 | data[off + r*4 + 1]
        w1 = data[off + r*4 + 2] << 8 | data[off + r*4 + 3]
        for c in range(8):
            p0 = (w0 >> (15-c)) & 1
            p1 = (w1 >> (15-c)) & 1
            m[r][c] = (p1 << 1) | p0
    return m

def write_glyph(data, idx, m):
    off = FONT + idx * BYTES_PER_GLYPH
    for r in range(8):
        w0 = 0; w1 = 0
        for c in range(8):
            v = m[r][c]
            if v & 1: w0 |= 1 << (15-c)
            if v & 2: w1 |= 1 << (15-c)
        data[off + r*4]     = (w0 >> 8) & 0xFF
        data[off + r*4 + 1] = w0 & 0xFF
        data[off + r*4 + 2] = (w1 >> 8) & 0xFF
        data[off + r*4 + 3] = w1 & 0xFF

def draw(m, r, c, v):
    if 0 <= r < 8 and 0 <= c < 8:
        m[r][c] = v

COLOR = 3  # color principal ('X' en el volcado)

def add_tilde(m, upper):
    """Añade acento agudo. upper=True -> letra mayúscula (tilde fila 0)."""
    if upper:
        # tilde comprimida en fila 0 (col 3 y 4)
        draw(m, 0, 3, COLOR); draw(m, 0, 4, COLOR)
    else:
        # diagonal en filas 1-2 (sube hacia la derecha)
        draw(m, 1, 4, COLOR); draw(m, 2, 3, COLOR)

def add_dieresis(m, upper):
    if upper:
        draw(m, 0, 2, COLOR); draw(m, 0, 5, COLOR)
    else:
        draw(m, 1, 2, COLOR); draw(m, 1, 5, COLOR)

def clear(m, r0, r1):
    for r in range(r0, r1+1):
        for c in range(8):
            m[r][c] = 0

def build(rom):
    data = bytearray(rom)
    for code, base_ch, kind in ACCENTS:
        base = glyph_index(base_ch)
        m = read_glyph(data, base)
        if kind == 'tilde':
            upper = base_ch.isupper()
            if base_ch == 'i':
                # quitar el punto de la 'i' antes de poner tilde
                clear(m, 1, 2)
                # tilde más arriba para la i
                draw(m, 0, 4, COLOR); draw(m, 1, 3, COLOR)
            else:
                add_tilde(m, upper)
        elif kind == 'dieresis':
            add_dieresis(m, base_ch.isupper())
        elif kind == 'bang':
            # '¡' = '!' invertido verticalmente
            m = [row[:] for row in reversed(m)]
        elif kind == 'iquest':
            # '¿' = '?' invertido verticalmente
            m = [row[:] for row in reversed(m)]
        idx = code - 0x20  # índice destino (96+)
        write_glyph(data, idx, m)
        # copiar ancho del carácter base
        data[WIDTH + idx] = data[WIDTH + base]
    return bytes(data)

if __name__ == '__main__':
    src = sys.argv[1]; dst = sys.argv[2]
    rom = open(src, 'rb').read()
    out = build(rom)
    open(dst, 'wb').write(out)
    print(f'OK: {len(out)} bytes -> {dst}')

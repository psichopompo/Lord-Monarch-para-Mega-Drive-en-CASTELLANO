"""tiles.py — vuelca una región de ROM como tiles 8x8, en arte ASCII.

Uso: python3 tiles.py rom.bin <offset_hex> <n_tiles> [1bpp|2bpp]

Para "ver" fuentes sin visión: cada glifo se dibuja con # (pixel) y . (vacío).
"""
import sys

def dump_tiles(data, offset, n, bpp=1, stride_bytes=None):
    """Imprime n tiles de 8x8. bpp=1 (1 bit) o 2 (2 planos interleaved MD)."""
    out = []
    for t in range(n):
        rows = []
        if bpp == 1:
            for r in range(8):
                b = data[offset + t*8 + r]
                rows.append(''.join('#' if (b>>(7-c))&1 else '.' for c in range(8)))
        elif bpp == 2:
            # Mega Drive 2bpp: 4 bytes por fila (2 words: plano0 word, plano1 word)
            for r in range(8):
                w0 = data[offset + t*32 + r*4]<<8 | data[offset+t*32+r*4+1]
                w1 = data[offset + t*32 + r*4+2]<<8 | data[offset+t*32+r*4+3]
                row=''
                for c in range(8):
                    p0 = (w0>>(15-c))&1
                    p1 = (w1>>(15-c))&1
                    row += ' #oX'[(p1<<1)|p0]
                rows.append(row)
        else:
            raise ValueError('bpp')
        out.append(rows)
    # imprimir lado a lado, 16 tiles por fila de pantalla
    for i in range(0, n, 16):
        group = out[i:i+16]
        for r in range(8):
            line = ' '.join(g[r] for g in group)
            print(f'{i:3d}| {line}')
        print()

if __name__ == '__main__':
    rom = open(sys.argv[1],'rb').read()
    off = int(sys.argv[2],16)
    n = int(sys.argv[3],16)
    bpp = 1
    if len(sys.argv)>4:
        bpp = 1 if sys.argv[4]=='1bpp' else 2
    dump_tiles(rom, off, n, bpp)

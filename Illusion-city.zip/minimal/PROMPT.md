# Illusion City (Mega CD) — Menu Text Box Wrap Bug — Self-Contained Task for Parallel Agent

## Objetivo
Arreglar el corte de 1px en la 7ª letra del menú del sistema (in-game). Palabras afectadas: **Objetos** (s cortada) y **Sistema** (a cortada). La O de Objetos tiene una muesca en (59,60) por el wrap. Solo faltan 1-2px libres de anchura. **No mover el texto**, solo ensanchar la caja pintable. Texto debe quedarse en posición v3.2 (X=0). Fallback textual "Objeto" solo si todo falla.

## Contexto técnico
- Juego: Gen'ei Toshi - Illusion City (Japan) Mega CD. Motor 68000, base START.BIN $10000 (file offset = runtime - 0x10000). Buffer de texto menú = $A6000 (RAM), limpiado en $17680, render en $172A6 → $174F4 → $1838C → $18B18.
- Blitter $18B18: `off = ((X>>1)+(Y>>1)*$8(a0))*32; a4 = $1E + off;` X+=3 por glifo (12px). $8(a0) = row stride en unidades X/2 (8px). 7 letras necesitan 9 unidades X/2, $08=10 da 80px, borde der 56+80=136 → clip exacto medido en x136.
- Medición 1:1 (256x224, captura 051810.png): frame naranja x49 y x142, interior negro x50-141 (92px), clip texto x136 (s pierde x136, a pierde x136). Captura 8.00.39.png (6x zoom) muestra s con 1px faltante y O con muesca en (59,60) por wrap (s desbordada cae sobre O).
- Tabla menú en START.BIN @file 0x119A8-0x11A00 (runtime $219A8): `31 7C val off` = $off(a0)=val. Campos: $2A=0,$2C=0,$26=1,$28=6,$32=3,$18=0,$2E=5,$04=7,$06=5,$08=10,$0A=9,$1A=0x8000,$1E=$A6000, JSR $172A6/$1744E. Función menú @0x11928 BSR $21996.
- SSTART.BIN @0xE52 setup menú (mensajes backup RAM, no menú principal): $22=$11068,$04=7,$06=14,$08=17,$0A=3,$1A=0x8000,$1E=$A6000. $08=17 → 136px row, no coincide con clip 80px.

## Qué se ha probado y ha FALLADO (no repetir sin nueva evidencia)
- v3.5: START $04 7→8 @0x119D5 (31 7C 00 08 00 04) — sin efecto
- v3.6: START $08 10→11 @0x119DE (31 7C 00 0B 00 08) — sin efecto
- v3.7: SSTART $08 17→18 @0xE6F (11→12) — movió bloque a la derecha (asimetría), wrap igual
- v3.8: SSTART $04 7→6 @0xE63 + $08 17→18 @0xE6F — sin efecto (posición invariante $C=$04+$08/2=15)
- v3.9: START $08 10→11 de nuevo — sin efecto
- v3.10 diagnóstico agresivo: START $04 0 + $08 20 @0x119D2/0x119DE — **sin efecto**, prueba que tabla START 0x119A8 está muerta (no se usa en runtime)
- v3.11: reducir espaciado ADDQ.W #3→#2 $14(a0) @0x8B54 (56 68 00 14 →52 68 00 14) — sin efecto
- v3.12: $32 3→2 (4px izq) @0x119C0 y $32 FF FF (-1) — sin efecto / rompió (M desaparece, wrap a derecha) → revertido
- X=-1 (FF FF) probado en v3.3: M desaparece, O peor, restos a derecha → $A5FE0-$A5FFF no es RAM libre. X unit =4px, 2px imposible.

Conclusión: **START.BIN @0x119A8 y SSTART @0xE52 no son la caja viva**. La anchura real está en otro sitio.

## Pistas restantes
- START.BIN tiene 25 setups con buffer $A6000 (MOVE.L #$A6000,$1E) y 163 con $A6B00. Solo 3 con $28=6 (6 filas): @0xC5DE ($04=6,$06=10,$08=21), @0x117E0 ($04=17,$06=3,$08=12), @0x119BA ($04=7,$06=5,$08=10) = menú. Solo 0x119BA coincide con medición, pero es muerta.
- MSTART.BIN, OSTART.BIN, SD.BIN no tienen $A6000. MSTART 0x1330-0x1368 contiene init VDP (81 24 90 11 8B 00 8C 81...), no caja.
- Tabla de bitmaps @START 0x1D28: punteros $80000+off (CHR1.BIN base $80000). Ej: 00 08 00 00, 00 08 28 D6, 00 08 51 AC... step 0x28D6=10454. CHR1.BIN len 47984, 4 bitmaps. Esos bitmaps son los fondos de menú copiados a $AB000/$AE000/$B0000. La caja podría estar ahí.
- Blitter $18B18 solo tiene 2 MULU $08 en START: @0x7792 y @0x8B32. $08 solo se usa ahí.
- $1C(a0) = $08*$0A*16 buffer size, leído en @0x759B etc.
- Capstone 68k falla (43 F9 ≠ LEA, D1 68 = ADDX.W no ADD.W). Hand-decode crítico.

## Archivos en este zip (mínimo)
- recursos/track01.iso (16MB, ISO 2048 B/sector, LBA: START 59 98184B, SSTART 43 32644B, etc)
- recursos/analisis/START_CAST.BIN (98KB, v3.2 baseline: Grp blanco 1 dígito, Equipo de Tianren, etc)
- recursos/analisis/SSTART_CAST.BIN (32KB, original)
- recursos/analisis/INIT.BIN (146KB, fuente menú tabla @0x4ED0 12x12 18B)
- recursos/tools/reconstruir_iso.py (inyecta START@LBA59 + SSTART@LBA43 + fuente INIT/OPEN/GFONT, escribe /tmp/track01_castellano.iso y [CAST].bin raw 2352)
- recursos/tools/fuente_menu.py + codificador_castellano.py + reconstruir.py
- recursos/iso_map.json
- DIARIO.md (histórico completo) + NORMAS.md
- uploads/8.00.39.png (zoom 6x con regla, s/O cortados) + 051810.png (256x224 nativo) + 034542.png (original JP)

## Pipeline
`cd recursos; python3 tools/reconstruir_iso.py` → /tmp/track01_castellano.iso + Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin (18,444,384 B raw). Fórmula raw: `(LBA+off//2048)*2352+16+off%2048`. Verificar siempre ISO y [CAST].bin raw, no solo mensajes.

## Tarea para agente paralelo
1. Encontrar el campo real de anchura de la caja de texto del menú sistema (no START 0x119A8 ni SSTART 0xE52). Candidatos: VDP window right-edge reg, horizontal modulo en blit fns 0x1244C/0x12508/0x125C4/0x12680 + bsr $1273E, tilemap en CHR1.BIN/SD.BIN, o $26/$1C/$32/$18.
2. Parchear con +1-2px libres sin mover texto (X=0). $08 10→11 mantiene $C=7+5=12 invariante si $C=$04+$08/2.
3. Probar en emulador (Genesis Plus 1.3.5) con [CAST].bin, capturar menú, medir s@x136.
4. Si no se encuentra, fallback "Objetos"→"Objeto" solo con aprobación.

## Vocab y restricciones
- Fuente menú 12x12 18B en INIT 0x4ED0, fullwidth Latin 8260-8279/8281-829A/824F. Grp blanco 1 dígito OK, Equipo de Tianren OK, X=0 baseline.
- No compilar Genesis Plus GX, workspace <128MB.
- Deliverable filename fijo: `Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin`

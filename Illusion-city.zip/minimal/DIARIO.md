# DIARIO — Illusion City [CAST] (sesiones en este workspace)

> Continúa el diario de la sesión anterior (ver `recursos/informes/DIARIO.md` —
> leer SIEMPRE al empezar). Este diario registra lo hecho AQUÍ, bien y mal.
> Reglas vivas: `NORMAS.md`. Actualizar al final de cada tarea.

## Contexto
- David prueba en Genesis Plus 1.3.5 con el .cue [CAST]. Él ve pantallas; yo no
  puedo ejecutar el emulador. Sus capturas son la fuente de verdad visual.
- Workspace ligero (límite de snapshot 128MB). Tras limpieza 2026-09-18:
  **54MB**. Lo imprescindible: track01_original.bin (18MB, fuente de todo),
  recursos/track01.iso (16MB, input del pipeline), [CAST].bin (18MB, entrega),
  recursos/{tools, textos_dumper.csv, extraidos/{START,GFONT,INIT}.BIN,
  analisis/{START_CAST_V3,START_CAST,GFONT_*}.BIN, informes/{DIARIO,
  INFORME_TRADUCCION,[CAST].cue}}, DIARIO.md, NORMAS.md. El resto (zip, ISOs
  duplicadas/intermedias, dumps SJIS, state_*.bin, backups CSV) era
  regenerable → borrado. [ORIGINAL].bin para el pipeline se copia al vuelo
  de track01_original.bin (NORMA 18).

## 2026-09-18 — Sesión 2 (esta)

### Hecho
1. Verificado íntegro el .bin original (git hash = 51c1089d...). Descargado y
   descomprimido Recursos.zip; borrado __MACOSX.
2. **MAPA DE REFERENCIAS DE PLANTILLAS** (hito clave): cada plantilla de
   START.BIN es referenciada por u32 (inmediatos) en el código 68000. Escaneé
   TODO el archivo y decodifiqué cada referencia:
   - **Z22 Velocidad (130B @0x143EE)**: ÚNICA referencia real =
     `move.l #$243EE, $22(a0)` en 0x139AE. Las "refs" +11/+18/+92 eran FALSOS
     POSITIVOS (bytes de `andi.w`, `bsr`, `move.w $2(an)`+`lea`). → Z22 se puede
     REUBICAR y cambiar de largo sin tocar más código.
   - **Z5 Magia (136B @0x13D60)**: base (0x11DE8) + 5 writes absolutos:
     nombre @+8 (lea 0x11E00, jsr $2087E copia máx d2=5 chars desde $bd00),
     now3 @+76 (lea 0x11E14, jsr $18722 3 dígitos), ind2 @+94 (lea 0x11E56,
     jsr $186D6), max3 @+114 (lea 0x11E66, jsr $18722), grp2 @+132
     (lea 0x11E98, jsr $186D6).
   - **Ventana objetivo (0x13DF6..)**: tabla de 3 u32 en 0x13DEA-0x13DF5
     (dirección RAM fija 0x23DEA; NADA apunta a la tabla → la tabla NO se mueve,
     las 3 cadenas sí se pueden mover).
   - **Z10-Z15 Equipo / Z16-Z18 tabs**: tablas de punteros + writes en +8/+32
     (las parches v3 mantuvieron longitudes → seguras).
   - **Z19 Ficha (338B)**: ~25 refs absolutas (leas + tabla de datos 0x13396-
     0x133FE para Z21; Z19 tiene leas en 0x12E1x-0x12F9x y datos @0x4257 etc.).
   - **Z20 Técnicas (392B)**: 71 refs (leas + tabla 0x13150-0x131C4).
   - **Z21 Combate (360B)**: 44 refs (leas + tabla de 25 u32 en 0x13396-0x133FE).
   - **Z23/Z24 [SanaPV]/[SanaPM]**: leas 43F9 (0x120C4/0x125F0/0x126DE).
3. **REGRESIÓN ENCONTRADA (la causa probable de pantallas raras)**: la sesión
   anterior cambió las LONGITUDES de línea de Z5 (L0 26→20B, L4 36→42B), Z19
   (todas las líneas) y Z21 (L1 38→40B, L6 36→34B) SIN actualizar los offsets
   absolutos del código → en juego, los valores numéricos se escriben sobre las
   etiquetas (Z5: el valor de PM pisaría "Ind"; Z19: total caos; Z21: filas
   Ataque/Def/Agi desalineadas +2). Z20 quedó OK (mismo largo).
   DECISIÓN: esta sesión Z19/Z21 vuelven al japonés original (pantallas que
   FUNCIONAN); el rediseño ES con mapa de refs se hace en la sesión siguiente.
4. Diseño v4 de las 4 zonas pedidas por David (menú velocidad, menú magia,
   ventana objetivo, HUD) — ver parchear_start_v4.py.

### Pendiente (esta sesión) — CERRADO en la parte 2
- [x] track01.iso desde el .bin original.
- [x] parchear_start_v4.py + ejecutar (v4 final, alocador secuencial).
- [x] reconstruir_iso.py → .bin [CAST] final.
- [x] Verificación final de bytes en el .bin publicado (NORMA 4) — 0 diffs
      sector a sector + checks de contenido.
- [x] Búsqueda LV/HP/MP/レベル/体力/術気 (resultado en parte 2: tabla de
      mensajes de batalla = nuevo front).
- [x] Cerrar diario + normas.

### Frontes para sesiones siguientes (orden, actualizado en parte 2)
1. **Tabla de mensajes de batalla ES**: bloque INIT.BIN 0x233A0-0x23560
   (≈25 cadenas $2の体力が#1回復 / $2の術気が#1回復 / ...), DUPLICADO en
   OPEN.BIN 0xFae1-0xFCxx, + fragmento START.BIN 0xD8D0. Slots 12-22B →
   español no cabe in-situ; sin refs u32 → diagnosticar primero cómo se
   direcciona la tabla (offsets relativos? tabla de índices?). Cuidado:
   INIT.BIN = archivo de alto riesgo (rebuild global → GAME OVER); solo
   ediciones quirúrgicas.
2. **Nombres de técnicas de magia (sin abreviar)**: 栄気=Energía Vital,
   練気=Ki Concentrado, 気功弾=Bala de Ki, 被甲護身=Cuerpo Acorazado,
   防呪結界=Barrera Anti-Maleficios, 守気=Ki Guardián, 攻気=Ki Ofensivo,
   封呪=Sello Mágico, 遅動=Ralentizar. Zona Z20 (0x140DE) + lista Z21.
3. **Z19 Ficha ES**: rediseño conservando longitudes o reubicación + parche
   de ~25 refs. Labels: NV/EXP/Next/PV/PM/Ataque/Defensa/Agilidad/Pericia/
   Acierto. (Mapa de refs en la parte 1 de este diario.)
4. **Z21 Combate ES**: tabla de datos 0x13396-0x133FE (25 u32) + leas.
5. **Z20 Técnicas ES**: columnas de armas (Ｇｕｎ, ライフル, 砲, ヘビー,
   クロー, 杖, 剣, 斬糸) — nombres de David pendientes.
6. Fuente 膨: localizar la tabla de fuente del menú de velocidad si David
   sigue viendo 膨 (celda fina 226 parcheada en 3 copias + 48 bitmaps
   gruesos ya aplicados).
7. Desbloquear no_cabe=329 (vía de crecimiento segura, sin romper INIT).
8. Continuar guion (A10.BIN y siguientes).

## 2026-09-18 — Sesión 2, parte 2 (v4 final + bin publicado)

### Hecho (bien)
1. **Layout del hueco libre por alocador secuencial** en parchear_start_v4.py:
   los blobs (Z22, Z5, EFG, IT, SY, redirects) se construyen primero y se
   colocan con `alloc()` (HUECO0=0x17500, FIN_LIBRE=0x17F7F). Cero offsets
   manuales. Layout final (impreso por el log de cada run):
   `Z22=0x17500(138B) Z5=0x1758A(144B) EFG=0x1761A/27/2E IT=0x17639/46/4F/5E
   SY=0x17669/84/A3 redir=[0x176C4,0x177AE) 33 u32`.
2. **Fuente de las zonas copiadas**: V3 → `analisis/START_CAST_V3.BIN`
   (pieza v3 limpia, no self-referencial).
3. **Tabla del menú principal arranca en 0x13D12** (6 u32), no en 0x13D18
   (lectura desalineada de la sesión anterior). Rango copiado de v3 corregido.
4. **Swap nuevo byte-neutro**: 0x14F18 術気→ＰＭ (ventana de magia EN combate,
   plantilla 39B 術気/n〔個〕/〔集〕; sin refs u32, acceso por offset).
5. **Pipeline completo**: reconstruir_iso.py → track01_castellano.iso +
   [CAST].bin (18,444,384 B) + CUE ya existente en informes/. Stats: in-situ
   v1 ok=147, no_cabe=329, errores=0; bitmaps 48/48 (16×3); celda fina 226/á
   ×3; START.BIN @LBA59.
6. **MAPEO BIN↔ISO (descubrimiento clave)**: el user data del bin NO es
   contiguo entre sectores (cada sector 2352 tiene 288 B de header).
   Mapeo correcto: `bin = (L + X//2048)*2352 + 16 + X%2048` donde L=LBA del
   archivo y X=offset dentro. La nota vieja "0x21D80+X" era FALSA.
   Verificación de [CAST].bin: región START (48 sectores) vs START_CAST.BIN =
   0 diffs + checks de contenido (Velocidad/Rápido-Lento/[Magia]+7 celdas/
   Efecto/Ind/Grupo/[Item]/Conversación-ó/NV/PV/PM/Combate/base 0x27500/
   tablas EFG+IT+SY/HUD Tianren-Meifan-Isaac).
7. **Escaneo completo del disco** (167 archivos):
   - ASCII LV/HP/MP (66 hits): FALSOS POSITIVOS en datos binarios
     (GENEI_ED/OP.DAT, F20/F50/C40/CK4, código INIT/OPEN). Ninguna cadena.
   - ＬＶ/ＨＰ/レベル: 0 hits (todo ya traducido o inexistente).
   - ＭＰ: 2 hits = nombre de arma "ＭＰ５ＫＡ４" (Ingram) en INIT/OPEN → SE
     MANTIENE (es nombre de modelo, no la etiqueta de recurso).
   - **体力/術気: 14 hits REALES de mensajes de batalla sin traducir**:
     bloque INIT.BIN 0x233A0-0x23560 (≈25 cadenas: '$2の体力が#1回復',
     '$2の術気が完全回復', '$2が#1の体力を失った'...) DUPLICADO en OPEN.BIN
     (0xFae1...) + fragmento START.BIN 0xD8D0 '体力を失った' (slot 13B, sin
     refs u32 → no fixable in-situ). SIN refs u32 → la tabla se accede por
     otro mecanismo (pendiente de diagnosticar). → siguiente front.

### Hecho (mal) — errores de ESTA parte
1. **Sumas hex manuales otra vez**: 0x176B4+31B=0x176D3 (escribí 0x176CB →
   SY3 pisó el ＯＦＦ de SY2) e IT3+15B=0x1768B (escribí 0x1768A). Solución:
   alocador (punto 1).
2. **Mis propios scripts de verificación traían expectativas falsas** (5 de 4
   "fallos" no eran del parche): pensé Ｅ=8265 (es **8264**), Ｖｅｌｏｃｉｄａｄ
   = 11 celdas (son 9), L2 de Z22 en 0x17524 (empieza en 0x17518), EFG
   'Ｅｆｅｃｔｏ' = 11B (son 12B), 'Ｉａａc' (typo de Isaac), y "dígitos ８-１５"
   cuando la plantilla ORIGINAL muestra １-８ en las celdas 8-15 (la spec
   se refería a la posición, no al valor). → NORMA 15/17.
3. **Borré [ORIGINAL].bin del pipeline antes de re-ejecutarlo** → fallo
   FileNotFoundError al regenerar [CAST].bin. Copiarlo de nuevo y re-ejecutar.

### Pendiente
- [ ] David prueba el bin nuevo (borrar bins viejos del directorio del CUE).
- [ ] Tabla de mensajes de batalla (体力/術気, INIT+OPEN+START) → ver frontes.
- [ ] Nombres de técnicas de magia (栄気=Energía Vital, 練気=Ki Concentrado,
      気功弾=Bala de Ki, 被甲護身=Cuerpo Acorazado, 防呪結界=Barrera Anti-
      Maleficios, 守気=Ki Guardián, 攻気=Ki Ofensivo, 封呪=Sello Mágico,
      遅動=Ralentizar) — deben caber SIN abreviar (Z20/Z21).
- [ ] Ventana objetivo: usé "Ind" (plan B). Si David ve que la caja flotante
      es ancha, "Individual" cabe (el string va en zona libre).

## Notas técnicas — layout FINAL v4 (supera la chuleta anterior)
- Z5: 144B @0x1758A (RAM 0x2758A). L0 30B: ［Ｍａｇｉａ］(1-7) + 8 celdas
  (nombre @+16, 7 celdas, d2 parcheado 5→7). L2 30B: 6sp &4ＰＭ(7-8) sp Ｃｏｓｔｅ
  (10-14) — patrón de color idéntico al original (sin &7, como en 術気/消費術気).
  L3 36B: &5Ａｈｏｒａ&7＋０００(val @+80, 3 dígitos der. → ≤99 en 7-8) sp
  &5Ｉｎｄ&7＋００(val @+98). L4 40B: &5Ｍａｘ&7＋０００(val @+118) ００(val
  @+126) &5Ｇｒｐ&7. Parches: 0x11DEA base, 0x11E02 +16, 0x11E08 d2=7,
  0x11E16 +80, 0x11E58 +98, 0x11E68 +118, 0x11E9A +126. Old 0x13D60-0x13DE7 a 0.
- Z22: 138B @0x17500 (RAM 0x27500). L0 20B: &5＋Ｖｅｌｏｃｉｄａｄ(1-9, sin padding
  — igual que original); L2 34B: &4＋3sp＋Ｒáｐｉｄｏ(4-9, á=9660)＋sp＋Ｌｅｎｔｏ
  (11-15)＋&7; L3 30B: 7sp＋１２３４５６７８(8-15, IGUAL que original);
  L4 Ｔｅｘｔｏ(1-5); L5 Ｍｏｖｅｒｓｅ(1-7); L6 Ｃｏｍｂａｔｅ(1-7). Un parche:
  0x139B0→0x27500. Old 0x143EE-0x14471 (132B) a 0.
- EFG: 0x1761A/27/2E (Efecto/Ind/Grupo); tabla in-situ 0x13DEA-0x13DF5.
- IT: 0x17639/46/4F/5E ([Item]/Usar/Cambiar/Tirar); tabla 0x13E16+4k;
  entradas 3-5 conservan desplazamiento +2 (semántica del original).
- SY: 0x17669/84/A3 (VR transp/Autoesquiva/Conversación + sp + ＯＦＦ);
  tabla 0x14472+4k; las únicas refs a los strings originales eran las 3
  entradas de tabla (verificado con refs u32).
- Menú principal: tabla 0x13D12 (6 u32); etiquetas redirigidas conservan refs.
- Ventana magia combate: 0x14F18 術気→ＰＭ (swap byte-neutro).

## Notas técnicas nuevas (chuleta sesión 2, parte 1 — SUPERADA en offsets)
- Z5 v4: reubicada a 0x17590 (RAM 0x27590), 142B. L0 32B: [Magia](1-7)
  FW(8-9) nombre 7 celdas (10-16, d2 5→7). L2 30B igual. L3 36B (=largo orig,
  offsets de valor intactos: now3 @L3+14, ind2 @L3+32). L4 36B: Max(1-3)
  FW(4-6) max2(7-8) FW(9) grp2(10-11) FW(12) Grp(13-15) — jsr max 18722→186D6.
  Parches código: 0x11DEA (base), 0x11E02 (nombre→+18), 0x11E06 (d2=7),
  0x11E16 (now→+82), 0x11E58 (ind→+100), 0x11E68 (max→+122) + 0x11E70
  (jsr 186D6), 0x11E9A (grp→+128).
- Z22 v4: reubicada a 0x17500 (RAM 0x27500), 132B. L0 &5Velocidad(1-9);
  L2 &4 FW×3 Rápido(4-9) FW Lento(11-15) &7; L3 FW×7 １２３４５６７８(8-15);
  L4 Texto(1-5); L5 Moverse(1-7); L6 Combate(1-7). Parche: 0x139B0→0x27500.
- EFG v4: strings en 0x17630/0x17640/0x17658 (Efecto 13B, Individual 21B,
  Grupo 11B); tabla 0x13DEA actualizada (0x27630/0x27640/0x27658). Ojo: la
  caja flotante puede no ser tan ancha como "Individual" → verificación visual
  de David; plan B "Ind".
- HUD: se mantiene el parche v3 (nombres Tianren/Meifan/Isaac + PV/PM en
  0x0CB8C-0x0CBC8; labels 体力/術気 → PV/PM). Sin LV en HUD (LV solo en ficha).

## Fuente: el "bug del 膨" — cierre (18/09, sesión de arqueología de fuente)
- **El "膨" de Rápido era un 冒 (0x9660)**. Zoom 16× del slot (x69-88, y69-84):
  glifo = 日 + 儿 = 冒, un kanji fullwidth real. A 0.8× de resolución el 日
  parece 月 y el 儿 parece 皮 → lectura 膨. No existía bug de bitmap: el motor
  dibujaba el kanji 冒 tal cual.
- **Causa raíz**: el HIJACK (16 slots 0x95FB-0x9770 pintados con glifos 12×12)
  solo alcanzó las tablas 12×12 (GFONT celdas 422-437 + celda 226, 3 copias en
  INIT/OPEN/GHEAD). La fuente 16×16 de los MENÚS se dibuja desde una tabla que
  **NO está en el ISO como bitmap lineal**: probados y descartados GFONT
  (18B/12B/24B/330×24/660×12), GHEAD (mapa 576×2 u16 + región 0x900-0C70
  empaquetada = ruido), H01 (base 0x897A) y H02 (base 0x8981) — sus slots 冒
  están vacíos (12 bits) y su 術 ≠ 術 del menú. H01/H02 = fuente cinemática.
  Búsquedas fuzzy a disco entero de 冒/術/膨 (16×16 32B, 14 col 32B, 16×12
  24B, 8×10): mejores distancias 29-34/176, sin consistencia de tabla →
  la tabla del menú está comprimida o se arma en RAM.
- **Solución aplicada (HIJACK remapeado, sin acentos)**:
  - `codificador_castellano.py`: override `_HIJACK_OVERRIDE` — á→ａ 8281,
    é→ｅ 8285, í→ｉ 8289, ó→ｏ 828F, ú→ｕ 8295, ü→ｕ 8295, ñ→ｎ 828E,
    Á→Ａ 8260, É→Ｅ 8264, Í→Ｉ 8268, Ó→Ｏ 826E, Ú→Ｕ 8274, Ñ→Ｎ 826D,
    ¿→？ 8148, ¡→！ 8149. (Códigos verificados con codecs, no de memoria.)
  - `reconstruir_iso.py`: se DESCARTAN los 48+3 parches de bitmaps (0
    reemplazos ahora). Ventaja extra: las celdas 12×12 vuelven a su kanji
    original → evita regresiones tipo 冒険→"á険" en fuentes 12×12.
  - Regenerado `parchear_start_v4.py` → START_CAST.BIN (tpl Z22 = Ｒａｐｉｄｏ
    8271 8281 8290 8289 8284 828F) → `reconstruir_iso.py`.
- **Verificación del [CAST].bin nuevo**: bitmaps 16 glifos = 0; región GFONT
  == original; tpl Z22 sin 9660; total 9660 en bin == 70 == original (todos
  japones legítimo); in-situ ok=147 no_cabe=329 err=0 (igual: fullwidth 2B
  mantiene longitudes).
- **Hecho mal (herencia)**: la entrada anterior "la fuente fina de menú usa
  GFONT celda 226" era FALSA (celda 226 = un glifo puntitos pequeño, no 冒);
  los 48 bitmaps se pintaron en tablas que el menú no usa → 1 día entero de
  arqueología. Lección → NORMAS 19-22.
- **Pendiente**: validar con David si "Rapido" sin acento es aceptable como
  solución provisional; ofrecerle la vía RAM dump (Genesis Plus GX, con el
  menú abierto: font struct RAM 0x0A230, array 0x0A230+w(0x0A242)) para
  parchear la tabla real con la fuente Lord Monarch o acentos de verdad.
- **Frentes abiertos (sin cambio)**: batch 6 frentes (Z19/Z21 etiquetas de
  stats, Z5, 所持金, Grp/SY, etiquetas equip) + 329 no_cabe + scripts.

## CORRECCIÓN: era 膨, no 冒 (18/09, 22:15 — ampliación de David)
- David envía ampliación 4× del glifo 0x9660 ("R膨pido"). Análisis objetivo de
  pixel a pixel (grid 11×10 extraída a escala 4px/bloque):
  - Componente IZQUIERDO = caja de 10 filas de alto: barra superior + 2 barras
    internas (filas 2 y 5) + verticales continuas + SIN barra inferior = 月
    (NO 日: 日 es corto ~5 filas y tiene barra inferior).
  - Componente DERECHO = horizontal superior + trazos cruzados + diagonal
    final a derecha-abajo = 皮.
  - **月 + 皮 = 膨. David tenía razón.** El zoom 16× de la captura 201839
    (256×224, escala 0.8×, antialiasing) engañó: el 月 pareció 日 y el 皮 pareció
    儿. Lección: el error de misreading costó una sesión; NORMAS 20-21 cubren
    esto, añadir: NUNCA afirmar identidad de kanji desde zoom de captura
    pequeña; exigir ampliación de David o bitmap exacto.
- **Consecuencia**: el mapeo código→glifo de la fuente del menú NO es SJIS
  identidad: el slot que el código 0x9660 ocupa en la tabla del menú contiene
  膨 (en la tabla 12×12 de GFONT el mismo 0x9660 = 冒, celda 431, verificado).

## Reversión del remapeo + estado (18/09, 22:30)
- David rechaza "sin acento" ("mejor dejar el kanji hasta que demos con la
  solución"). **REVERTIDO** el `_HIJACK_OVERRIDE` de codificador_castellano.py:
  vuelve el HIJACK original (á=0x9660 etc.). Regenerado [CAST].bin: tpl Z22
  otra vez con 9660 (kanji a la vista), ok=147 no_cabe=329 err=0.
- **Búsqueda final de la tabla del menú con target LIMPIO** (grid 11×10 de 膨
  de la ampliación 4×): todo el ISO, filas 2B (16px), margen izquierdo 1-5,
  alineaciones 0/1 → mejor distancia 26/160 (16%), sin consistencia de tabla.
  **CONFIRMADO: la tabla 16×16 del menú no existe en el ISO como bitmap
  lineal.** Se arma en RAM (fuente empaquetada en GENEI_OP.DAT/GENEI_ED.DAT o
  generada).
- Lecho byte-level de INIT/START/OPEN/MSTART/SSTART/OSTART por lea/mov de
  inmediatos #$a230/#$a242 (struct de fuente) y lea.l #$0a2xx: CERO hits →
  la dirección del struct no es un inmediato en esos archivos.

## Fuente Lord Monarch (David) — inventario completo
- PNG 128×48 RGBA, fondo MAGENTA (placeholder transparencia) + glifos NEGROS,
  grid 16×6 de celdas 8×8. Umbral: R<50 = tinta. (No leer en grayscale:
  magenta→gris ~105 lo confundía con el glifo.)
- Contenido (96 celdas):
  - Fila 0: . , : ; ! ¡ ? ¿ ( ) / \ « » - %
  - Fila 1: 0 1 2 3 4 5 6 7 8 9 A B C D E F
  - Fila 2: G H I J K L M N Ñ O P Q R S T U
  - Fila 3: V W X Y Z a b c d e f g h i j k
  - Fila 4: l m n ñ o p q r s t u v w x y z
  - Fila 5: Á É Í Ó Ú Ü á é í ó ú ü ñ + 3 CELDAS VACÍAS (C13-15)
- **Cubre TODO el alfabeto castellano** (verificado contra las 476 traducciones
  del CSV): a-z A-Z ñ Ñ á é í ó ú ü Á É Í Ó Ú Ü 0-9 . , : ; ! ? ¿ ¡ ( ) « » - %
- **FALTAN** para los textos actuales: **$ (142 usos, dinero) y # (9 usos)**.
  Las 3 celdas vacías caben: sugerir a David $, # y " (o ×).
- Nota: las traducciones traen comillas japonesas 「」 (66+64 usos) → sustituir
  por « » (presentes en su fuente).

## Plan fuente (pendiente de David)
1. **RAM dump desde Genesis Plus GX con el menú de velocidad abierto**
   (Debug > Memory Viewer, rango 0x000000-0x0FFFFF, 64 KB). Con el dump:
   localizar la tabla (el bitmap 16×16 de 膨 ya se tiene exacto), deducir el
   esquema índice↔código y construir el parche que pinta la latina Lord
   Monarch + acentos reales en la tabla (slot 0x9660 → á real).
2. Mientras tanto: kanji a la vista (decisión de David).
3. Independentemente de la fuente: batch 6 frentes (Z19/Z21, Z5, 所持金,
   Grp/SY, etiquetas equip) + 329 no_cabe + scripts.

## 18/09/26 (II) — Fuente de menú: tabla localizada al 100%, 78 celdas pintadas
### Hechos medidos
- **Tablas de la fuente de menú**: celdas 12×12, 18 B (flujo continuo de 144
  bits, MSB-first), en **INIT.BIN+0x4ED0** (celda 0 = 術 0x8F70) y
  **OPEN.BIN+0xA710** (NO 0xA740: la memoria anterior llevaba 0x30 de error).
  Misma disposición relativa en ambas (verificado celda a celda: 術/方/Ａ).
- **Orden de la tabla = JIS fila-major sobre un subconjunto**. Clúster kanji
  verificado: 術(29,49)@rel 0, 方(42,93)@+510, 膨(43,33)@+526, 北(43,44)@+529,
  本(43,60)@+531, 魔(43,66)@+534, 民(44,17)@+550, 無(44,21)@+554, 命(44,31)@+557,
  滅(44,39)@+561, 目(44,60)@+568, 優(45,5)@+584, 誘(45,22)@+592, 予(45,29)@+599,
  誉(45,32)@+600, 様(45,45)@+606, 用(45,49)@+607 — estrictamente monótono en JIS.
  La memoria "rel -1 = 白" era una mala identificación: rel -1 = 出 (29,48),
  coherente con JIS. El subconjunto es mayor que el corpus de textos
  (~97 caracteres extra entre 術 y 方).
- **0x9660 = 冒 (verificado con cp932), NO 膨**. La fuente del juego tiene
  冒/膨 INTERCAMBIADOS: la celda de 0x9660 (rel +526, INIT 0x73CC) contiene el
  glifo 膨 (coincidencia pixel a pixel con el zoom 4× de David; por eso el
  menú mostraba 膨 para 0x9660) y la celda de 0x9663 (rel +569) contiene 冒.
- **Bloque fullwidth Latin** (leído directamente de la tabla): ０ 0x824F @ rel
  -772 (INIT 0x1888) … ９ 0x8258 @ -763, Ａ 0x8260 @ -762 (INIT 0x1934) … Ｚ
  0x8279 @ -737, ａ 0x8281 @ -736 … ｚ 0x829A @ -711 (INIT 0x1CC2). 62 celdas
  contiguas. Antes: < > $ % & (rel -777..-773); después: kanji.
- **16 celdas HIJACK** (código → celda, todas exactas): 0x95FB→+510(0x72AC),
  0x9660→+526(0x73CC), 0x966B→+529(0x7402), 0x967B→+531(0x7426), 0x9682→+534
  (0x745C), 0x96AF→+550(0x757C), 0x96B3→+554(0x75C4), 0x96BD→+557(0x75FA),
  0x96C5→+561(0x7642), 0x96DA→+568(0x76C0), 0x9744→+584(0x77E0),
  0x9755→+592(0x7870), 0x975C→+599(0x78EE), 0x975F→+600(0x7900),
  0x976C→+606(0x796C), 0x9770→+607(0x797E).

### Parche aplicado
- `recursos/tools/fuente_menu.py`: extrae los glifos 8×8 de David (R<50 sobre
  fondo magenta) y pinta 78 celdas en INIT y OPEN (glifo 8×8 centrado en
  (col 2, fila 2)): 16 HIJACK con los acentos (Á á É Í Ó Ú Ñ Ü ¿ ¡ é í ú ó ü
  ñ) + 62 fullwidth (0-9 A-Z a-z con los glifos de David).
- Integrado en reconstruir_iso.py (después del parche de START.BIN).
- **Rebuild [CAST].bin completado y verificado**: 30 celdas revisadas byte a
  byte en el bin raw final (todas OK), 術 intacta en las dos tablas.
  Preview: `preview_fuente_parche.png` (las 78 celdas a pintar).
- Pendiente: **David prueba [CAST].bin** (menú de velocidad: "Velocidad",
  "Rápido/Lento" con á de verdad, cifras 1-8; cualquier texto fullwidth).

### Errores y caminos muertos de este tramo
- Fuzzy 18B de Latinas sobre todo el ISO: MILARES de falsos positivos
  (umbral 22: 8400-14400 hits por glifo; el header LBA0 "apunta" a cualquier
  glifo raro; la celda rel -722 pareció 'l' y era ｏ). Inutilizable para
  localizar bloques: leer la tabla por densidad + tiras 16 celdas a 4×.
- Miniaturas de grid a 1px: me leí una fila de KANJI como "456789 ABCDEF..."
  (no es fiable para identificar filas; solo para localizar zonas).
- Empaquetado celda: 18 B = 144 bits CONTINUOS (bit = 12r+c), NO 2 bytes por
  fila (el primer celda12 generaba 24 B y escribía basura).
- Verificación del bin: el raw NO es base+off (cada sector crece 2048→2352);
  hay que mapear byte a byte con n*2352+16+r. Mi primer check "TODO XX" fue
  un bug del chequeo, no del parche.
- /tmp no persiste entre turnos (glifs.pkl perdido; regenerado).
- Agrupar bandas de una captura por "gap>20" fusiona filas (gap real 5 px);
  agrupar por y0 exacto.
- Los códigos SJIS de memoria mienten (confundí 冒/膨): siembre cp932.

## 18/09/26 (2ª parte) — La fuente del menú: el "SD" era un fantasma y el experimento discriminador

### Descubrimientos
1. **START.BIN boot**: tabla de carga en file 0x90-0x2D0: INIT.BIN → RAM
   $28000, CHR.BIN → ?, CHR1.BIN → $80000, SD.BIN → ?, otros → $50000.
   El loader jsr $10888 (nombre en a0, destino en a1). START → RAM $10000
   (los nombres de archivo se refieren como $1009C etc. = file+0x9C).
2. **Framework de menús** (START 0x18F0-0x1A32): 16 IDs de menú en $A240,
   layouts en $A260/$A2A0/$A2E0/$A320, y COPIAS completas de bitmap
   pre-renderizado (32KB/24KB/32KB) desde las tablas $11D28/$11D58/$11D88
   a frame buffers $AB000/$AE000/$B0000. El texto dinámico (mis plantillas)
   se dibuja encima con el motor de objetos ($C100 registros stride 0x50).
3. **GHEAD.BIN REAL = 3184 B** (mi "GHEAD_FULL 122880 B" era una extracción
   con el bug de sectores): es un script de inicialización de RAM (registros
   tag 0x33FC/0x23FC con direcciones $A1xx), NO un mapa de fuente.
4. **GENEI_OP/ED.DAT = movies** (446/241 KB). RLE naive y LZSS estándar
   (16K, ambas convenciones de flag, todos los starts 256B/16B) no producen
   la tabla de fuentes. Descartados como fuente del menú.
5. **EL FANTASMA DE SD.BIN**: "descubrí" que SD.BIN contenía una tabla de
   fuentes (術@36080, fw@22184) → pinté sus 78 celdas en el build. LUEGO:
   mi extracción de SD.BIN usó `iso[lba*2352+16 : +sz]` (la fórmula RAW)
   sobre el ISO de 2048 B/LBA → leí 76 KB desplazado = una ventana dentro
   de **OPEN.BIN** (artificialmente "SD+36080" = OPEN+0xA710 = la 術 de
   OPEN; "SD+22184" = OPEN+0x70C8 = fw de OPEN). SD.BIN real: NO es fuente.
   El build intermedio tenía 1362 B de BASURA en SD.BIN real → corregido en
   el rebuild final (SD restaurado byte a byte ✓).
6. **Verificación con extracción correcta (por sectores)**: el build actual
   tiene INIT 78/78 y OPEN 78/78 pintados de verdad (el "32/32 verificado"
   del build anterior se hizo con lectura continua = no fiable, aunque el
   build era correcto porque el builder escribe sector a sector).
7. **PRUEBA DECISIVA — búsqueda exacta de los glifos renderizados**:
   decodifiqué 20 glifos del screenshot de David (V e l o c i d a R p d L e
   1-7) de /tmp/glifs.pkl (4× zoom, 44 px = 11 filas + fila 11 vacía) a
   12×12 → 18 B (144 bits MSB, todas las shift de columna) → búsqueda
   exacta en los 167 archivos del disco: **los 20 bitmaps SOLO existen en
   INIT.BIN, OPEN.BIN y GFONT.BIN**. Ningún otro archivo del disco los
   contiene (ni CHR/CHR1/SD/MSTART/SSTART/OSTART/H01/H02/GENEI).
8. **GFONT fw (celdas 50-111) == INIT fw: hamming 0** (mismo diseño Latin).
   GFONT NO tiene celda 膨 (mejor celda: 37 bits de 144; celda 431 = 冒).
   El menú muestra 0x9660 como 膨 ⇒ **el menú lee INIT u OPEN** (GFONT
   descarta). Y sin embargo pintar INIT+OPEN no cambió nada en el menú.
   Paradoja abierta → experimento discriminador.

### Experimento discriminador (build actual, para David)
Cada tabla recibe un diseño DISTINTO en las 62 celdas fullwidth (+16
HIJACK en INIT/OPEN):
- **INIT**: diseño normal de David (Lord Monarch 8×8) — 78 celdas.
- **OPEN**: TODAS las 78 celdas = glifo **8**.
- **GFONT celdas 50-111**: TODAS = glifo **3**.
Interpretación del screenshot del menú de velocidad:
- Latin de David + 膨 en el acento → lee INIT (y habría que buscar por qué
  el build anterior no se veía: ¿bin/cue equivocado? ¿pantalla distinta?).
- Todo a 8 → lee OPEN.
- Todo a 3 → lee GFONT (improbable por el 0x9660).
- Sin cambios (Latin original + 膨) → NINGUNA de las tres: entonces o el
  bin/cue de David no es el que creemos (proceso) o la tabla se genera en
  RAM desde una fuente comprimida no localizada.
Verificado en el bin final: INIT 78/78 David, OPEN 78/78 "8", GFONT 62/62
"3", SD.BIN intacto, 術 intacto, sha [CAST].bin == (Track 01).bin.

### Errores de este tramo (los malos)
- **Extraje SD.BIN (y casi GHEAD) con la fórmula RAW sobre el ISO**:
  lba*2352+16 sobre un ISO de 2048 B/LBA desplaza 304 B por cada LBA →
  "SD.BIN" era en realidad OPEN desplazado. Todo el "descubrimiento de SD"
  era un artefacto. (NORMA 30)
- Comparé bin-vs-ISO con slice continuo (misma familia de bug, dirección
  contraria) → "164/167 archivos distintos 94%" falso alarmón: con
  extracción por sectores, bin == ISO (misma imagen). (NORMA 24, reforzada)
- Dos scripts Python con líneas basura dejadas (sintaxis) — revisar antes
  de ejecutar heredocs largos.
- `0x8C60`/`0x8CE0`/`0x8CF0`: tres conversiones dec→hex erróneas seguidas
  (36080 = 0x8CF0). Verificar con `hex()` siempre.
- El (1,1) de /tmp/glifs.pkl NO es 膨: es el borde del selector (3 px).
  El glifo 膨 no está limpio en la captura.
- La "verificación 32/32" del build anterior usaba lectura continua: no
  confiable (aunque el build era correcto).

## 2026-09-19 — Sesión: fuente confirmada + lote de menús (magia/equipo/principal)

### Contexto
David confirma (mensaje 18/09-19/09): "Ahora sí se ve la nueva fuente" con á
accentado en "Rápido" => **EL MENÚ LEE INIT** (experimento discriminador
resuelto). Pedido: cerrar el lote de menús (magia, equipo, sistema, principal)
antes de seguir con más.

### Hecho
1. **Parches aplicados a START_CAST.BIN (zona 0x17500-0x177AE, plantillas
   vivas — verificadas: son las ÚNICAS copias de los textos en el archivo):**
   - P1 @0x1758A (Z5 cabecera, 32B): `［Ｍａｇｉａ］`+8sp -> `Ｍａｇｉａ：`+9sp.
     Corchetes fuera (fuente de David no los tiene) y colon FULLWIDTH 8146
     (glifo original del juego; la fuente de David NO tiene ： ni ［］).
   - P2 @0x175F2 (Z5 L5, 38B): el campo valor ００ de Grp se mueve de celdas
     10-11 a 13-14 y la etiqueta Ｇｒｐ de 13-15 a 10-12 => "Grp 8" alineado
     con "Ind 2" (celdas 10-14). MISMA LONGITUD.
     **RIESGO DOCUMENTADO:** la sesión anterior mapeó writes de valor en
     RAM absolutos (lea 0x11E98, jsr $186D6) para grp2. Si el engine escribe
     el valor en offset fijo (no escanea el placeholder), el "8" saldría en la
     posición vieja (sobre "Ｇｒ"). El build anterior mostraba el valor
     EXACTAMENTE donde está el placeholder en el archivo (coherencia), lo que
     sugiere que el placeholder manda. David lo confirmará con captura.
   - P3 @0x13E70 (cabecera equipo, 16B): `［Ｅｑｕｉｐｏ］` -> `Ｅｑｕｉｐｏ`+2sp
     (el box tiene 6 celdas: "[Equipo" se cortaba a "[Equi").
2. **Rebuild + verificación por sectores**: [CAST].bin con START ==
   START_CAST (P1/P2/P3 presentes), INIT 78/78 celdas David (celda á rel+526
   celdas = blob David exacto), GFONT celda 50 OK. NOTE: "rel" de fuente_menu
   va en CELDAS (×18B), no bytes.
3. **Mapa de la zona de plantillas 0x13DEA-0x14472** (EFG/IT/SY):
   - 0x13DF3 ［術効果］ + 個別/集団; 0x13E2B ［アイテム］ + 使用/入替/捨てる
     (plantillas ORIGINAL japonés, sin traducir aún).
   - 0x13E6D ［Ｅｑｕｉｐｏ］ (ahora sin corchetes) + líneas de stats YA en
     español: Arma At ＋０００ / Prot De / Otro Vl / Otro Sk ０００％ /
     Otro Ac ０００％ (hechas por la sesión anterior).
   - 0x13F67 tabs: Ｃｈａｒ / Ｔｅｃ / Ｃｏｍｂ.
   - 0x13F8A (338B) template Ficha: ＮＶ/ＥＸＰ/Ｎｅｘｔ/ＰＶ/ＰＭ ya en
     español; **attack/defense/agility labels siguen en japonés** (攻撃力/
     防御力/素早さ/スキル/命中率).
   - 0x140DE (392B) tab Técnicas: cabeceras de columnas de armas: Ｇｕ /
     **ライフル** / 砲 / **ヘビー** / **クロー** / **杖** / **剣** / **斬糸**
     (6 de 8 en japonés; la sesión anterior tradujo solo los que cabían).
   - 0x14268 (360B) tab Combate: 攻撃力/防御力/素早さ japoneses + PV/PM ok.
   - 0x143D7: "…スピード" (-Speed) + "スイッチ" (system: Switch).
   - 0x13D18-0x13D5F: tabla de 6 mini-plantillas con descriptors [02 XX YY]:
     "　術" / " ﾁﾃﾆﾃ" / "　技巧" / "　効力" / "　Ｅｆｅｃｔｏ" (traducida) /
     " ﾖﾘﾃ" => pantalla de efectos de magia (術効果). El 術 de 0x13D32
     ES de esa pantalla, NO del menú principal.
4. **Búsqueda agotada de la fila 術 del menú principal**:
   - 術 (97 64) en todo el disco: solo zonas de fuentes + dialogs + movies.
   - 魔術 / ステータス / アイテム / エクイップ / 会話: NO existen en NINGÚN
     archivo del disco.
   - "Ficha" (fullwidth y ASCII): NO existe en el disco.
   => las filas no traducidas del menú principal (術 y la de "Ficha") NO son
     texto de plantilla: probablemente **bitmaps de layout pre-renderizados**
     (los 32KB que el engine copia a $AB000/$AE000/$B0000). BLOQUEADO hasta
     tener la captura de David del menú principal y poder analizar el
     bitmap. (NOTA: 0x11D28/0x11D58/0x11D88 = CÓDIGO, no tablas de punteros:
     la interpretación anterior de "layout pointer tables" era errónea.)
5. **Nombre 天人 (Tianren) — fuente común localizada pero cirugía RIESGOSA**:
   - Tabla maestra de nombres INIT 0x22900-0x22CA0: entradas variable largo
     NUL-separadas (el lector debe ser secuencial: coexisten entradas de 4B y
     26B). Primera entrada inline = 天人 @0x22918 (marcador `00 80` + nombre).
     Resto: 美紅/ホウメイ/シュウ老師/アイザック/カッシュ/薬師カイ/リー/…
     (todos los nombres del juego, ya que los dialogs usan nombres inline).
   - Verificado: NINGÚN puntero 24-bit ni 32-bit apunta a 0x22900-0x23000 en
     INIT/START/OPEN/GHEAD; los registros de personaje (0x1B00-0x22000) no
     apuntan a la zona de nombres.
   - PERO: la cola del archivo está LLENA de datos (dialogs hasta el último
     byte) => no hay 10 B libres para compensar el alargamiento 天人(4B) ->
     Ｔｉａｒｅｎ(14B). Alargar = desplazar ~4.7KB de INIT y romper referencias
     que no he logrado localizar. **A POSPONER: decisión de David.**
   - ADEMÁS: el mapa de la sesión anterior dice que el nombre del menú de
     magia copia "máx d2=5 chars desde $bd00" => "Tianren" (7) se truncaría
     a 5. Opciones: "Tian" (4, cabe), aceptar truncado, o dejar 天人.
6. **Iconos de estado de equipo 忌/瞬/哀/僕/渡**: no son texto en ninguna
   plantilla del disco => también bitmaps/layout. BLOQUEADO igual.
7. **Espaciado de la fuente latina (queja de David)**: causa confirmada =
   glifos 8x8 centrados en (2,2) dentro de celda 12x12 => margen 2px por lado
   => hueco de 4px entre letras ("I L L U S I O N"). Generado
   /home/user/illusion-city/preview_espaciado.png: fila 1 = actual (8x8
   centrado), fila 2 = escalado 8x8->12x12 (rellena celda, letras pegadas).
   Pendiente decisión de David (escalar / dejar / mandarme glifos 12x12).
8. **Vocabulario pendiente (pedir a David)**: labels de stats de Ficha
   (攻撃力/防御力/素早さ/スキル/命中率) y columnas de armas (ライフル/砲/
   ヘビー/クロー/杖/剣/斬糸) — en la zona 0x13F8A/0x140DE, con anchos de
   celda limitados (3-4 celdas por label).

### Errores de este tramo (los malos)
- **Confundí ０-９ fullwidth**: ０=824F, １=8250, ２=8251 — el campo "０００"
  es 824F 824F 824F. Dos asserts fallaron por escribir 8250/8251 "de
  memoria". (NORMA 34)
- **Corte de bytearray con reemplazo más corto**: al parchear P1 usé
  Ｍａｇｉａ=12B (son 5 chars = 10B) y asigné 30B a un slice de 32B:
  el bytearray en memoria se encogió 2B y corrompió lecturas posteriores
  (el disco NO se tocó porque el assert de P2 falló antes del write).
  Siempre: assert len(nuevo) == len(slice). (NORMA 37)
- **Leí mal el hex volcado**: "0x143EE Z22" (mapa anterior) es un bloque de
  CEROs de 128B, no una copia de la plantilla; Z22/Z5 solo existen en la zona
  0x17500-0x177AE (confirmado con find de cada palabra).
- "rel" de fuente_menu.py = celdas, no bytes (el spot-check á falló usando
  +526B en vez de +526×18B).
- /tmp no persistente: no usar para datos entre sesiones (recordatorio).

## 2026-09-19 — Turno: build v2 (headers "de", Magia fila 1, Ficha restaurada)

### Pedido de David (verdict v1)
Headers "Magia de <nombre>" / "Equipo de <nombre>" (sin colon); Grp roto
("8rp00") — 8 debe ir celda 14 bajo el "2" de Ind, label Grp celda 10
bajo Ind, azul; Tianren COMPLETO obligatorio; no escalar 8->12, preguntar
por celdas 8x8; sistema: ensanchar caja no acortar palabras; menú
principal: 術->"Magia" + todo a celda 1 (sin margen); $ y # va a la PNG.

### Hecho
1. **TABLA DEL MENÚ PRINCIPAL DESCODIFICADA** (START 0x13D00-0x13D61):
   - 0x13D00: header `01 00` + serie `07 06 05 04 03 02 01 00 00` (9 u8) +
     `02 04 00 00 00 04 06 00`.
   - 0x13D12-0x13D29: **6 entradas de 4B = offsets $2xxxx (file+0x10000)**:
     $23D2A 術(r1) | $2773E Ojetos(r2) | $2774D Equipo(r3) | $2775A Hablar(r4)
     | $23D4A Ficha/Efecto(r5) | $27767 Sistema(r6). Mis 4 strings de
     0x1773E alimentan r2/r3/r4/r6 (hipótesis confirmada).
   - Pool de strings 0x13D2A-0x13D5F: 術 / ﾁﾃﾆﾃ / 技巧 / 効力 /
     Efecto(=exステータス→Ficha lote1) / ﾖﾘﾃ (variable, NUL-terminadas;
     las 4 katakana/技巧効力 = otra pantalla, NO tocadas).
   - Bloque de ceros 0x13D60-0x13DED = zona libre para strings nuevas.
2. **Ficha RESTAURADA**: 0x13D4A estaba "Ｅｆｅｃｏ" (sobrescritura de sesión
   anterior para la pantalla de efecto de magia). El menú principal muestra
   r5 = esa string (prueba: captura de David vieja con "Ficha" + CSV:
   0x13D4A = única "Ficha" del juego). Revertida a "Ｆｉｃａ" (12B, misma).
   Riesgo conocido: si la pantalla 術効果 usa la misma string, mostrará
   "Ficha" en vez de "Efecto" (la palabra ORIGINAL era ステータス; aceptable).
3. **Fila 1 術->"Magia"**: string nueva "Ｍａｇｉａ"+NUL en 0x13D60 (bloque
   ceros), entrada 0x13D12: $23D2A->$23D60 (4B). Sin espacio inicial: la
   fila 術 se dibuja ~1 celda a la izquierda que las otras (medido: 術 en
   x76-88 = celda 0; las demás en celda 1) => "Magia" queda en celda 0-4
   (cabe en el interior de 6 celdas). El shift de r2-r6 a celda 0 sigue
   pendiente = parche de código (renderer, no hay X por fila en los datos).
4. **Headers "de"** (MISMA LONGITUD, verificados en .bin):
   - Magia 0x1758A (32B): Ｍａｇｉａ：+9sp -> Ｍａｇｉａ sp ｄｅ +7sp.
     El nombre 天人 lo dibuja el engine en celda 8 => "Magia de 天人"
     (Tianren completo = celdas 8-14, desborda 3 celdas el box de 12).
   - Equipo 0x13E70 (22B): Ｅｑｕｉｐｏ 2sp+8NUL -> Ｅｑｉｐｏ sp ｄｅ +4NUL.
     En la captura 202054 NO aparece ningún nombre en esta cabecera
     (box ~13 celdas, texto 4) => sin colisión esperable.
5. **GRP — resolución final del mecanismo** (sin parche de código posible
   hoy): el write del valor es a **offset de byte FIJO dentro de la línea
   (byte 24 de L5 = celdas render 9-10, máx 12)** — demostrado por
   aritmética de plantilla (el "8" cayó sobre la G en 3 layouts distintos).
   "Grp" bajo "Ind" (celdas 9-11) + "8" bajo "2" (celdas 13-14) es
   IMPOSIBLE sin parchear el código (el write nunca puede llegar a 13-14).
   **Revertido P2** (0x1760A+14B): layout original => "8  Grp" como el
   japonés (coherente, sin "8rp00"). El "Grp 8" alineado queda para el
   pase de disassembler del renderer (junto al shift del menú principal y
   el ensanche de cajas).
6. **Mediciones (256x224)**:
   - Sistema 201923: caja x51-139 (interior 7.2 celdas) x y33-73 (3 líneas
     de 12px). Opciones japonesas originales = 9 celdas (también se
     desbordaban ~2); mis españolas 13-16 => 2 líneas cada una => caja de 3
     líneas corta las continuaciones (lo que ve David). Ensanchar = editar
     el bitmap 256x128 1bpp del layout (tablas $11D28/$11D58/$11D88 =
     file 0x1D28/0x1D58/0x1D88; sources 32/24/32KB -> $AB000/$AE000/$B0000;
     loop copier 0x198A; tipos del record $4). Pendiente identificar qué
     bloque 32KB es el menú de sistema.
   - Equipo 202054: caja superior x8-165 (~13 celdas), cabecera y16-26,
     4 celdas de texto.
   - Magia 013517: "8rp00" visible (confirmado el bug P2); header
     "Magia: 天人" celdas 0-6 + nombre celda 8-9; box 12 celdas.
   - Z19 Ficha: filas stats = label 3 kanji (celdas 0-2) + 2sp + valor
     ０００＋０００ (celdas 5-10, WRITES FIJOS); EXP/Next/PV/PM usan celdas
     8-14 => box >=15 celdas. Vocab aprobado NO CABE en 5 celdas de label:
     Ataque(6) Defensa(7) Velocidad(9) Habilidad(9) Precisión(9) — todos
     desbordan hacia el valor fijo. Opciones: parchear los 5 writes de
     valor (pase de código) o abreviaturas.
7. **Build v2**: reconstruir_iso.py desde original: ok=147 no_cabe=329
   (idéntico a v1), START LBA59, INIT 78 + OPEN 78 + GFONT 62. Verificados
   en el .bin final los 6 parches (find de cada secuencia): OK 6/6,
   "Efe..." viejo ausente. [CAST].bin 18,444,384 B.

### Errores de este tramo (los malos)
- **Búsqueda de strings con los códigos de fullwidth MALOS**: busqué
  Ｍａｇｉａ con 82C9/93FC/82EA/828F (bloque de GFONT) y encontré 0 hits en
  todo el disco; las plantillas de START usan el bloque SJIS 8260-8279
  (Ａ-Ｚ) / 8281-829A (ａ-ｚ) / 824F-8258 (０-９) y 8146 (：). Los hits de
  "no está literal en el disco" de sesiones anteriores para 術/ステータス
  siguen siendo válidos, pero CUALQUIER búsqueda futura de texto fullwidth
  debe usar 8260-829A. (NORMA 38)
- **Confundí RAM con file en $11D28**: lea $11D28 = file 0x1D28 (START va a
  $10000). Volqué file 0x11D28 (código) y saqué conclusiones sobre "tablas
  runtime" basadas en código. Los 3 volcados "de tablas" de esta sesión
  (0x11D28-0x11DA8 "u32 jumble") eran CÓDIGO de START. Las tablas 0x1D28/
  0x1D58/0x1D88 SÍ contienen datos (entries con 0x0800/0x0900/... low-16)
  pero no las decodifiqué bien (parecen offsets low-16 + high-16 flags).
- **Los "jsr $186D6 / $2087E / $17FD8" del mapa anterior NO existen en
  ninguno de los archivos del disco** (buscados como 16b y 32b en los 167
  archivos). Ese mapa de addresses de writes fue una lectura errónea de la
  disassembler previa; el mecanismo real de los writes de valor sigue
  SIN ENCONTRAR (solo probado el de Grp: byte 24 fijo de la línea).
- **P2 no era viable**: mover placeholders no mueve writes (confirmado
  aritméticamente y con la captura de David). P2 revertido. (NORMA 39)

## 2026-09-19 — v3: dictamen 10 puntos de David

### Investigación Z5 (rompimiento)
- La zona Z5 (0x1758A) se carga en código: 0x11DE8 `move.l #$2758A, $22(a0)` (a0=$A4200, struct de pantalla en $A4222). El renderer recorre líneas delimitadas por /n (2F6E); las líneas PM Coste/Ahora/Max no tienen refs propias.
- Writes de valores (función @0x11DC6, desensamblos capstone):
  - Nombre: jsr $2087E (copia NUL-terminada (a0)→(a1), **sin límite de longitud**), a2=$2759A (celda 8), d2=7.
  - Ahora: rec(a4)+$48 → lea $275DA (０００ tras "Ahora") ✓ correct.
  - Ind: lea $275EC (００ tras "Ind") ✓ correct; 2 dígitos (decenas celda 12, unidades celda 13; "2" va en celda 13).
  - Max: rec+$46 → lea $27600 (celda espacio).
  - **Grp: lea $27608 → write 2 dígitos en 0x17608 (tens, sp) y 0x1760A (units, ¡sobreescribe el &5 azul!)** → explica el bug v2 "80 Gr + p desborda".
- Writers de dígitos: $186D6 = 2 dígitos (espacio si <10), $18722 = 3 dígitos, derecha, llevan 8140 de relleno.
- **Menú principal**: filas referenciadas por tabla 0x13D12 (6 u32 $2xxxx); setup @0x21996 (a0=$A4200: $28=6 filas, $26=1, $8=10, $A=9, $1E=$A6000); renderer genérico $172A6 → draw $174F4 → por fila bsr $1838C (intérprete: /n=reset X +Y, &=color, #/opcode, $/opcode, resto=glyph vía $18B18 que hace $14+=3 por char). **NO HAY CLIP en el código**: las 7 letras de "Sistema"/"Objetos" se dibujan completas (x74-153); el "resto cortado" que ve David = la 7ª letra solapando el panel azul decorativo (x145+). Las filas YA están en celda 0 (sin margen izquierdo). **No se parchea el shift** (innecesario).
- **Equipo**: el nombre se dibuja FIJO en celda 6 (sobrescribe la plantilla) ⇒ "Equipo de" imposible; revertido a Ｅｑｉｐｏ+2sp (look original JP).
- **Nombres**: tabla INIT 0x22919+ variable NUL-sep (天人 5B con flag 0x80, 美紅, ホウメイ, シュウ老師, アイザック…). Copia nombre = NUL-terminada sin límite. Expandir 天人→Tianren requiere mover la tabla (refs por offset) — pendiente.

### Parches v3 aplicados (START_CAST.BIN)
1. 0x13D4B 8264→8265 (Ficha; yo escribí E en v2).
2. 0x13E70: revertido a Ｅｑｉｐｏ+2sp+8NUL (24B).
3. 0x175F0 (40B): L4 = `/n &5 Ｍａｘ sp sp &7 ０００ sp &5 Ｇｒ ００ sp sp` + NUL 0x17618-19 intacto (Efecto 0x1761A no se mueve). + **código 0x11E9D 08→12 (lea $27608→$27612)**: "8" en celda 13 bajo el "2" de Ind; "Grp" azul celdas 9-11 bajo "Ind".
4. Z19: 攻撃力→ＡＴＡ (0x1404C), 防御力→ＤＥＦ (0x1406A), 素早さ→ＶＥＬ (0x14088), スキル→ＨＡＢ (0x140A6), 命中率→ＰＲＥ (0x140C8). Todos 6B→6B.

### Errores propios (regla: script atómico)
- Varios scripts murieron en asserts tras aplicar parches en memoria y antes del write → cambios perdidos (Ficha/Equipo/L4/lea 3 veces). Lección: validar TODO primero, escribir UNA vez.
- Slices con offsets mal calculados (0x13D4C vs 0x13D4E; 0x11EA2 vs 0x11E9E) → asserts falsos.
- (0x27612).to_bytes(2) → overflow (escribir solo el byte bajo).
- L4 original = 40B (no 44): contar bytes, no suponer.

### Pendiente v3 (siguiente build)
- Título "Efect" → &4 amarillo: requiere +2B en la línea Efecto (0x1761A) y desplazar Ind/Grupo/Item/Combate/VR/mainmenu4 → actualizar todas las refs u32 en rango $2761A-$277AE (incl. tabla 0x13D12). A valorar.
- Tianren en la tabla de nombres (mover/expander en INIT 0x22919).
- Reexplicar $/# a David (fila 5 cols 13-14 de su PNG).
### Verificación en [CAST].bin (raw)
Fórmula raw confirmada: `raw = (59 + off//2048)*2352 + 16 + off%2048` (LBA 59 = START).
- Tabla menú 0x13D12 → raw 0x38982: 6 entries correctos.
- Ficha → raw 0x389BA: 82 65 82 89... = Ｆｉｃｈａ ✓ (original tenía otros strings, p.ej. スイス).
- lea → raw 0x36648: 45 f9 00 02 76 12 ✓.
- L4 → raw 0x3CAB0: layout nuevo ✓ (original 0xFF).
### Corrección post-build (lea Grp)
El write de 2 dígitos pone TENS en (a2) y UNITS en (a2+2). Para alinear el "8" (units) bajo el "2" de Ind (units @c13), a2 debe ser la CELDA 12 = file 0x17610 = RAM $27610. El parche inicial ($27612) dejaba el "8" en c14. Corregido 0x11E9D: 12→10. Rebuild + verificado raw.
(Nota: el check "Efecto intacto" falló por bytes esperados mal escritos en mi check; la string ８２６４８２８６… = Ｅｆｅｃｏ está intacta en file y raw.)

## 2026-09-19 (2ª tanda) — v3.1: Equipo de, Efecto amarillo, Grp blanco

### Cambios aplicados (todos en un solo write atómico)
1. **Grp valor blanco**: L4 = `/n &5 Ｍａｘ sp sp &7 ０００ sp &5 Ｇｒ &7 ００ sp NUL` (40B). El valor Grp heredaba el azul de &5; ahora &7 blanco antes de ００. lea $27610 sin cambios (tens c12, units c13).
2. **"Equipo de <name>"** (David: nada es imposible):
   - Header 0x13E70 (18B): `Ｅｑｕｉｐｏ ｅ`; nombre ahora celda 9 (0x13E80), antes celda 5 (sobrescribía el ｏ → "Equip天人").
   - Mudanza: sp-line/Arma/Prot/Otro×3 (0x13E88-0x13F5D) → 0x17800-0x1792B (zona 0xFF); NUL-fill 0x13E82-0x13F5D (246B de margen para nombres largos).
   - Tabla 0x13E54: $23E70 $27800 $27803 $2783D $27877 $278B1 $278EB.
   - 11 lea's parcheados (5 nombres de item + 5 valores + nombre char): $23E80/$2780B/$27845/$2787F/$278B9/$278F3/$27825/$2785F/$27899/$278D1/$2790B.
   - Nota: "Arma/Prot/Otro" son ASCII (41 72 6D 61), no fullwidth; se movieron byte a byte (contenido intacto).
3. **"Efecto" amarillo &4**: inserción 2B (26 34) @0x1761A + shift +2 de la zona de strings 0x1761A-0x177AD → 0x1761C-0x177AF + **45 refs u32 actualizadas (+2)** (tablas: battle 0xEFA0-0xF0FC ×24, sistema 0x14472-0x1447A ×3, effect 0x13DEA-0x13E2A ×11, main menu 0x13D16-0x13D26 ×4, otros 0x10924-0x10DA6 ×6). Verificado: 45 hits, todos en tablas de punteros.

### Investigaciones
- **Menú principal 15px**: NO HACE FALTA / IMPOSIBLE a texto: filas en X=3 ($32(a0)=3 en el setup 0x219C0) = x74; marco caja x70 → solo 4px de hueco. X=0 sería x62 (fuera de la caja). El renderer NO hace clip ($18B18 dibuja todo); el "problema" real = la 7ª letra de "Objetos"/"Sistema" (x146-154) solapa el panel azul decorativo (x145-165) que es ART (el buffer $A6000 se limpia a $A500 cada frame con $17680; caja/panel = fondo VDP, no buffer). Solución = mover el panel en el art, no el texto.
- **$ y # NO SON GLIFOS**: en $191BE (SJIS→celda) los códigos 0x23/0x24 caen en el mismo índice 0x1500 (colisión ASCII); en $1838C se consumen como opcodes (& color, #N etiqueta, $ valor). **Retractada la petición de añadirlos al PNG** — David no tiene que añadir nada.
- **Función equip completa** @0x12838-0x129F0: setup $28=7 filas, $1E=$A7AE0 (bitmap propio, no $A6000), 11 writes de nombre/valores.
- **$195A8**: construye en $BD00 una lista de punteros (nombre char) desde tabla $A600; $1960x variantes para items.

### Errores
- Header "Ｅｑｕｉｐｏ ｄｅ" = 18B (9 chars), no 24: contaba mal.
- Check "Arma nueva" esperaba fullwidth; el string original es ASCII.
- Sandbox reset: uploads/ vaciado (PNGs perdidos) — pedir reenvío de 030441 y 034542.

### Pendiente
- Menú sistema: re-medir 034542 (perdida) + ensanchar caja.
- Tabla de nombres INIT (天人→Tianren): expandir/mover + refs.
- Panel azul del menú principal (art) si David lo quiere.

## 2026-09-19 (3ª tanda) — v3.2: fixes de las 2 regresiones + shift menú

### Regresiones v3.1 (diagnosticadas y corregidas)
- **Grp "80" azul**: mi lea $27610 apuntaba al &7 (26 37) que yo mismo metí; el write 2-dígitos lo sobrescribió con sp y el "0" restante (celda 13) + color azul heredado = "80" azul. Fix: lea → $27612 (0x11E9D: 10→12) = primer ０ del campo.
- **"Equipo d天人"**: offset mío: "Ｅｑｕｉｐｏ ｄｅ" = 18B = celdas 0-8 → celda 9 = 0x13E82 (no 0x13E80, que era la ｅ). Fix: lea 0x12855 80→82 (ojo: target = 0x12852+4B; escribí el byte 0x12854 por error la 1ª vez → $8280; corregido).
- **Líneas item "cortadas"**: NO diagnosticado (capturas nuevas 045122/045315/050156 NO llegaron a uploads/). Verificado: las líneas movidas son byte-idénticas en file y raw; el write de nombre/valor apunta a la misma posición relativa (+8/+34); hay un 2º borrador de nombres ($227F2) con lea's a posiciones antiguas (ahora zona NUL, inocuo). Pendiente: captura nueva de equip.
- **Efecto blanco + muesca en E**: NO diagnosticado (captura 050156 no llegó). &4 insertado correctamente (verificado raw). Hay 162 instrucciones `move.l #$23DEA, ...` → 0x13DEA es tabla genérica multi-pantalla; el renderer de la caja de efecto puede no interpretar & (por eso sigue blanco). Pendiente: captura.

### Menú principal 15px
- Aplicado $32(a0) 3→0 (0x119C2): texto 12px a la izquierda (celda completa; la rejilla es de 4px/celda=12px por char, 15px no cae en la rejilla; 12px es el máximo hacia la izquierda sin salir de X≥0).
- David contó px en resolución real: la ventana tiene margen; el límite real no es el x70 que medí antes (probablemente marco interior decorativo).

### Lección
- Al insertar bytes dentro de una línea, recalcular los offsets de write que caen DESPUÉS de la inserción (el &7 de Grp empujó el campo ００ a +2).
- El target de un lea.l empieza en off+2; el byte bajo final está en off+5.

## 2026-09-19 (4ª tanda) — v3.3: menú 4px más a la izquierda (X=-1)

### Veredicto 4 (051810/052259/052743/053346)
- Grp **APROBADO** (un dígito blanco "8"). "Equipo de 天人" **APROBADO**.
- Shift 12px confirmado ("¿¡Ves como tenía yo realidad!?") → ahora pide **4px MÁS a la izquierda**.
- 's' de "Objetos" recortada 1-2px; 'O' con muesca (David cree que es la misma causa).
- Equip: filas de item todavía cortadas (052743). Efecto: título blanco + muesca en E (053346).
- Falta: nombres en latinos (Magia de Tianren) + nombres de magias del panel inferior.

### Parche v3.3
- **Menú: X = -1** (0x119C2-3: 00 00 → FF FF). Mecanismo: en $18B18, X=-1 (0xFFFF) → lsr#1 = 0x7FFF → lsl#5 = 0x1FFFE0 → **andi #$ffff (0x8B3E) trunca a 0xFFE0 = buffer base − 32B = exactamente 4px a la izquierda** (la rejilla es 4px/unidad X; 32B = 1 unidad). Paridad correcta (lsr de 0xFFFF deja C=1 → variante impar). Las demás X de la fila (2,5,8…) siguen siendo positivas y válidas → toda la fila se desplaza 4px.
- **Riesgo**: requiere que $A5FE0-$A5FFF (32B antes de la buffer $A6000) sea RAM libre; ningún lea/inmediato en el código referencia $A5Fx/$A5Ex (barrido hecho). Si en la próxima captura algo SE ROMPE en otra parte de la pantalla (corrupción), la causa es esa y se revierte a X=0.
- Rebuild ok=147 no_cabe=329. Raw verificado: X=317CFFFF0032 ✓, Grp lea $27612 ✓, name lea $23E82 ✓.

### Hallazgos de la forense (píxel a píxel, umbral >128 = texto; el texto es BRILLANTE 239 sobre 0)
1. **El menú/magia/equip NO usan la fuente de David.** Las 78 celdas en INIT 0x4ED0 (y OPEN 0xA710) SÍ están pintadas y correctas en el build (0/78 diffs) — pero solo las usa el menú de velocidad. El menú principal dibuja con la **fuente original del juego**: el S de "Sistema" del screenshot ≠ S de David (doble barra), etc. La rejilla del texto: glifo 8×8 en celda de 6px visibles, pitch 12px; **1 unidad X = 4px** (verificado: X 3→0 movió todo el menú, marco incluido, 12px entre 030441→051810).
2. **Resolver de glifos $191BE**: code SJIS → packed JIS (sub $922C) → idx = ((p>>4−0x200)&0xF00)×1.5 + ((p>>4)&0xF0)×1.5 + ((p>>2−8)&0x3C) → tabla u16 en $28000 (=[w0 máscaras, w1 sub-idx]) → offset u16 → glifo 8×8 (64 bits, 4 pares) en $294E0+offset. Blit $18B18: buffer celda 32B = 8px×2rows 2planos; offset = ((X>>1)+(Y>>1)×$8(a0))×32, truncado 16 bits; variante por paridad (4 rutinas 0x18B76/C32/CEE/DAA). Buffer menú = $A6000 (25 pantillas lo usan; setup 0x119F0).
3. **La tabla $28000/$294E0 se carga estáticamente (ningún código la escribe); su archivo origen NO está identificado**: los patrones 8×8 de S/M/O del screenshot (y 12×12, y LSB, y column-major) NO aparecen en crudo en ningún archivo del ISO → probablemente comprimida. Los u16 de la tabla del INIT file 0x8000 NO son la tabla runtime (colisiones de idx entre caracteres vecinos).
4. **Nombres de item del equip = DB en CHR.BIN** (copia en GENEI_OP.DAT): region 0xBFD3+ = ~120 nombres NUL-sep (ハンドガン@0xBFD3, スーツ@0xC503, etc.; listado completo extraído a memoria). No hay tabla de punteros en CHR.BIN (barrido de rachas de deltas) → candidatos: parsing secuencial o refs en otro sitio. **El equip muestra el japonés porque las strings de v3.1 (0x17800+) solo son las etiquetas de slot (Arma/Prot/Otro + ATA/DEF/VL/SK/AC), no los nombres.**
5. **Header de magia cortado** (052259): "Magia de 天人" se dibuja ~10px demasiado arriba; solo se ven los 2-3 px superiores de los glifos (el resto queda detrás del borde de la caja). En equip (052743) el mismo header SÍ se ve completo → el Y es distinto por pantalla.
6. El "panel azul" del menú que llevaba confundiendo = marco de selección alrededor de la fila resaltada (se mueve con la selección), NO art fijo.
7. 'O' del menú (x59-64, y55-61): 1 píxel falta en la esquina inferior-izda (x59,y60) respecto al glifo esperado; 's' (x120-125): fila superior (y55) ausente. Ambas son rasgos de la fuente ORIGINAL (su glifo), no del renderer — confirmación definitiva requiere la tabla runtime (punto 3).

### Pendiente (próxima tanda)
1. **Nombres de item en español** (CHR.BIN 0xBFD3+): reemplazo in-situ fullwidth a misma longitud (padding 8140) o variable si la DB se parsea secuencialmente — primero averiguar cómo se referencian.
2. **Efecto amarillo**: el &4 no se aplica (renderer de la caja puede no parsear &); hay que localizar el draw path de esa caja.
3. **Header de magia**: bajar el Y de esa fila (equipo sí funciona; magia no).
4. **Nombres latinos**: INIT 0x22919 天人→Tianren (+ magias del panel inferior de magia: 紫気/緑気/気功障/攻気/封気 → traducir; DB en CHR.BIN/GENEI).
5. Si la captura v3.3 muestra corrupción fuera del menú → revocar X=-1 (el margen $A5FE0 estaba en uso).

## 2026-09-19 (5ª tanda) — v3.4: revert X=-1 + limpieza workspace

### Veredicto 5 (061030 menú, 062356 magia)
- **X=-1 REVERTIDO** (David: "revierte"). Efectos vistos con X=-1: la M de "Magia" desaparece, la O de "Objetos" se corta más, la 's' igual de cortada + **restos de letras que se cortan a la izquierda reaparecen a la derecha** (wrap horizontal del VDP: las writes en $A5FE0-$A5FFF caen en otra región de pantalla). Conclusión definitiva: **$A5FE0-$A5FFF NO es RAM libre** — el margen no existe y X=-1 está descartado para siempre. X=0 es el suelo del grid.
- **"1px más" no es posible**: la rejilla del blitter es 4px/unidad X (32B/paso de buffer); no hay sub-pixel en este renderer. La solución real para la 's' = **ensanchar la ventana de texto** (regla de David: ensanchar caja, no acortar palabras) — hsize en la display list (driver MSTART), pendiente.
- **Corrección de David A (aceptada)**: el menú/magia/equip SÍ se dibujan con la fuente de David. Mi conclusión de "fuente original" era falsa: mis mediciones de glifo usaban umbral >128 y la paleta del texto tiene varios grises (64/80/112/160/239) → el shape "roto" del S/O era artefacto de umbral, no de fuente. La muesca de O y el corte de S/s = **clip por la ventana de texto** (franja derecha de la caja corta el 7º carácter de las filas de 7 letras: Objetos/Sistema).
- **Corrección de David C**: el header de magia se ve bien (062356). Mi análisis de "cortado" era el mismo artefacto de umbral. **No tocar.**
- 061030 corrobora la corrupción de X=-1 (filas del menú alteradas: "Halar", "Ficha", "Sistema" en posiciones raras).

### Cambios v3.4
- 0x119C2-3: FF FF → 00 00 (revert; estado = v3.2). Raw verificado ISO+RAW: X=317C00000032 ✓, Grp $27612 ✓, name $23E82 ✓. ok=147 no_cabe=329.
- **Limpieza workspace** (105→~56MB):
  - `track01_original.bin` (18M, duplicado de [ORIGINAL].bin; el script usa [ORIGINAL].bin).
  - `recursos/(Track 01).bin` (18M, salida redundante: el .cue carga [CAST].bin) + write desactivado en reconstruir_iso.py.
  - `recursos/track01_castellano.iso` (16M) + **ISO_OUT movido a /tmp** (intermedio, se regenera cada build).
  - `analisis/START_CAST_V3.BIN`, `analisis/SD.BIN.ok`, PNGs sueltos de root, screenshots viejas de uploads (quedan las de la 4ª/5ª tanda + fuente de David).
  - `recursos/track01.iso` se MANTIENE (input del pipeline).

### Estado de la cola (orden)
1. **'s'/'S'/'O' cortados** = ventana de texto estrecha para 7 celdas: localizar el hsize de la display list del menú (driver MSTART, entries construidos en runtime) y ensancharlo +1 celda (12px) sin romper el art de la caja.
2. Nombres de ítem en español (DB CHR.BIN @0xBFD3+, ~120 nombres NUL-sep; reemplazo in-situ fullwidth).
3. Efecto amarillo (el &4 no lo parsea ese renderer; localizar draw path).
4. Magias del panel inferior (紫気/緑気/気功障/攻気/封気 → DB) + nombres en latinos (INIT 0x22919 天人→Tianren).

## 2026-09-19 (6ª tanda) — v3.5: ensanchar ventana del menú ($04 7→8)

### Remediciones precisas (051810, umbral >150 = texto brillante)
- Celda = 12px desde x59; marco de la caja x142-143 (+línea exterior x145).
- **"Objetos s" (c6) = 4px (132-135) vs "s" referencia (Sistema c2) = 5px (84-88) → falta x136 = clip exacto de 1px.**
- "Sistema a" (c6) = 5px completo (131-135 = rel. 0-4, igual que la "a" de referencia). "O" (c0) = 6px (59-64): glifo completo (no hay clip a la izquierda; la ventana empieza ≤59).
- → El daño real = solo 1px de la "s" de "Objetos". El resto de glifos completos.

### Tabla de parámetros por pantalla (descifrada campo a campo)
- Formato: `31 7C 00 NN 00 DD` (6B) = valor NN×0x100 → $DD(a0); buffer: `21 7C imm32 00 1E`.
- **Menú (0x119A8-0x119F0):** $2A=0 $2C=0 $26=1 **$28=6 (nº filas ✓)** $32=X(0) $18=0 $2E=5 **$04=7** $06=5 $08=10 $0A=9 $1A=0x80 $1E=$A6000.
- **Screen B (0x11B1C-0x11B68):** $28=1 $2E=9 $04=3 $06=8 $08=26 $0A=15 $1A=0x8B00 $1E=$A6B00.
- Hipótesis geométrica: ventana = $04 celdas (7×12=84px, x51-135) y el texto entra con X=2 (8px) → primera celda x59 ✓✓. El 7º carácter (celda x131-142) queda a 1px del borde → clip en x136 ✓ consistente.
- SSTART.BIN = 68000: contiene setups de menú paralelos (inmediatos $A6000 en 0xAE4/0xE80/0xEC8/0xF14/0x2908) con struct (a1) y valores sin ×0x100.
- MSTART 0x1330-0x1368: bloque de boot con valores 0x85/0x87/0x8A/0x8B/0x8C/0x8F/0x90-0x92 (133-146) ≈ coordenadas X del borde derecho (0x8A=138 = X2+1 con offset de captura +2px) — **último refugio si la tabla (a0) no es la ventana; tocarlo = riesgo de romper el boot del CD (probar solo si no hay otra opción).**

### Cambio v3.5
- 0x119D5: 07 → 08 ($04 del menú: 7→8 celdas → ventana 96px, x51-147). Solo START.BIN (seguro). X=0 intacto.
- Verificado en ISO (/tmp) y en [CAST].bin @0x36182: 317C00080004 ✓.

### Si el veredicto dice "no cambió"
- Candidates en la misma tabla (1 build c/u): $0A 9→10, $08 10→11, $06 5→6, $2E 5→6.
- Después: bloques de MSTART (riesgo boot) — solo con aprobación expresa.
- Fallback textual (nunca tocar sin pedir): "Objetos"→"Objeto" (singular, NO es abreviatura) dejaría ambas filas a 6 letras.

## 2026-09-19 (6b) — v3.6: $08 = ancho de la ventana (80px -> 88px)

### Correciones a la remediencia (bug propio en la comparacion previa)
- La **"a" de Sistema (c6) TAMBIEN pierde x136** (y106,y107): su borde derecho termina en x135, no x136 como en la tabla. Mi comparacion de rejilla anterior la dio "completa" por un bug (no volverse a fiar de comparaciones sin ver volcados directos).
- Píxeles perdidos totales en el menú (volcado directo, no inferencia): **s (5,8)+(8,8) = (136,57)+(136,60); a (6,7)+(7,7) = (136,106)+(136,107); O (8,3) = (59,60)**.
- → **El borde DERECHO de la ventana = x135 (col 8 del 7º carácter se corta SIEMPRE, filas 1 y 5).** Confirmado clip real, no artefacto.
- La muesca de la O (59,60) es OTRO asunto: 1 píxel, no es borde (x59 se ve en y57-59 y en las filas 2-4 para E/H/F), estable entre builds y con selección en otra fila (030441).

### Descifrado de la tabla de parámetros (unidad = 8px, como el blitter)
- **$0A = alto de la ventana en unidades de 8px**: menú 9×8 = 72px = 6 filas×12px ✓✓.
- **$08 = ANCHO de la ventana en unidades de 8px**: menú 10×8 = 80px = x56-135 ✓✓ (borde derecho x135 ✓).
- $04 = nº de celdas a renderizar por fila (7): el parche 7→8 no cambió nada (no hay 8º carácter) ✓ consistente.
- $04 NO es X1 (si lo fuera, el parche 7→8 habría movido el texto 8px; no pasó).

### Cambio v3.6
- 0x119E1: 0A → 0B (**$08: 10 → 11 = 88px, ventana x56-143**). $04 revertido a 7. X=0 intacto.
- Verificado ISO + [CAST].bin @raw(0x119DE): 317C000B0008 ✓.
- La columna 8 completa (x136-139) del 7º carácter queda visible; la tinta real de s/a termina en x136 → sin solapar el marco (x142-143).

### Queda (próximo veredicto)
1. **Muesca O (59,60)**: si sigue (casi seguro, es otro mecanismo), opciones: (a) cirugía de glifo (mover (8,3)→(8,4) de la O; su diseño, pedir OK), (b) seguir buscando el mecanismo (arte de OPEN.BIN sobre el plano de texto / bits pegados buffer→VDP).
2. Nombres de ítem (CHR.BIN 0xBFD3+), Efecto amarillo, Tianren + magias (cola 2-4).

### Otros hallazgos de la tanda
- SSTART (68000) carga OPEN.BIN y SD.BIN al boot (strings en el código, 0x08A4+). SD 69194B / OPEN 69258B (tamaños reales del dir; los usé mal antes).
- El header de magia (062356) NO usa la tabla INIT: glifos de forma/posición distintas (filas y41-50, no y43-49) → renderer/fuente propios; NO tocar (aprobado por David).
- Tabla SD @0x8CF0: NO es la misma disposición que INIT (celdas != glifos) → la nota "SD misma disposición" era para otra zona (fw block @22184); no seguir por ahí.

## 2026-09-19 (7ª tanda) — v3.7: wrap de la caja de texto, parche en SSTART

### Modelo de David (aceptado, explica TODO)
- La caja invisible que contiene el texto tiene un límite de anchura; si una palabra lo supera, **lo que se excede pasa al lado contrario** (wrap; equivale a bajar a siguiente renglón con pitch mucho más ajustado que el visible).
- Evidencia: el menú del título (JP, 3 opciones largas) se forma en 6 líneas superpuestas y cortadas; también visto en otros menús.
- Solo Objetos y Sistema (las únicas palabras de 7 letras) pierden píxeles. La s pierde 2 píxeles en x136; el inferior, al hacer wrap, cae sobre el píxel de la pared de la O en (59,60) y lo BORRA (la muesca); el superior cae en zona sin tinta de la O (sin efecto visible). En Sistema: el rabillo de la "a" (x136) → el px que pierde la "S" izquierda, a la misma altura.
- Solo se necesitan 1-2px libres de anchura.

### Por qué mis parches anteriores no hicieron nada
- La tabla (a0) de START.BIN 0x119A8 = TABLA INACTIVA (muerta): parches $04 y $08 sin efecto ✓ consistente.
- La struct VIVA es la (a1) de **SSTART.BIN** (setup menú @0xE5E-0xE98: $22=$11068, $04=7, $06=14, $08=17, $0A=3, $1A=0x80, $1E=$A6000). Geometría: $04×8 = x56 (borde izq), $08×8 = x136 (borde der+1) → ventana x59-135 / 77px de wrap ✓✓.

### Cambio v3.7
- **SSTART 0xE6F: 11 → 12 ($08 menú: 17 → 18 = borde der x136 → x144; wrap 77px → 85px > 77 del 7º carácter ✓)**. 1 byte de diff en el boot file (verificado: diffs=[3695]).
- START_CAST.BIN: $08 revertido a 10 (tabla muerta; diff limpio = v3.2 + parches de textos).
- Pipeline: reconstruir_iso.py ahora inyecta analisis/SSTART_CAST.BIN @LBA43 (assert 32644B).
- Riesgo: SSTART = código de boot; si NO ARRANCA el juego → revertir el byte (el diff es 1 byte, trivial).
- Unidad = 8px (no "1-2px libres"): +1 unidad = +8px. Si no funciona, candidates: $06 (14), otros setups (a1) con $A6000 (call3 $08=30, call4 $08=28, setup1 $08=16) — probar 1 a 1.

### Pendiente tras veredicto
- Si la s/a quedan completas → la muesca de la O debería desaparecer por el mismo mecanismo (el wrap deja de caer sobre ella).
- Cola: 2) nombres ítem CHR.BIN 0xBFD3+; 3) Efecto amarillo; 4) Tianren + magias.

## 2026-09-19 (8ª tanda) — v3.8: desacoplar ancho de posición en SSTART

### Veredicto v3.7: RECHAZADO. "$08 solo" movió el bloque de palabras a la derecha (asimetría). David: "dejar el texto donde estaba; ampliar la caja, no mover el texto".

### Mecanismo (código, decodificado)
- Struct viva del menú = $A4200, montada por SSTART @0xE52. Renderer de texto = SSTART 0x11E9E-0x1243A (sistema /n # $ &; buffer $1E(a0)=$A6000; glifo 12×12; X+=3, Y+=3 por glifo/renglón = 12px).
- Blitter 0x123EE: `off = ((X>>1) + (Y>>1)×$8(a0))×32; off &= $FFFF; a4 = $1E + off`. Fila de buffer = $8 elementos × 8px = 136px. X en unidades de 4px.
- Initializer @0x1640: $0C(a0) = $04 + $8>>1 (flag bit3 de $00) → **la posición X del texto depende de $8** → por eso $08 solo movía el texto.
- 7º celda (x128-139) = elementos 16+17; el elemento 17 desborda la fila de 17 elementos → envuelve al inicio de la fila (modelo wrap de David).
- Nota: wrap medido x136→x59 (77px) NO cuadra con fila de 136px (136 mod 136 = 0 ≠ 59) → si la s se completa pero la muesca de la O persiste, la muesca tiene OTRA causa (investigar glifo O / borrado en render).

### Cambio v3.8 (2 bytes, SSTART menú)
- $08: 17→18 (0xE6F): fila de buffer 136→144px → la 7ª celda ya no desborda.
- $04: 7→6 (0xE63): compensa $C = $04 + $8>>1 = 6+9 = 15 = invariante → **el texto NO se mueve**.
- Verificado: diffs vs original = [0xE63, 0xE6F] solo.

### Si falla
- Texto movido → la fórmula $C no es $04+$8>>1 (re-decodificar 0x168A con desensamblador fiable; capstone falla con 43 F9/MOVE16).
- s completa pero O con muesca → la muesca es otro bug (font/borrado); buscar en el glifo O del INIT @0x1A38 y en el path de borrado (barra de selección?).
- Nada cambia → el ancho no es $8; buscar otro campo (VDP window, $26/$1C).

## 2026-09-19 (9ª tanda) — v3.9: START $08 10→11 (88px) — retry con verificación 1:1

### Contexto
- v3.5 ($04 7→8) y v3.6 ($08 10→11) se marcaron como "tabla muerta" tras veredicto "sigue igual", pero la medición 1:1 (051810.png 256×224) demuestra que **START.BIN @0x119A8 SÍ es la geometría viva**:
  - Frame naranja menú: x49 y x142 (interior negro x50-141, 92px)
  - $04=7 → left 7×8=56 (cerca de 50, margen 9px)
  - $08=10 → width 10×8=80 → right 56+80=136 → **clip exacto medido en x136** (s pierde x136, a pierde x136, O muesca por wrap)
  - $0A=9 → height 9×8=72px = 6 filas×12px ✓
- Por tanto $08=10 es el campo de anchura. v3.6 debió funcionar. Posibles causas del fallo previo: build no inyectado / SSTART solapando / medición errónea.
- SSTART $08=17 es de pantallas de error de backup RAM, no del menú principal (strings $11068 etc). Revertido a original 7/17.

### Cambio v3.9
- START_CAST.BIN @0x119DE: 31 7C 00 0A 00 08 → **31 7C 00 0B 00 08** ($08 10→11, 80→88px, right 136→144)
- $C = $04 + $08/2 = 7+5=12 invariante (10/2=5, 11/2=5) → **texto NO se mueve** (mismo centro)
- SSTART revertido: @0xE63 06→07, @0xE6F 12→11 (diff limpio solo START)
- Verificado ISO + [CAST].bin raw: 317c000b0008 ✓

### Qué mirar
1. s de Objetos completa (x132-136)
2. a de Sistema completa (x132-136)
3. O sin muesca (59,60) — si era wrap, desaparece
4. Texto NO movido (margen izq x59 igual)
5. Si sigue igual → la tabla viva es OTRA copia (buscar $A6000 con $28=6 y $04=7 duplicada) o el VDP window es independiente.

# NORMAS del proyecto (nacidas de errores reales)

Reglas de obligado cumplimiento. Cada una cita el error que la motivó.

## Texto y plantillas
1. **NUNCA cambiar la longitud de una línea de plantilla sin actualizar TODAS
   las referencias absolutas** (lea/move inmediatos en código Y tablas de
   datos) que caigan dentro de la zona desplazada.
   → Error: Z5/Z19/Z21 de la sesión 1 cambiaron largos de línea; en juego los
   valores numéricos se escribían sobre las etiquetas.
2. **Un escaneo de u32 da FALSOS POSITIVOS**: una secuencia `XX 2C 00 02 43 YY`
   (move.w $2(an) + lea.l) o `61 00 02 44 4A` (bsr + tst) o `02 44 00 FF`
   (andi.w #$ff) se lee como u32 0x0243xx/0x0244xx sin ser referencia.
   → Error: casi se "parchean" 3 refs inexistentes de Z22.
   Regla: toda referencia candidata se verifica decodificando la instrucción.
3. **El texto de plantillas es SIEMPRE fullwidth (2B)**: el motor empareja
   bytes; ASCII de 1B aparece como kanji basura.
   → Error: etiquetas "Mens."/raw ASCII salieron como japonés en captura.
4. **Conservar los marcadores de color (&4/&5/&7) y su posición EXACTA**
   respecto al original línea a línea; &7 al final de línea cuando el original
   lo tiene (resetea color para la línea siguiente).
   → Error: menú Velocidad todo azul (&5) en vez de amarillo (&4).
5. **La fuente no se juzga por lectura visual de bitmaps derivados** (ya se
   confundieron 1345/1393, 1420/1424, 冒/膨). Se trabaja por código exacto y
   bitmap exacto, y la confirmación visual la hace David.

## Construcción y publicación
6. **Verificar SIEMPRE los bytes de la traducción dentro del .bin final
   publicado** (no del intermedio) antes de enviarlo a David.
   → Error: queja "no veo ningún cambio" sin haber verificado el binario final.
7. **Pipeline por defecto = modo seguro in-situ** (reconstruir_iso.py sin
   --rebuild). El rebuild global rompió INIT (tablas de offsets fijos) →
   GAME OVER probado.
8. **No acumular parches sobre binarios ya parcheados**: todo se regenera
   desde track01_original.bin en cada pipeline.
9. **El .bin que carga el .cue es raw 2352**, nunca la ISO 2048 (la BIOS no la
   lee y cae al reproductor de CD).

## Gestión
10. **Workspace ligero**: intermedios grandes se borran al terminar; se
    conservan SOLO: original (track01_original.bin), track01.iso (input
    pipeline), [CAST].bin (entrega), tools/, textos_dumper.csv,
    extraidos/{START,GFONT,INIT}.BIN (inputs patcher+pipeline),
    analisis/START_CAST_V3.BIN (fuente v4) + artefactos de fuente, informes/
    (diario anterior, informe, CUE). Todo lo demás es regenerable y se
    borra. Regeneración: [ORIGINAL].bin = cp track01_original.bin (al vuelo);
    track01_castellano.iso = reconstruir_iso.py; extraidos/* = extraer de
    track01.iso (walk ISO9660).
11. **DIARIO.md al día**: al empezar sesión se lee entero (el anterior +
    este); al terminar cada tarea se actualiza (hecho, bien, mal, pendientes).
12. **Nada está "arreglado" hasta que David lo confirma en emulador.** Yo
    verifico bytes; él verifica pantalla.
13. **Nombres de personaje: SOLO el canon de David** (Meifan, Tianren, Cash,
    Houmei, Doc, Airén, Xiao Mei, Kai, Rey Maten, Lee, Fei, Vaara, Dai, Ark,
    Consorte del Acero, Meshmer, Yama...). En HUD/batalla: solo el nombre
    corto.

## Aritmética y codificación (nacidas de la sesión 2, parte 2)
14. **NUNCA aritmética hex manual para layout**: los offsets de zona libre se
    calculan con un alocador secuencial en código (build-blobs → alloc() →
    colocar); las tablas se localizan decodificando u32 de los bytes vecinos,
    no asumiendo alineación.
    → Errores: 0x176B4+31B=0x176D3 (escribí 0x176CB → SY3 pisó SY2);
    0x1768A vs 0x1768B (IT4); menú principal en 0x13D12 (leído como 0x13D18).
15. **Códigos SJIS: NUNCA de memoria, SIEMPRE `python -c "print('Ｘ'.encode('shift_jis').hex())"`**
    (o `str.encode('shift_jis')` en el código).
    → Errores: Ｅ=8264 (no 8265); ［=816D (no 824F); los dígitos ０-９ son
    824F-8257. La tabla "de memoria" falló 3 veces en la misma sesión.
16. **El user data del .bin NO es contiguo**: cada sector MODE1 de 2352 B
    tiene 288 B de header entre datos. Offset del bin para (LBA del archivo L
    + offset dentro del archivo X): `(L + X//2048)*2352 + 16 + X%2048`.
    → Error: la nota "START = track 0x21D80+X" era falsa; las verificaciones
    del bin publicadas daban basura hasta usar el mapeo correcto. Verificar
    SIEMPRE sector a sector (48 sectores de START = 0 diffs).
17. **Las expectativas de verificación se calculan con el MISMO código y los
    MISMA run** (enc() del patcher, el layout impreso por el log del run en
    curso, `.encode('shift_jis')`): nunca de memoria, nunca del run anterior
    (los offsets de zona libre cambian entre diseños).
    → Error: 5 "fallos" de verificación seguidos que eran expectativas mal
    calculadas (tamaños de strings, posiciones de línea, codificación).
18. **El pipeline necesita `[ORIGINAL].bin` en recursos/**: copiar desde
    `track01_original.bin` antes de `reconstruir_iso.py` y borrarlo después
    (o se queda 18 MB de duplicado).
    → Error: borrado antes de re-ejecutar → FileNotFoundError en el paso bin.
19. **La fuente del juego NO tiene acentos latinos; los acentos se codifican
    como fullwidth SIN acento** (á→ａ 8281, é→ｅ 8285, í→ｉ 8289, ó→ｏ 828F,
    ú→ｕ 8295, ü→ｕ 8295, ñ→ｎ 828E, Á→Ａ 8260, É→Ｅ 8264, Í→Ｉ 8268, Ó→Ｏ 826E,
    Ú→Ｕ 8274, Ñ→Ｎ 826D, ¿→？ 8148, ¡→！ 8149). La tabla 16×16 del menú no
    existe como bitmap lineal en el ISO (GFONT/GHEAD/H01/H02 descartados);
    los slots HIJACK kanji (0x9660=冒...) solo afectan tablas 12×12 que el
    menú no usa. Para acentos de verdad o fuente Lord Monarch: RAM dump desde
    el emulador de David (struct 0x0A230, array 0x0A230+w(0x0A242)).
20. **Antes de diagnosticar "glifo mal pintado", zoom 16× y lectura
    pixel-a-pixel.** El 冒 a 0.8× parece 膨; el zoom 16× (日+儿) desmontó un
    día entero de búsquedas. Nunca interpretar glifos pequeños sin zoom.
21. **NUNCA parchear bitmaps por todo el disco sobre una identificación
    visual de celda 12×12** (celda 226 era un glifo puntitos, no 冒).
    Reemplazos por patrón a disco entero solo con el mapeo celda→glifo
    confirmado contra una tabla independiente o contra el render del juego.
22. **Cualquier cambio de codificación (HIJACK) exige regenerar
    START_CAST.BIN con parchear_start_v4.py ANTES de reconstruir_iso.py**:
    START.BIN se reemplaza entero con el cast estático; el in-situ no lo toca.
23. **Los offsets de tabla se verifican con byte-match exacto, nunca de
    memoria.** La base de OPEN llevaba 0x30 de error en la memoria
    (0xA740 real: 0xA710). Al reutilizar un offset "sabido", re-buscar el
    ancla (bitmap de 術) en el archivo antes de escribir.
24. **raw .bin ↔ ISO: mapeo por sector, no lineal.** raw = n*2352+16+r para
    cada offset ISO n*2048+r. Un slice continuo `raw[base:base+size]` de un
    archivo multi-sector ES BASURA: se lee byte a byte con el mapeo.
25. **Fuzzy de glifos sobre el ISO completo = inestable** (miles de hits
    falsos con umbral ≤22; el header LBA0 apunta a glifos raros). Para
    localizar bloques de una tabla: escaneo de densidad (bitcount/celda) +
    tiras de 16 celdas renderizadas a 4× y lectura directa.
26. **Códigos SJIS: siempre cp932, nunca memoria.** 冒=0x9660, 膨=0x9663
    (los confundí; la fuente del juego además los tiene intercambiados de
    celda). Toda asignación celda→código se verifica con el codec.
27. **Celda 12×12 de estas tablas = 144 bits CONTINUOS (bit = 12r+c, MSB),
    no 2 bytes por fila.** Empaquetar/desempaquetar siempre con la fórmula;
    validar con round-trip sobre una celda conocida (術) antes de pintar.
28. **Miniaturas de grid a 1px: solo para localizar zonas, no para leer
    filas.** Me leí kanji como "456789 ABCDEF...". La lectura fiable es
    celda a celda en ASCII o tira 16 celdas a 4×.
29. **Artefactos de trabajo en recursos/, no en /tmp** (/tmp no persiste
    entre turnos). Pkls de glifos, tablas SJIS↔JIS, etc.
30. **Leer el ISO de 2048 B/LBA: SIEMPRE `iso[lba*2048 : +sz]`.** La
    fórmula `lba*2352+16` (raw) sobre el ISO desplaza 304 B por cada LBA y
    produce un archivo "fantasma" (leí SD.BIN y resultó ser OPEN
    desplazado 76 KB). La fórmula raw solo aplica al .bin crudo 2352.
    Al extraer un archivo, validar con un ancla única (bitmap de 術) y
    comprobar que el offset esperado (p.ej. fw block) cae donde debe.
31. **Comparar bin↔ISO solo con extracción por sectores** (bloques de
    2048 B en `raw[(lba+k)*2352+16]`). Un slice continuo `raw[a:b]` de un
    archivo multi-sector da "94% de diferencias" FALSAS (es la basura de
    sync+header entre sectores). Antes de gritar "son imágenes distintas",
    re-verificar con extracción por sectores.
32. **Verificación de builds: extraer con el mapeo por sectores y contar
    celdas pintadas una a una** (78/78, 62/62...). No fiarse de "N sectores
    distintos del original" ni de verificaciones con slice continuo.

33. **Las plantillas vivas de Z22/magia/sistema/combate/principal están en la
    zona 0x17500-0x177AE de START.BIN** (las únicas copias de cada texto en el
    archivo, verificado con find). La zona 0x13D60 es un bloque de CEROS (no
    una plantilla) y 0x11D28/0x11D58/0x11D88 es CÓDIGO, no tablas de
    punteros. Antes de parchear un "menú", confirmar con find que el texto
    buscado está exactamente donde se parchea.
34. **Fullwidth ０-９ = 824F..8258: ０=824F, １=8250, ２=8251.** Los campos
    de valor "０００" son 824F 824F 824F. Nunca escribir offsets/bytes
    "de memoria": volcar el hex del disco y assertar byte a byte antes del
    parche.
35. **術/魔術/ステータス/アイテム/会話 no existen como texto en NINGÚN archivo
    del disco.** Las filas sin traducir del menú principal (術, "Ficha") y
    los iconos de estado de equipo (忌/瞬/哀/僕/渡) no son plantillas de
    texto: son bitmaps de layout pre-renderizados. No perseguir texto donde
    no lo hay; trabajar el bitmap (requiere captura + análisis de video RAM).
36. **Tabla maestra de nombres INIT 0x22900-0x22CA0**: entradas NUL-
    separadas de largo variable (lectura secuencial obligatoria; coexisten
    4B y 26B). Alargar una entrada desplaza el resto del archivo y NO hay
    bytes libres en la cola (está llena de dialogs) => requiere corte de
    compensación en zona de riesgo. No tocar sin haber verificado TODAS las
    referencias a la región desplazada y sin aprobación explícita.
    El nombre del menú de magia copia "máx 5 chars desde $bd00" (mapa de la
    sesión anterior): "Tianren" (7) se truncaría.
37. **Al asignar bytes a un slice de bytearray, SIEMPRE
    `assert len(nuevo) == len(slice)` ANTES de asignar**: una asignación más
    corta encoge el buffer y corrompe todas las lecturas posteriores del
    mismo buffer (pérdida de 2B en el parche P1; se detectó porque un assert
    posterior falló antes del write a disco).
38. **Fullwidth en plantillas de START = bloque SJIS 8260-8279 (Ａ-Ｚ),
    8281-829A (ａ-ｚ), 824F-8258 (０-９); ：=8146, sp=8140**. Los códigos
    82C9/93FC/82EA/828F son de la fuente GFONT, NO de las plantillas de
    texto: buscarlos en .bin da 0 hits falsos. Siempre traducir el hex de
    referencia ANTES de concluir "la string no existe en el disco".
    (2026-09-19: "Magia"/"Equipo" parecían no existir; estaban en 826C...)
39. **Los writes de valor del engine van a offset de byte FIJO dentro de la
    línea de plantilla (demostrado con Grp: byte 24, celdas render 9-10,
    máx 12) — NO al placeholder ００ de la línea**. Mover placeholders o
    etiquetas en el archivo no mueve el write; el write pisa lo que haya en
    su offset. Para reubicar un valor hay que parchear el CÓDIGO del write
    (aún no localizado; los "jsr $186D6/$2087E/$17FD8" del mapa anterior no
    existen en ningún archivo — mapa corrupto, no confiar en él). Diseñar
    cualquier layout de "label + valor" poniendo el campo del write donde
    se quiera que salga el número, y el texto estático alrededor.
40. **Offsets de RAM <-> file: START en $10000, INIT en $28000, CHR1 en
    $80000, OPEN en $??? (por confirmar). RAM $11D28 = file 0x1D28 en
    START, NO file 0x11D28.** Antes de volcar una "tabla" en file, restar
    la base RAM del archivo correspondiente; los file-iniciales de zonas
    RAM altas suelen ser CÓDIGO del propio START (0x11D28-0x11DA8 = código).
41. **Menú principal (6 filas): tabla en START 0x13D12-0x13D29 = 6 entradas
    4B big-endian = $2xxxx (file+0x10000) apuntando a strings NUL-terminadas
    (pool 0x13D2A-0x13D5F + 0x1773E-0x177A3). Strings nuevas => bloque de
    ceros 0x13D60+ + parchear la entrada (4B). La fila 1 (術) se dibuja 1
    celda a la izquierda que r2-r6 (margen del renderer, no de la data).
    r5 (0x13D4A) está COMPARTIDA con la pantalla de efecto de magia
    (original ステータス; traducida a "Ficha"; no romper la compartición
    sin entender la otra pantalla).

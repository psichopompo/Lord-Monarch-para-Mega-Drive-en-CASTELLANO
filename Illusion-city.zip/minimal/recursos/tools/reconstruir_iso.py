#!/usr/bin/env python3
"""Reconstrucción de la ISO con textos reubicados.

Pipeline:
1. Para cada archivo de guion con traducciones en el CSV: rebuild con
   reconstruir.rebuild (reubicación interna + fixup de IDs c6/c5).
2. Los archivos que CRECEN se reubican a la zona libre del final del disco
   (los IDs c6 son relativos a una BASE interna del archivo, por lo que
   mover el archivo entero de LBA no rompe nada).
3. Se parchean los directory records ISO9660 (extent LE+BE y tamaño).
   Los registros de directorio no cambian de tamaño -> parcheo in-situ.

Uso:
    python3 tools/reconstruir_iso.py --dry
    python3 tools/reconstruir_iso.py
Salida: track01_castellano.iso (+ informe_reconstruccion.txt)
"""
import csv
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(__file__))
import importlib.util


def _load(name):
    spec = importlib.util.spec_from_file_location(name, f'tools/{name}.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


reconstruir = _load('reconstruir')

ISO_ORIG = 'track01.iso'
ISO_OUT = '/tmp/track01_castellano.iso'  # (19/09/26) intermedio fuera del workspace
CSV_IN = 'textos_dumper.csv'
INFORME = 'informes/informe_reconstruccion.txt'
FREE_LBA_MIN = 7700
RESERVED = {'.', '..'}


def walk_iso(d):
    """Devuelve ({nombre: (ext, size, rec_off)}, directorios_visitados)."""
    pvd = 16 * 2048
    root_off = pvd + 156
    root_ext = struct.unpack('<I', d[root_off + 2:root_off + 6])[0]
    root_size = struct.unpack('<I', d[root_off + 10:root_off + 14])[0]
    files = {}
    dirs = {}

    def dir_records(lba, size):
        recs = []
        p = lba * 2048
        endp = p + size
        while p < endp:
            rl = d[p]
            if rl == 0:
                p = ((p // 2048) + 1) * 2048
                continue
            ext = struct.unpack('<I', d[p + 2:p + 6])[0]
            sz = struct.unpack('<I', d[p + 10:p + 14])[0]
            flags = d[p + 25]
            fl = d[p + 32]
            name = d[p + 33:p + 33 + fl].decode('ascii', 'replace')
            recs.append((name, ext, sz, flags, p))
            p += rl
        return recs

    def walk(lba, size):
        if lba in dirs:
            return
        dirs[lba] = size
        for name, ext, sz, flags, recp in dir_records(lba, size):
            if name in RESERVED:
                continue
            if flags & 2:
                walk(ext, sz)
            else:
                files[name] = (ext, sz, recp)

    walk(root_ext, root_size)
    return files, dirs


def patch_dir_record(d, recp, new_ext, new_size):
    """Parchea extent (+2 LE, +6 BE) y size (+10 LE, +14 BE) in-situ."""
    struct.pack_into('<I', d, recp + 2, new_ext)
    struct.pack_into('>I', d, recp + 6, new_ext)
    struct.pack_into('<I', d, recp + 10, new_size)
    struct.pack_into('>I', d, recp + 14, new_size)


def main():
    dry = '--dry' in sys.argv
    iso = bytearray(open(ISO_ORIG, 'rb').read())
    informe = []

    files, dirs = walk_iso(bytes(iso))
    files = {n.split(';')[0]: v for n, v in files.items()}
    informe.append(f'{len(files)} archivos, {len(dirs)} directorios')

    rows = list(csv.DictReader(open(CSV_IN, encoding='utf-8-sig')))
    trads = {}   # {(archivo, offset_archivo): traduccion}
    for row in rows:
        trad = row['traduccion_castellano'].strip()
        if trad:
            trads.setdefault(row['archivo'], {})[
                int(row['offset_archivo'], 16)] = trad

    # recolectar traducciones de todos los archivos y construir los nuevos
    # MODO SEGURO (por defecto): TODO in-situ con relleno de ceros -> ninguna
    # longitud de archivo cambia, ningún offset se desplaza, ningún LBA se mueve.
    # El rebuild con reubicación (tools/reconstruir.py) es correcto a nivel de
    # IDs c6, pero INIT.BIN tiene tablas de datos accedidas por offset fijo
    # fuera del flujo c6 que quedan DESPLAZADAS al crecer -> pantalla de batalla
    # corrupta y GAME OVER probado en emulador. Solo se activa con --rebuild.
    import os as _os
    allow_rebuild = '--rebuild' in sys.argv
    new_files = {}     # nombre -> bytes nuevos (o None si no cambia)
    grew = []
    if allow_rebuild:
        for fname, ftrads in sorted(trads.items()):
            if fname not in files:
                informe.append(f'AVISO: {fname} no existe en la ISO')
                continue
            d = open(f'extraidos/{fname}', 'rb').read()
            seg = reconstruir.find_segment(d)
            if seg is None:
                continue
            S, BASE, E = seg
            translations = {off: txt for off, txt in ftrads.items() if S <= off < E}
            out_bytes, inf = reconstruir.rebuild(d, translations, S, BASE, E)
            nerr = sum(1 for l in inf if l.startswith('ERROR'))
            if nerr:
                informe.append(f'{fname}: {nerr} errores de codificacion (esas cadenas quedan originales)')
            delta = len(out_bytes) - len(d)
            if delta > 0:
                grew.append((fname, len(d), delta))
            new_files[fname] = out_bytes if delta != 0 else None
            if delta:
                informe.append(f'{fname}: {len(ftrads)} traducciones, delta {delta:+d} B')
    else:
        informe.append('modo seguro in-situ (usa --rebuild para reubicación, NO probado en emulador)')

    # traducciones fuera del segmento c6 (o archivos sin formato): in-situ v1
    grew_names = {f for f, _s, _dl in grew}
    stats_v1 = {'ok': 0, 'no_cabe': 0, 'error': 0, 'omitidas': 0}
    for row in rows:
        trad = row['traduccion_castellano'].strip()
        if not trad:
            continue
        fname, off_s = row['archivo'], row['offset_archivo']
        if fname in grew_names and allow_rebuild:
            # con rebuild activo, el archivo se reescribe desde extraidos:
            # una edicion v1 aquí se perdería -> omitir y reportar
            stats_v1['omitidas'] += 1
            continue
        if fname in new_files and new_files[fname] is not None:
            # el archivo se reconstruye: las cadenas dentro del segmento ya
            # están puestas; las de fuera del segmento hay que aplicarlas
            # sobre los bytes NUEVOS con offset remapeado -> se resuelve
            # con el mapa del rebuild; para v1 simplemente se omiten aqui
            # y se reportan
            pass
        off = int(off_s, 16)
        ext, size, recp = files[fname]
        base = ext * 2048
        d = bytes(iso[base:base + size])
        end = d.find(b'\x00', off)
        if end < 0:
            continue
        orig_len = end - off + 1
        try:
            new = reconstruir.cod.encode_spanish(trad)
        except reconstruir.cod.EncodeError as e:
            stats_v1['error'] += 1
            continue
        if len(new) + 1 > orig_len:
            stats_v1['no_cabe'] += 1
            continue
        data = new + b'\x00'
        data += b'\x00' * (orig_len - len(data))
        iso[base + off:base + off + orig_len] = data
        stats_v1['ok'] += 1
    informe.append(f'in-situ v1: ok={stats_v1["ok"]} no_cabe={stats_v1["no_cabe"]} errores={stats_v1["error"]} omitidas_por_reubicacion={stats_v1["omitidas"]}')

    # (18/09/26) Los parches de bitmaps (48 copias: 16 kanji x 3 fuentes
    # GFONT/INIT/OPEN + celda 226 'fina') se DESCARTAN: el HIJACK ahora
    # remapea los acentos a fullwidth sin acento (ver codificador_castellano.py),
    # así que los slots 0x9660/0x95FB... ya no los usa texto castellano y no
    # hay que pintarlos. Dejarlos intactos además evita regredir el kanji
    # original (冒険, 北...) en las fuentes 12x12.
    informe.append('bitmaps reemplazados en todo el disco: 0 (HIJACK remapeado a fullwidth sin acento; slots dejados intactos)')
    informe.append('fuente fina celda 226: sin parches (0x9660 libre para 冒 original)')
    cod = _load('codificador_castellano')

    # menús/sistema de START.BIN (parche con repack + redirects, misma longitud)
    start_cast = 'analisis/START_CAST.BIN'
    if os.path.exists(start_cast):
        sc = open(start_cast, 'rb').read()
        sext, ssize, _ = files['START.BIN']
        assert len(sc) == ssize, f'START_CAST {len(sc)} != {ssize}'
        iso[sext * 2048:sext * 2048 + ssize] = sc
        informe.append(f'START.BIN parcheado en LBA {sext} (menús + plantillas NV/PV/PM)')

    # (19/09/26) SSTART.BIN parcheado: struct (a1) del menú, $08 = borde derecho
    # de la ventana de texto (unidades 8px): 17 -> 18 para des-wrap del 7º carácter
    sstart_cast = 'analisis/SSTART_CAST.BIN'
    if os.path.exists(sstart_cast):
        ss = open(sstart_cast, 'rb').read()
        sext2, ssize2, _ = files['SSTART.BIN']
        assert len(ss) == ssize2, f'SSTART_CAST {len(ss)} != {ssize2}'
        iso[sext2 * 2048:sext2 * 2048 + ssize2] = ss
        informe.append(f'SSTART.BIN parcheado en LBA {sext2} (ventana de texto del menú)')

    # (18/09/26) Fuente de menú: pintar en las tablas 12x12 de INIT/OPEN
    # - las 16 celdas kanji HIJACK con los acentos de Lord Monarch 8x8, y
    # - las 62 celdas fullwidth Latin (0-9 A-Z a-z) con los glifos 8x8.
    # Tablas localizadas y verificadas celda a celda: INIT+0x4ED0,
    # OPEN+0xA710 (misma disposición relativa).
    try:
        spec_fm = importlib.util.spec_from_file_location('fuente_menu', f'tools/fuente_menu.py')
        fm = importlib.util.module_from_spec(spec_fm)
        spec_fm.loader.exec_module(fm)
        iext, isz, _ = files['INIT.BIN']
        oext, osz, _ = files['OPEN.BIN']
        init_b = bytes(iso[iext * 2048:iext * 2048 + isz])
        open_b = bytes(iso[oext * 2048:oext * 2048 + osz])
        gext, gsz, _ = files['GFONT.BIN']
        g_b = bytes(iso[gext * 2048:gext * 2048 + gsz])
        init_n, open_n, g_n = fm.aplicar(init_b, open_b, informe, g_b)
        iso[iext * 2048:iext * 2048 + isz] = init_n
        iso[oext * 2048:oext * 2048 + osz] = open_n
        iso[gext * 2048:gext * 2048 + gsz] = g_n
        informe.append('fuente menú: INIT+OPEN 78 celdas + GFONT celdas 50-111, diseño David (menú confirmado leyendo INIT)')
    except Exception as e:
        informe.append(f'AVISO: fallo en fuente_menu: {e}')

    if dry:
        print('\n'.join(informe))
        print('\n(dry run: nada escrito)')
        return

    # reubicar los archivos crecidos al final + parchear dir records
    free_lba = FREE_LBA_MIN
    for fname, old_size, delta in grew:
        ext, size, recp = files[fname]
        new_data = new_files[fname]
        new_size = len(new_data)
        new_ext = free_lba
        iso[ext * 2048:ext * 2048 + old_size] = bytes(old_size)  # limpiar hueco
        dst = new_ext * 2048
        iso[dst:dst + new_size] = new_data
        pad = (-new_size) % 2048
        iso[dst + new_size:dst + new_size + pad] = bytes(pad)
        free_lba += (new_size + pad) // 2048
        patch_dir_record(iso, recp, new_ext, new_size)
        informe.append(f'REUBICADO {fname}: LBA {ext} -> {new_ext} ({new_size} B)')

    open(ISO_OUT, 'wb').write(bytes(iso))
    print(f'{ISO_OUT} escrito')

    # reconstruir el .bin crudo desde el ORIGINAL (no acumulativo)
    BIN_ORIG = "Gen'ei Toshi - Illusion City (Japan) (Track 01) [ORIGINAL].bin"
    BIN_OUT = "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin"

    def iso_to_raw(iso_off):
        # verificado empiricamente: el .bin son 7842 sectores raw de 2352
        # sin prefijo, y el user data va a +16 (12 sync + 4 header)
        n, r = divmod(iso_off, 2048)
        return n * 2352 + 16 + r

    raw = bytearray(open(BIN_ORIG, 'rb').read())
    orig = open(ISO_ORIG, 'rb').read()
    nsec = len(iso) // 2048
    for n in range(nsec):
        blk = iso[n * 2048:(n + 1) * 2048]
        if blk != orig[n * 2048:(n + 1) * 2048]:
            ro = iso_to_raw(n * 2048)
            raw[ro:ro + 2048] = blk
    open(BIN_OUT, 'wb').write(bytes(raw))
    print(f'{BIN_OUT} escrito')

    # el .bin que carga el .cue principal tambien, SIEMPRE en raw 2352
    # (nunca copiar la ISO 2048 encima: la BIOS no la lee y cae al
    # reproductor de CD de la Mega CD)
    # (19/09/26) El .cue carga [CAST].bin; el write a (Track 01).bin era
    # redundante (18MB de workspace) -> desactivado.
    # BIN_CUE = "Gen'ei Toshi - Illusion City (Japan) (Track 01).bin"
    # open(BIN_CUE, 'wb').write(bytes(raw))
    # print(f'{BIN_CUE} actualizado (raw 2352, {len(raw)} B)')

    txt = '\n'.join(informe)
    open(INFORME, 'w').write(txt + '\n')
    print('\n'.join(informe))


if __name__ == '__main__':
    main()

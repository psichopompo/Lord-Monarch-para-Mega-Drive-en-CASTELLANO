#!/usr/bin/env python3
"""Codificador castellano -> Shift-JIS del motor de Gen'ei Toshi.

Reglas de codificación (derivadas del análisis del juego):
- Latin A-Z a-z 0-9      -> fullwidth SJIS (Ａ-Ｚ ａ-ｚ ０-９), que están en GFONT.
- ¿¡ÑñáéíóúüÁÉÍÓÚÜ       -> códigos SJIS de los 16 slots de kanji secuestrados
                            (ver tabla_castellano.txt / GFONT_CAST.BIN).
- Marcadores del motor    -> ASCII literal: $1 $2 $3 #1 (nombres/números) y /n
                            (salto de línea). No se convierten a fullwidth.
- Opcodes halfwidth       -> byte único SJIS 0xA1-0xDF (ﾇ, ﾈ, ﾊ..ﾑ, ｡).
- Puntuación              -> equivalente japonés SIEMPRE que exista en la fuente
                            (se comprueba contra los códigos presentes en los
                            textos originales del juego, textos_dumper.csv).
- Cualquier otro caracter -> error, con lista de los caracteres problemáticos.

Uso:
    python3 tools/codificador_castellano.py "¡Hola, $1! ¿Todo bien?"
    python3 tools/codificador_castellano.py --selftest
"""
import codecs
import csv
import re
import sys
import importlib.util

CSV_DUMPER = 'textos_dumper.csv'
CSV_COL = 'japones'

# ------------------------------------------------------------------ setup

def _load_glyphs():
    spec = importlib.util.spec_from_file_location('g', 'tools/glifos_castellanos.py')
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

G = _load_glyphs()

# caracter castellano -> código SJIS (2 bytes) del slot secuestrado
HIJACK = {}
for _ch, _kanji in zip(G.GLYPHS.keys(), G.HIJACK_KANJI):
    HIJACK[_ch] = codecs.encode(_kanji, 'shift_jis')

# (18/09/26) REVERTIDO (peticion de David): el remapeo a fullwidth sin acento
# fue rechazado ("sin tilde no es aceptable"). Vuelve el HIJACK original:
# los acentos ocupan slots de kanji (á=0x9660 etc.). En la fuente 16x16 del
# menu esos slots siguen mostrando el kanji (0x9660 se ve como 膨, VERIFICADO
# pixel a pixel en la ampliacion de David de 22:12: mes+pi = 膨, NO 冒 — la
# lectura 冒 del zoom 16x de 201839 estaba mal). Se dejara el kanji a la vista
# hasta que se localice la tabla del menu (no existe en el ISO como bitmap
# lineal: ver DIARIO.md) y se pinte el acento real. Plan: dump de RAM del
# emulador (font struct RAM 0x0A230) o sustitucion de la fuente latina por
# la de Lord Monarch (8x8) cuando se localice la tabla.

# opcodes halfwidth del motor (prefijos vistos en las cadenas reales)
HW_OPCODES = set('｡ﾇﾊﾋﾌﾍﾎﾏﾐﾑ')

# fullwidth (acepta también formas halfwidth ａ-ｚ Ａ-Ｚ ０-９ y las normaliza)
def _fw(ch):
    o = ord(ch)
    if 0xFF21 <= o <= 0xFF3A:              # Ａ-Ｚ
        return bytes([0x82, 0x60 + o - 0xFF21])
    if 0xFF41 <= o <= 0xFF5A:              # ａ-ｚ
        return bytes([0x82, 0x81 + o - 0xFF41])
    if 0xFF10 <= o <= 0xFF19:              # ０-９
        return bytes([0x82, 0x4F + o - 0xFF10])
    if ord('A') <= o <= ord('Z'):
        return bytes([0x82, 0x60 + o - ord('A')])
    if ord('a') <= o <= ord('z'):
        return bytes([0x82, 0x81 + o - ord('a')])
    if ord('0') <= o <= ord('9'):
        return bytes([0x82, 0x4F + o - ord('0')])
    return None

# puntuación castellana -> candidatos japoneses (el primero que exista en la fuente)
PUNCT_CANDIDATES = {
    ',':  ['、'],
    '.':  ['。'],
    ':':  ['：'],
    ';':  ['；'],
    '!':  ['！'],
    '?':  ['？'],
    '(':  ['（'],
    ')':  ['）'],
    '-':  ['－', 'ー'],
    '—':  ['―', '－'],
    '…':  ['…'],
    '·':  ['・'],
    '•':  ['・'],
    '"':  ['」', '”'],
    '%':  ['％'],
    '/':  ['／'],
    '+':  ['＋'],
    '=':  ['＝'],
    "'":  ['’', 'ｰ'],
    '*':  ['＊'],
    '<':  ['＜'],
    '>':  ['＞'],
}

# símbolo castellano con significado propio del motor: pasa tal cual (ASCII)
PASSTHROUGH = set('$#')

# ------------------------------------------------------------------ fuente

def symbol_codes_from_dump(path=CSV_DUMPER):
    """Códigos SJIS de símbolos (bloque 0x81xx) presentes en el texto original:
    garantía de que ese glifo existe y el motor lo mapea."""
    codes = set()
    for row in csv.DictReader(open(path, encoding='utf-8-sig')):
        for ch in row[CSV_COL]:
            try:
                b = ch.encode('shift_jis')
            except UnicodeEncodeError:
                continue
            # símbolos + fullwidth alfanumérico: rangos completos de GFONT
            if len(b) == 2 and 0x8140 <= (b[0] << 8) | b[1] <= 0x829A:
                codes.add((b[0] << 8) | b[1])
    return codes

SYMBOLS = symbol_codes_from_dump()

def _enc2(ch):
    """codifica un caracter japonés a SJIS; cp932 como superset de respaldo."""
    try:
        return ch.encode('shift_jis')
    except UnicodeEncodeError:
        return ch.encode('cp932')


# ------------------------------------------------------------------ encoder

MARK_RE = re.compile(r'([$#][0-9A-Za-z]|/[a-zA-Z])')

class EncodeError(Exception):
    def __init__(self, bad):
        self.bad = bad
        super().__init__('Caracteres sin glifo: ' + ' '.join(f'{c!r}' for c in bad))

def encode_spanish(text, symbols=None):
    """Texto castellano -> bytes SJIS para el motor (sin terminador 00).

    Prefijo 'raw:': los bytes restantes se escriben LITERALES (1 byte/caracter,
    ASCII). Sirve para el experimento halfwidth en menus: si el motor soporta
    celdas de 1 byte, palabras como 'Sistema' caben donde el fullwidth no.
    """
    if text.startswith('raw:'):
        raw = text[4:]
        # de-acentar para no romper si alguien escribe 'Código' en raw
        import unicodedata as _ud
        raw = ''.join(c for c in _ud.normalize('NFD', raw)
                      if _ud.category(c) != 'Mn')
        return raw.encode('ascii')
    symbols = SYMBOLS if symbols is None else symbols
    text = text.replace('...', '…')     # puntos suspensivos japoneses
    out = bytearray()
    bad = []
    pos = 0
    while pos < len(text):
        m = MARK_RE.match(text, pos)
        if m:                                # marcador $1, #1, /n... literal
            out += m.group(0).encode('ascii')
            pos = m.end()
            continue
        ch = text[pos]
        pos += 1
        if ch in PASSTHROUGH:
            out += ch.encode('ascii')
        elif ch in HIJACK:
            out += HIJACK[ch]
        elif ch in HW_OPCODES:
            out += ch.encode('shift_jis')    # 1 byte 0xA1-0xDF
        elif ch == ' ':
            out += b'\x81\x40'               # espacio fullwidth
        else:
            fw = _fw(ch)
            if fw:
                out += fw
                continue
            # el caracter ya es japonés y existe en la fuente (「」、。！…): tal cual
            try:
                b = _enc2(ch)
            except UnicodeEncodeError:
                b = None
            if b and len(b) == 2 and ((b[0] << 8) | b[1]) in symbols:
                out += b
                continue
            cands = PUNCT_CANDIDATES.get(ch)
            done = False
            if cands:
                for c in cands:
                    try:
                        b = _enc2(c)
                    except UnicodeEncodeError:
                        continue
                    code = (b[0] << 8) | b[1]
                    if code in symbols:
                        out += b
                        done = True
                        break
            if not done:
                bad.append(ch)
    if bad:
        raise EncodeError(sorted(set(bad)))
    return bytes(out)

# ------------------------------------------------------------------ decoder

REVERSE = {(v[0] << 8) | v[1]: k for k, v in HIJACK.items()}

def decode_engine(data):
    """Bytes del motor -> texto legible (para verificación)."""
    out = []
    i = 0
    while i < len(data):
        b = data[i]
        if b < 0x80:
            out.append(chr(b))
            i += 1
        elif 0xA1 <= b <= 0xDF:
            out.append(bytes([b]).decode('shift_jis'))
            i += 1
        else:
            code = (b << 8) | data[i + 1]
            if code in REVERSE:
                out.append(REVERSE[code])
            else:
                try:
                    out.append(bytes([b, data[i + 1]]).decode('shift_jis'))
                except UnicodeDecodeError:
                    out.append(f'[{code:04X}]')
            i += 2
    # legibilidad: fullwidth -> ascii
    s = ''.join(out)
    return s.translate(str.maketrans(
        'ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ'
        'ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ０１２３４５６７８９　',
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 '))

# ------------------------------------------------------------------ selftest

def selftest():
    # (entrada, decodificación esperada: la puntuación sale como su
    #  equivalente japonés existente en la fuente)
    pruebas = [
        ('¡$1 recibe #1 puntos de daño!', '¡$1 recibe #1 puntos de daño！'),
        ('¿Con qué te enfrentas, Ñandú?', '¿Con qué te enfrentas、 Ñandú？'),
        ('Á É Í Ó Ú Ü á é í ó ú ü ñ Ñ ¿ ¡',
         'Á É Í Ó Ú Ü á é í ó ú ü ñ Ñ ¿ ¡'),
        ('Item: Poción de vida (máx. 99).', 'Item： Poción de vida （máx。 99）。'),
        ('ﾇ「$1, ¡detente!」', 'ﾇ「$1、 ¡detente！」'),
        ('Nivel 12. EXP #1. /nFalta poco...', 'Nivel 12。 EXP #1。 /nFalta poco…'),
    ]
    ok = True
    for text, esperado in pruebas:
        try:
            data = encode_spanish(text)
        except EncodeError as e:
            print(f'FALLO {text!r}: {e}')
            ok = False
            continue
        back = decode_engine(data)
        status = 'OK ' if back == esperado else 'DIF'
        if back != esperado:
            ok = False
        print(f'{status} {text}')
        print(f'     hex: {data.hex().upper()}')
        if back != esperado:
            print(f'     esp: {esperado}')
            print(f'     dec: {back}')
    # caracteres no soportados -> error claro
    try:
        encode_spanish('Esto tiene ~ y ª')
        print('FALLO: debería haber lanzado EncodeError')
        ok = False
    except EncodeError as e:
        print(f'OK  error claro para caracteres sin glifo: {e}')
    print('\nSELFTEST', 'PASS' if ok else 'FAIL')
    return ok

if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    text = ' '.join(sys.argv[1:])
    data = encode_spanish(text)
    print(f'texto : {text}')
    print(f'bytes : {data.hex().upper()}  ({len(data)} B + 00)')
    print(f'decod : {decode_engine(data)}')

#!/usr/bin/env python3
"""Parcheo de la fuente de menú (tablas 12x12 de INIT.BIN y OPEN.BIN).

Sustituye:
  - 16 celdas kanji HIJACK (los códigos de acento castellano) por los glifos
    con tilde de la fuente Lord Monarch 8x8 de David.
  - 62 celdas fullwidth Latin (０-９ Ａ-Ｚ ａ-ｚ) por los glifos 8x8 de David.

Hechos medidos (ver DIARIO 18/09/26):
  - Tabla de menú: celdas 12x12, 18 B, row-major MSB-first.
  - Base INIT: 0x4ED0 (celda 0 = 術 0x8F70).  Base OPEN: 0xA710 (misma
    disposición relativa; verificado celda a celda: 術/方/Ａ idénticas).
  - Orden de la tabla: JIS fila-major sobre un subconjunto; el clúster
    kanji HIJACK está en rel +510..+607 (verificado glifo a glifo).
  - Celda del código 0x9660 (冒) contiene el glifo 膨 en rel +526
    (la fuente del juego tiene 冒/膨 intercambiados; es por eso que el
    menú mostraba 膨 para 0x9660).
  - Bloque fullwidth: ０ 0x824F en rel -772 ... ｚ 0x829A en rel -711
    (leído directamente de la tabla, celda a celda).

El glifo 8x8 de David se centra en la celda 12x12 en (col 2, fila 2).
"""
import numpy as np
from PIL import Image

FONT_PNG = '/home/user/uploads/Fuente Lord Monarch.png'
INIT_BASE = 0x4ED0
OPEN_BASE = 0xA710
SD_BASE = 0x8CF0  # (18/09/26) tabla de SD.BIN: MISMA disposicion que INIT
# (verificado celda a celda: 術 @0x8CF0, fw block @22184, 78/78 celdas
# idénticas, slot 0x9660 = glifo 膨). LA TABLA QUE USA EL MENÚ: INIT/OPEN
# pintadas no tuvieron efecto en el menú; SD es la única otra tabla con
# este diseño. SD.BIN se carga en el boot (junto a INIT/CHR/CHR1).
CELL = 18  # 12x12, 1 bit por px, row-major MSB-first


def cargar_glifos_david(path=FONT_PNG):
    """Devuelve {caracter: matriz 8x8 (np int 0/1)}."""
    im = Image.open(path).convert('RGB')
    a = np.array(im)
    def cell8(r, c):
        g = np.zeros((8, 8), int)
        for y in range(8):
            for x in range(8):
                g[y, x] = 1 if int(a[r * 8 + y, c * 8 + x, 0]) < 50 else 0
        return g
    G = {}
    # fila 0: . , : ; ! ¡ ? ¿ ( ) / \ « » - %
    G['¡'] = cell8(0, 5); G['¿'] = cell8(0, 7)
    # fila 1: 0-9 A-F
    for i in range(10):
        G[str(i)] = cell8(1, i)
    for i, ch in enumerate('ABCDEF'):
        G[ch] = cell8(1, 10 + i)
    # fila 2: G H I J K L M N Ñ O P Q R S T U
    for i, ch in enumerate('GHIJKLMNÑOPQRSTU'):
        G[ch] = cell8(2, i)
    # fila 3: V W X Y Z a b c d e f g h i j k
    for i, ch in enumerate('VWXYZ'):
        G[ch] = cell8(3, i)
    for i, ch in enumerate('abcdefghijk'):
        G[ch] = cell8(3, 5 + i)
    # fila 4: l m n ñ o p q r s t u v w x y z
    for i, ch in enumerate('lmnñopqrstuvwxyz'):
        G[ch] = cell8(4, i)
    # fila 5: Á É Í Ó Ú Ü á é í ó ú ü ñ
    for i, ch in enumerate('ÁÉÍÓÚÜáéíóúüñ'):
        G[ch] = cell8(5, i)
    return G


# ---------------------------------------------------------------- destinos
# (rel, caracter_glifo): celdas kanji HIJACK -> acento
HIJACK_DEST = [
    (510, 'Á'),   # 0x95FB 方
    (526, 'á'),   # 0x9660 冒 (glifo 膨)
    (529, 'É'),   # 0x966B 北
    (531, 'Í'),   # 0x967B 本
    (534, 'Ó'),   # 0x9682 魔
    (550, 'Ú'),   # 0x96AF 民
    (554, 'Ñ'),   # 0x96B3 無
    (557, 'Ü'),   # 0x96BD 命
    (561, '¿'),   # 0x96C5 滅
    (568, '¡'),   # 0x96DA 目
    (584, 'é'),   # 0x9744 優
    (592, 'í'),   # 0x9755 誘
    (599, 'ú'),   # 0x975C 予
    (600, 'ó'),   # 0x975F 誉
    (606, 'ü'),   # 0x976C 様
    (607, 'ñ'),   # 0x9770 用
]


def fullwidth_dest():
    out = []
    for i in range(10):                      # ０-９ 0x824F-0x8258
        out.append((-772 + i, str(i)))
    for i, ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
        out.append((-762 + i, ch))           # Ａ-Ｚ 0x8260-0x8279
    for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
        out.append((-736 + i, ch))           # ａ-ｚ 0x8281-0x829A
    return out


def celda12(glifo8):
    """Convierte un glifo 8x8 en 18 bytes (12x12, MSB row-major), centrado."""
    g12 = np.zeros((12, 12), int)
    g12[2:10, 2:10] = glifo8
    out = bytearray(CELL)  # 144 bits = 18 B, flujo continuo MSB-first
    for r in range(12):
        for c in range(12):
            if g12[r, c]:
                bit = 12 * r + c
                out[bit // 8] |= 1 << (7 - bit % 8)
    return bytes(out)


def patch_tabla(data, base, dests, glifos, report, nombre):
    n = 0
    for rel, ch in dests:
        g = glifos[ch]
        blob = celda12(g)
        off = base + rel * CELL
        if off < 0 or off + CELL > len(data):
            report.append(f'{nombre}: rel {rel:+d} FUERA DE RANGO')
            continue
        data[off:off + CELL] = blob
        n += 1
    report.append(f'{nombre}: {n} celdas pintadas')
    return data


def aplicar(init_bytes, open_bytes, report, gfont_bytes=None):
    """Parchea las tablas y devuelve (init_nuevo, open_nuevo, [gfont_nuevo]).

    (18/09/26) Experimento discriminador RESUELTO: David confirma que el
    menú de velocidad muestra la fuente de David => el menú lee INIT.
    Se pinta INIT y OPEN con el diseño normal de David (consistencia en
    todas las pantallas) y GFONT (celdas 50-111) con el mismo diseño.
    """
    glifos = cargar_glifos_david()
    dests = HIJACK_DEST + fullwidth_dest()
    init_b = bytearray(init_bytes)
    open_b = bytearray(open_bytes)
    patch_tabla(init_b, INIT_BASE, dests, glifos, report, 'INIT')
    patch_tabla(open_b, OPEN_BASE, dests, glifos, report, 'OPEN')
    if gfont_bytes is not None:
        gf_b = bytearray(gfont_bytes)
        dests_fw = [(50 + i, ch) for i, ch in
                    enumerate(['0','1','2','3','4','5','6','7','8','9',
                               'A','B','C','D','E','F','G','H','I','J','K','L','M',
                               'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
                               'a','b','c','d','e','f','g','h','i','j','k','l','m',
                               'n','o','p','q','r','s','t','u','v','w','x','y','z'])]
        patch_tabla(gf_b, 0, dests_fw, glifos, report, 'GFONT')
        return bytes(init_b), bytes(open_b), bytes(gf_b)
    return bytes(init_b), bytes(open_b)


if __name__ == '__main__':
    # preview: renderiza las 78 celdas a pintar
    glifos = cargar_glifos_david()
    dests = HIJACK_DEST + fullwidth_dest()
    per = 16
    n = len(dests)
    rows = (n + per - 1) // per
    img = Image.new('L', (per * 14, rows * 14), 255)
    px = img.load()
    for i, (rel, ch) in enumerate(dests):
        g = celda12(glifos[ch])
        rr, cc = divmod(i, per)
        for r in range(12):
            for c in range(12):
                bit = 12 * r + c
                if g[bit // 8] >> (7 - bit % 8) & 1:
                    px[cc * 14 + 1 + c, rr * 14 + 1 + r] = 0
    img = img.resize((img.width * 2, img.height * 2), Image.NEAREST)
    img.save('/home/user/illusion-city/preview_fuente_parche.png')
    print('preview_fuente_parche.png', n, 'celdas')
    print('fila 1: HIJACK (Á á É Í Ó Ú Ñ Ü ¿ ¡ é í ú ó ü ñ)')
    print('filas 2+: fullwidth 0-9 A-Z a-z')

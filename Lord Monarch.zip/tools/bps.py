#!/usr/bin/env python3
"""bps.py - genera y aplica parches BPS. Con round-trip obligatorio.

BPS es el formato que pide David para compartir. Frente a IPS:

  - lleva CRC32 de origen, destino y del propio parche, asi que el
    emulador avisa si la ROM base no es la correcta o si el parche
    llego corrupto. IPS no comprueba nada.
  - no tiene el limite de 16 MB ni el problema del offset "EOF".

FORMATO
-------
    "BPS1"
    varint  tamano de la ROM origen
    varint  tamano de la ROM destino
    varint  tamano de los metadatos
    bytes   metadatos
    ...     acciones
    u32le   CRC32 del origen
    u32le   CRC32 del destino
    u32le   CRC32 del parche (todo lo anterior)

Cada accion es un varint: los 2 bits bajos son el comando y el resto,
mas uno, la longitud.

    0 SourceRead  copia `n` bytes del origen, en el mismo offset
    1 TargetRead  detras vienen `n` bytes literales
    2 SourceCopy  detras, un varint con signo: offset relativo en origen
    3 TargetCopy  idem, pero sobre lo ya escrito del destino

VARINT
------
Es el de bsnes, que NO es el de protobuf: el ultimo byte lleva el bit 7
y cada paso resta uno, para que no haya dos codificaciones del mismo
numero.

    python3 tools/bps.py crear ORIGEN DESTINO SALIDA.bps
    python3 tools/bps.py aplicar ORIGEN PARCHE.bps SALIDA
"""
import sys
from zlib import crc32


def escribe_varint(n):
    out = bytearray()
    while True:
        x = n & 0x7F
        n >>= 7
        if n == 0:
            out.append(0x80 | x)
            break
        out.append(x)
        n -= 1
    return bytes(out)


def lee_varint(b, i):
    n, desp = 0, 1
    while True:
        x = b[i]
        i += 1
        n += (x & 0x7F) * desp
        if x & 0x80:
            break
        desp <<= 7
        n += desp
    return n, i


def crear(origen, destino, metadatos=b''):
    """Parche BPS minimo: alterna tramos iguales y tramos literales.

    No busca coincidencias movidas (SourceCopy/TargetCopy). Para lo que
    hacemos -unos cientos de bytes cambiados in situ sobre una ROM del
    mismo tamano- da un parche pequeno y, sobre todo, trivial de leer.
    Meter un buscador de coincidencias seria codigo que no puedo
    verificar bien y que no ahorraria nada aqui.
    """
    p = bytearray(b'BPS1')
    p += escribe_varint(len(origen))
    p += escribe_varint(len(destino))
    p += escribe_varint(len(metadatos))
    p += metadatos

    n = min(len(origen), len(destino))
    i = 0
    while i < len(destino):
        if i < n and origen[i] == destino[i]:
            j = i
            while j < n and origen[j] == destino[j]:
                j += 1
            p += escribe_varint(((j - i - 1) << 2) | 0)      # SourceRead
            i = j
        else:
            j = i
            while j < len(destino) and not (j < n and origen[j] == destino[j]):
                j += 1
            p += escribe_varint(((j - i - 1) << 2) | 1)      # TargetRead
            p += destino[i:j]
            i = j

    p += crc32(origen).to_bytes(4, 'little')
    p += crc32(destino).to_bytes(4, 'little')
    p += crc32(bytes(p)).to_bytes(4, 'little')
    return bytes(p)


def aplicar(origen, parche):
    assert parche[:4] == b'BPS1', 'no es un BPS'
    esperado = int.from_bytes(parche[-4:], 'little')
    real = crc32(parche[:-4])
    assert real == esperado, 'el parche esta corrupto (CRC32 %08X != %08X)' % (
        real, esperado)

    i = 4
    n_org, i = lee_varint(parche, i)
    n_dst, i = lee_varint(parche, i)
    n_met, i = lee_varint(parche, i)
    i += n_met

    assert len(origen) == n_org, \
        'la ROM base mide %d B y el parche espera %d' % (len(origen), n_org)
    crc_org = int.from_bytes(parche[-12:-8], 'little')
    assert crc32(origen) == crc_org, \
        'la ROM base no es la correcta (CRC32 %08X, esperado %08X)' % (
            crc32(origen), crc_org)

    salida = bytearray()
    src_rel = dst_rel = 0
    fin = len(parche) - 12
    while i < fin:
        cmd, i = lee_varint(parche, i)
        accion, largo = cmd & 3, (cmd >> 2) + 1
        if accion == 0:                                      # SourceRead
            o = len(salida)
            salida += origen[o:o + largo]
        elif accion == 1:                                    # TargetRead
            salida += parche[i:i + largo]
            i += largo
        else:                                                # Source/TargetCopy
            d, i = lee_varint(parche, i)
            desp = (-1 if d & 1 else 1) * (d >> 1)
            if accion == 2:
                src_rel += desp
                salida += origen[src_rel:src_rel + largo]
                src_rel += largo
            else:
                dst_rel += desp
                for _ in range(largo):
                    salida.append(salida[dst_rel])
                    dst_rel += 1

    assert len(salida) == n_dst, 'salida de %d B, esperaba %d' % (
        len(salida), n_dst)
    crc_dst = int.from_bytes(parche[-8:-4], 'little')
    assert crc32(bytes(salida)) == crc_dst, 'el resultado no cuadra'
    return bytes(salida)


def genera(ruta_origen, ruta_destino, salida, metadatos=b''):
    a = open(ruta_origen, 'rb').read()
    b = open(ruta_destino, 'rb').read()
    p = crear(a, b, metadatos)
    # ROUND-TRIP OBLIGATORIO: se aplica el parche recien hecho y se
    # exige que salga el destino byte a byte. Un parche que no se ha
    # aplicado nunca no esta verificado.
    assert aplicar(a, p) == b, 'ROUND-TRIP FALLA'
    open(salida, 'wb').write(p)
    dif = sum(1 for k in range(min(len(a), len(b))) if a[k] != b[k])
    print('%s  %d B' % (salida, len(p)))
    print('   origen  CRC32 %08X  %d B' % (crc32(a), len(a)))
    print('   destino CRC32 %08X  %d B  (%d bytes distintos)'
          % (crc32(b), len(b), dif))
    print('   round-trip: OK')
    return p


if __name__ == '__main__':
    if sys.argv[1] == 'crear':
        genera(sys.argv[2], sys.argv[3], sys.argv[4])
    elif sys.argv[1] == 'aplicar':
        a = open(sys.argv[2], 'rb').read()
        p = open(sys.argv[3], 'rb').read()
        open(sys.argv[4], 'wb').write(aplicar(a, p))
        print('%s escrito' % sys.argv[4])
    else:
        print(__doc__)

# Emulador headless — Genesis Plus GX (para verificar la ROM sin visión)

Compilado en `/home/user/gpgx/` (clon de ekeeke/Genesis-Plus-GX), frontend SDL2
`gen_sdl2`, con un modo **headless** añadido para tomar capturas sin display ni
audio y con **input simulado**.

## Cómo compilarlo (si se pierde el binario)
```bash
sudo apt-get install -y libsdl2-dev zlib1g-dev
git clone --depth 1 https://github.com/ekeeke/Genesis-Plus-GX.git gpgx
cd gpgx
git apply /home/user/LordMonarch/tools/gpgx_headless.patch   # parche del modo headless
cd sdl && make -f Makefile.sdl2 -j4
```
El parche hace 3 cosas:
1. `Makefile.sdl2`: `-std=c99` → `-std=gnu99` (por ftello/fseeko de libchdr) y
   quita `-DUSE_LIBTREMOR -DUSE_LIBCHDR` (no se necesitan para ROMs de cartucho).
2. `sdl2/main.c`: arregla `SDLK_KPx` → `SDLK_KP_x` (SDL ≥2.32).
3. `sdl2/main.c`: añade **modo headless** + `save_bmp()`.

## Uso
```bash
SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy ./gen_sdl2 rom.md FRAMES salida.bmp [INPUT]
```
- `FRAMES` = nº de frames a emular (60/s NTSC, 50/s PAL).
- `INPUT`  = cadena de eventos `"START@120,A@200,..."`. Cada evento mantiene la
  tecla ~8 frames. Teclas: START, A, B, C, UP, DOWN, LEFT, RIGHT.
- Genera `salida.bmp` (viewport 320×224, 24 bpp) del frame final.

### Mapeo de teclas MD en el frontend normal (por si se usa con ventana)
A=A · S=B · D=C · F=START · flechas=d-pad.

## "Ver" sin visión
`tools/read_frame.py` compara píxel a píxel el frame contra los glifos de la
fuente (0x19AEC0) para reconstruir el texto en pantalla. Útil para validar que
los acentos se renderizan. (Requiere Pillow: `pip install pillow`.)

## Nota honesta sobre la visión
En este entorno `read_file` sobre una imagen devuelve "no vision capabilities",
así que NO puedo inspeccionar capturas a ojo como hacía el chat anterior. Lo
compenso con **comparación píxel a píxel** (más rigurosa que mirar): renderizo
el mismo frame con/sin cambios y diff de píxeles, o reconstruyo el texto con
`read_frame.py`.

# gen_sdl2 con modo headless + carga de savestate
Binario compilado: gen_sdl2_compilado (misma interfaz que gen_sdl2 + 5º arg = state raw).
Uso: SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy ./gen_sdl2 ROM FRAMES out.bmp 'INPUT' [state.raw]
state.raw = el .state de GENPLUS-GX descomprimido (zlib) desde el byte 0x18, y a ese
resultado quitarle los primeros 0x10 bytes (cabecera RASTATE+MEM), rellenando con ceros
hasta 0xfd000. OJO: los .state de la version Wii cuelgan el state_load del nucleo SDL
(bloques MEM/VRAM separados); solo sirve para states del frontend SDL.
Recompilar: sudo apt-get install -y libsdl2-dev zlib1g-dev; git clone --depth 1
https://github.com/ekeeke/Genesis-Plus-GX.git gpgx; copiar main.c sobre gpgx/sdl/sdl2/main.c
y Makefile.sdl2 sobre gpgx/sdl/Makefile.sdl2; cd gpgx/sdl && make -f Makefile.sdl2 -j4.

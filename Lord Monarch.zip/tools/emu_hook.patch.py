#!/usr/bin/env python3
"""Aplica sobre gpgx/sdl/sdl2/main.c + Makefile.sdl2 los parches de instrumentacion:
 - dumps: state.bin, vram.bin, cram.bin, regs.bin, sat.bin (DUMPSTATE=1)
 - ram.bin (DUMPRAM=1)
 - trace de lecturas 68k hook.bin (HOOKFROM/HOOKTO)
Uso: python3 emu_hook.patch.py <dir_sdl_de_gpgx> <main.c_con_dumps>
"""
import sys, os
sdl = sys.argv[1]
main_src = open(sys.argv[2]).read()

hook_code = '''
#ifdef HOOK_CPU
#include "debug/cpuhook.h"
static FILE *hookf=0;
static void my_hook(hook_type_t t,int w,unsigned a,unsigned v){
  if(!hookf) return;
  if(t==HOOK_M68K_E){ unsigned char b[5]; b[0]=0; b[1]=0xEE; b[2]=a>>16;b[3]=a>>8;b[4]=a; fwrite(b,5,1,hookf); return; }
  if(t==HOOK_M68K_R||t==HOOK_M68K_W){ unsigned char b[10]; b[0]=w; b[1]=(t==HOOK_M68K_W)?1:0; b[2]=a>>24;b[3]=a>>16;b[4]=a>>8;b[5]=a; b[6]=v>>24;b[7]=v>>16;b[8]=v>>8;b[9]=v; fwrite(b,10,1,hookf);} }
#endif
'''
main_src = main_src.replace('#define SOUND_FREQUENCY 48000', hook_code + '\n#define SOUND_FREQUENCY 48000', 1)

loop_add = '''      input.pad[0]=pad;
#ifdef HOOK_CPU
      { static int hf=-2,ht=-1;
        if(hf==-2){ hf=getenv("HOOKFROM")?atoi(getenv("HOOKFROM")):-1; ht=getenv("HOOKTO")?atoi(getenv("HOOKTO")):-1; }
        if(hf>=0){ if(f==hf){ hookf=fopen("hook.bin","wb"); cpu_hook=my_hook;} if(f==ht&&hookf){ cpu_hook=0; fclose(hookf); hookf=0;} } }
#endif'''
assert '      input.pad[0]=pad;' in main_src
main_src = main_src.replace('      input.pad[0]=pad;', loop_add, 1)

# compat SDL2 moderna
adds = "\n".join(f"#define SDLK_KP{i} SDLK_KP_{i}" for i in range(10))
main_src = main_src.replace('#include "shared.h"', '#include "shared.h"\n' + adds, 1)

open(os.path.join(sdl, 'sdl2', 'main.c'), 'w').write(main_src)

mk = open(os.path.join(sdl, 'Makefile.sdl2')).read()
old = "DEFINES   = -DLSB_FIRST -DUSE_16BPP_RENDERING -DMAXROMSIZE=33554432 -DHAVE_YM3438_CORE -DHAVE_OPLL_CORE -DENABLE_SUB_68K_ADDRESS_ERROR_EXCEPTIONS -DZ7_ST -DZSTD_DISABLE_ASM"
assert old in mk
mk = mk.replace(old, old + " -DHOOK_CPU")
mk = mk.replace('-I$(SRCDIR)/../sdl -I$(SRCDIR)/../sdl/sdl2', '-I$(SRCDIR)/../sdl -I$(SRCDIR)/../sdl/sdl2 -I$(SRCDIR)/debug', 1)
mk = mk.replace('-fomit-frame-pointer -Wall', '-fomit-frame-pointer -fcommon -Wall', 1)
open(os.path.join(sdl, 'Makefile.sdl2'), 'w').write(mk)
print('patched', sdl)

# Repaso de la traducción — Lord Monarch (Mega Drive) → castellano

Estado: texto tal y como está volcado en la ROM. Caja ancha:
~300 px útiles; líneas llenas sin romper palabras. «(N)» =
caracteres de la línea. «--- página ---» = separador 0x02 del
motor (máx. 3 líneas por página). Sin líneas vacías impuestas.

### [0]  `031936`
**ES:** Alfred Monarch
```
+----------------------+
| Alfred Monarch       | (14)
+----------------------+
```
### [1]  `031945`
**ES:** Princesa
```
+----------------------+
| Princesa             | (8)
+----------------------+
```
### [2]  `03194E`
**ES:** Rubia Martika
```
+----------------------+
| Rubia Martika        | (13)
+----------------------+
```
### [3]  `031970`
**ES:** Lance
```
+----------------------+
| Lance                | (5)
+----------------------+
```
### [4]  `03197A`
**ES:** El Rey
```
+----------------------+
| El Rey               | (6)
+----------------------+
```
### [5]  `031983`
**ES:** Lord Monarch
```
+----------------------+
| Lord Monarch         | (12)
+----------------------+
```
### [6]  `031998`
**ES:** Geopaldon
```
+----------------------+
| Geopaldon            | (9)
+----------------------+
```
### [7]  `0319A9`
**ES:** Woodhead
```
+----------------------+
| Woodhead             | (8)
+----------------------+
```
### [8]  `0319BE`
**ES:** Gran Ninja
```
+----------------------+
| Gran Ninja           | (10)
+----------------------+
```
### [9]  `0319CB`
**ES:** Shakuren
```
+----------------------+
| Shakuren             | (8)
+----------------------+
```
### [10]  `0319E3`
**ES:** Soldados
```
+----------------------+
| Soldados             | (8)
+----------------------+
```
### [11]  `0319EC`
**ES:** Aldea de Monarch
```
+----------------------+
| Aldea de Monarch     | (16)
+----------------------+
```
### [12]  `0319FE`
**ES:** Bestias
```
+----------------------+
| Bestias              | (7)
+----------------------+
```
### [13]  `031A07`
**ES:** Aldea de Monarch
```
+----------------------+
| Aldea de Monarch     | (16)
+----------------------+
```
### [14]  `031A19`
**ES:** El rival
```
+----------------------+
| El rival             | (8)
+----------------------+
```
### [15]  `031A23`
**ES:** Geis Blighty
```
+----------------------+
| Geis Blighty         | (12)
+----------------------+
```
### [16]  `031A35`
**ES:** A ver... ¿Qué hacemos?
```
+------------------------+
| A ver... ¿Qué hacemos? | (22)
+------------------------+
```
### [17]  `031A5C`
**ES:** Mmm... ¿Qué hacemos?
```
+----------------------+
| Mmm... ¿Qué hacemos? | (20)
+----------------------+
```
### [18]  `031A91`
**ES:** Progreso guardado.
```
+----------------------+
| Progreso guardado.   | (18)
+----------------------+
```
### [19]  `031AB4`
**ES:** ¡Oh, no! ¡No podemos guardar!
```
+-------------------------------+
| ¡Oh, no! ¡No podemos guardar! | (29)
+-------------------------------+
```
### [20]  `031AF0`
**ES:** ¡Progreso guardado!
```
+----------------------+
| ¡Progreso guardado!  | (19)
+----------------------+
```
### [21]  `031B09`
**ES:** ¡No podemos guardar!
```
+----------------------+
| ¡No podemos guardar! | (20)
+----------------------+
```
### [22]  `031B45`
**ES:** Alfred, casi tienes 16 años. Seguro que conoces las reglas del reino.
```
+-------------------------------------+
| Alfred, casi tienes 16 años. Seguro | (35)
| que conoces las reglas del reino.   | (33)
+-------------------------------------+
```
### [23]  `031B94`
**ES:** ¿Qué te pasa, viejo? Hablas muy formal para ser tú.
```
+---------------------------------+
| ¿Qué te pasa, viejo? Hablas muy | (31)
| formal para ser tú.             | (19)
+---------------------------------+
```
### [24]  `031BDC`
**ES:** ¡Compórtese, joven amo! ¡Está ante Su Majestad!
```
+------------------------------------+
| ¡Compórtese, joven amo! ¡Está ante | (34)
| Su Majestad!                       | (12)
+------------------------------------+
```
### [25]  `031C1E`
**ES:** Mocoso insolente. Te has ganado uno de mis coscorrones.
```
+-------------------------------------+
| Mocoso insolente. Te has ganado uno | (35)
| de mis coscorrones.                 | (19)
+-------------------------------------+
```
### [26]  `031C66`
**ES:** ¡P-P-Por favor, Majestad! ¡Acabamos de reparar el castillo!
```
+----------------------------------------+
| ¡P-P-Por favor, Majestad! ¡Acabamos de | (38)
| reparar el castillo!                   | (20)
+----------------------------------------+
```
### [27]  `031CA6`
**ES:** Bah. ¿Qué pasa con nuestras reglas?
```
+-----------------------------+
| Bah. ¿Qué pasa con nuestras | (27)
| reglas?                     | (7)
+-----------------------------+
```
### [28]  `031CD7`
**ES:** Bien. Para demostrar que mereces el trono, debes vencer a todos los bandidos antes de cumplir los 16.
```
+-------------------------------------+
| Bien. Para demostrar que mereces el | (35)
| trono, debes vencer a todos los     | (31)
| bandidos antes de cumplir los 16.   | (33)
+-------------------------------------+
```
### [29]  `031D47`
**ES:** Estos bandidos son flojos. En fin... ¿Y si no lo consigo antes de que acabe el plazo?
```
+-----------------------------------------+
| Estos bandidos son flojos. En fin... ¿Y | (39)
| si no lo consigo antes de que acabe el  | (38)
| plazo?                                  | (6)
+-----------------------------------------+
```
### [30]  `031DA3`
**ES:** No aceptaría a un debilucho como príncipe de Monarch. Es decir, que te echaré del reino. Cuando tenía tu edad, yo era el joven más guapo de todos los países vecinos, y derrotaba bandidos a diestro y siniestro.
```
+----------------------------------------------+
| No aceptaría a un debilucho como príncipe de | (44)
| Monarch. Es decir, que te echaré del reino.  | (43)
+- - - página - - -+
| Cuando tenía tu edad, yo era el joven más    | (41)
| guapo de todos los países vecinos, y         | (36)
| derrotaba bandidos a diestro y siniestro.    | (41)
+----------------------------------------------+
```
### [31]  `031EA3`
**ES:** Otra vez con sus historias...
```
+-------------------------------+
| Otra vez con sus historias... | (29)
+-------------------------------+
```
### [32]  `031ECA`
**ES:** En fin. Tienes 160 días. Úsalos bien.
```
+--------------------------+
| En fin. Tienes 160 días. | (24)
+- - - página - - -+
| Úsalos bien.             | (12)
+--------------------------+
```
### [33]  `031F04`
**ES:** Sí, sí. Venceré a los bandidos y volveré antes de que lo notes.
```
+------------------------------------------+
| Sí, sí. Venceré a los bandidos y volveré | (40)
| antes de que lo notes.                   | (22)
+------------------------------------------+
```
### [34]  `031F57`
**ES:** Lance, cuida del tonto de mi hijo, ¿sí?
```
+-----------------------------------------+
| Lance, cuida del tonto de mi hijo, ¿sí? | (39)
+-----------------------------------------+
```
### [35]  `031F86`
**ES:** ¡Sí, Majestad! Puede contar conmigo.
```
+--------------------------------------+
| ¡Sí, Majestad! Puede contar conmigo. | (36)
+--------------------------------------+
```
### [36]  `031FD1`
**ES:** Daría mi vida por proteger el futuro de nuestro...
```
+-----------------------------------------+
| Daría mi vida por proteger el futuro de | (39)
| nuestro...                              | (10)
+-----------------------------------------+
```
### [37]  `03200E`
**ES:** Como sea, me voy.
```
+----------------------+
| Como sea, me voy.    | (17)
+----------------------+
```
### [38]  `032023`
**ES:** ¡Espérameeeeee!
```
+----------------------+
| ¡Espérameeeeee!      | (15)
+----------------------+
```
### [39]  `032053`
**ES:** ¡Comencemos!
```
+----------------------+
| ¡Comencemos!         | (12)
+----------------------+
```
### [40]  `032075`
**ES:** ¿Por qué no me enseña aquí lo que sabe hacer?
```
+----------------------------------------+
| ¿Por qué no me enseña aquí lo que sabe | (38)
| hacer?                                 | (6)
+----------------------------------------+
```
### [41]  `0320AB`
**ES:** ¿Eh? Pero los monstruos de aquí son flojos. Son aburridos. Lucharé contra otros.
```
+--------------------------------------+
| ¿Eh? Pero los monstruos de aquí son  | (35)
| flojos.                              | (7)
+- - - página - - -+
| Son aburridos. Lucharé contra otros. | (36)
+--------------------------------------+
```
### [42]  `03210B`
**ES:** Calma, hay que ir paso a paso. La falta de preparación es peligrosa, ya verá.
```
+------------------------------------------+
| Calma, hay que ir paso a paso.           | (30)
+- - - página - - -+
| La falta de preparación es peligrosa, ya | (40)
| verá.                                    | (5)
+------------------------------------------+
```
### [43]  `03217D`
**ES:** Bien. Veamos quién está aquí.
```
+-------------------------------+
| Bien. Veamos quién está aquí. | (29)
+-------------------------------+
```
### [44]  `0321B6`
**ES:** ¡Uga uga!
```
+----------------------+
| ¡Uga uga!            | (9)
+----------------------+
```
### [45]  `0321C2`
**ES:** Bah. Lo venzo dormido. Solo tengo que avanzar.
```
+-------------------------+
| Bah. Lo venzo dormido.  | (22)
| Solo tengo que avanzar. | (23)
+-------------------------+
```
### [46]  `03220F`
**ES:** Piense en los soldados. Debemos proteger la zona.
```
+-------------------------+
| Piense en los soldados. | (23)
| Debemos proteger la     | (19)
| zona.                   | (5)
+-------------------------+
```
### [47]  `03225A`
**ES:** Sí, sí. ¡Vamos ya!
```
+----------------------+
| Sí, sí. ¡Vamos ya!   | (18)
+----------------------+
```
### [48]  `03227B`
**ES:** ¿Ves? ¡Fue fácil!
```
+----------------------+
| ¿Ves? ¡Fue fácil!    | (17)
+----------------------+
```
### [49]  `032293`
**ES:** ¿En serio? ¿Vamos a darle el reino a alguien tan imprudente?
```
+---------------------------+
| ¿En serio? ¿Vamos a darle | (25)
| el reino a alguien tan    | (22)
| imprudente?               | (11)
+---------------------------+
```
### [50]  `0322DB`
**ES:** ¿Ha dicho algo, abuelo?
```
+----------------------+
| ¿Ha dicho algo,      | (15)
| abuelo?              | (7)
+----------------------+
```
### [51]  `0322FC`
**ES:** Nada, joven amo... *suspiro*
```
+------------------------------+
| Nada, joven amo... *suspiro* | (28)
+------------------------------+
```
### [52]  `032329`
**ES:** ¡Pan comido! Je, je.
```
+----------------------+
| ¡Pan comido! Je, je. | (20)
+----------------------+
```
### [53]  `032343`
**ES:** Ah, joven.
```
+----------------------+
| Ah, joven.           | (10)
+----------------------+
```
### [54]  `032406`
**ES:** Alfred@Monarch
```
+----------------------+
| Alfred@Monarch       | (14)
+----------------------+
```
### [55]  `032415`
**ES:** Princesa
```
+----------------------+
| Princesa             | (8)
+----------------------+
```
### [56]  `03241E`
**ES:** Rubia@Martika
```
+----------------------+
| Rubia@Martika        | (13)
+----------------------+
```
### [57]  `032440`
**ES:** Lance
```
+----------------------+
| Lance                | (5)
+----------------------+
```
### [58]  `03244A`
**ES:** El@Rey
```
+----------------------+
| El@Rey               | (6)
+----------------------+
```
### [59]  `032453`
**ES:** Lord@Monarch
```
+----------------------+
| Lord@Monarch         | (12)
+----------------------+
```
### [60]  `032468`
**ES:** Geopaldon
```
+----------------------+
| Geopaldon            | (9)
+----------------------+
```
### [61]  `032479`
**ES:** Woodhead
```
+----------------------+
| Woodhead             | (8)
+----------------------+
```
### [62]  `03248E`
**ES:** Gran@Ninja
```
+----------------------+
| Gran@Ninja           | (10)
+----------------------+
```
### [63]  `03249B`
**ES:** Shakuren
```
+----------------------+
| Shakuren             | (8)
+----------------------+
```
### [64]  `0324B3`
**ES:** Soldados
```
+----------------------+
| Soldados             | (8)
+----------------------+
```
### [65]  `0324BC`
**ES:** Pueblo@de@Monarch
```
+----------------------+
| Pueblo@de@Monarch    | (17)
+----------------------+
```
### [66]  `0324D0`
**ES:** Bestias
```
+----------------------+
| Bestias              | (7)
+----------------------+
```
### [67]  `0324D9`
**ES:** Pueblo@de@Monarch
```
+----------------------+
| Pueblo@de@Monarch    | (17)
+----------------------+
```
### [68]  `0324ED`
**ES:** El@rival
```
+----------------------+
| El@rival             | (8)
+----------------------+
```
### [69]  `0324F7`
**ES:** Geis@Blighty
```
+----------------------+
| Geis@Blighty         | (12)
+----------------------+
```
### [70]  `03251D`
**ES:** ¿Qué tal he luchado, eh?
```
+--------------------------+
| ¿Qué tal he luchado, eh? | (24)
+--------------------------+
```
### [71]  `032551`
**ES:** Ha estado espléndido. Si sigue así, no tendré nada que reprocharle. Jo, jo, jo.
```
+----------------------------------------+
| Ha estado espléndido. Si sigue así, no | (38)
| tendré nada que reprocharle. Jo, jo,   | (36)
| jo.                                    | (3)
+----------------------------------------+
```
### [72]  `0325B9`
**ES:** Bueno, para ser su primer intento, bien. Aún no se ha acostumbrado al combate, lo entiendo. Pero las batallas serán cada vez más duras. Tenga cuidado, señor.
```
+---------------------------------------+
| Bueno, para ser su primer intento,    | (34)
| bien.                                 | (5)
+- - - página - - -+
| Aún no se ha acostumbrado al combate, | (37)
| lo entiendo.                          | (12)
+- - - página - - -+
| Pero las batallas serán cada vez      | (32)
| más duras. Tenga cuidado, señor.      | (32)
+---------------------------------------+
```
### [73]  `032678`
**ES:** Ya lo sé. ¡Todo saldrá bien!
```
+------------------------------+
| Ya lo sé. ¡Todo saldrá bien! | (28)
+------------------------------+
```
### [74]  `0326A6`
**ES:** Bien, sigamos.
```
+----------------------+
| Bien, sigamos.       | (14)
+----------------------+
```
### [75]  `0326D3`
**ES:** Joven amo, tendrá que usar otras tácticas en la próxima batalla.
```
+----------------------------------+
| Joven amo, tendrá que usar otras | (32)
| tácticas en la próxima batalla.  | (31)
+----------------------------------+
```
### [76]  `03271E`
**ES:** Solo debo vencer al enemigo, ¿no?
```
+-----------------------------------+
| Solo debo vencer al enemigo, ¿no? | (33)
+-----------------------------------+
```
### [77]  `03274A`
**ES:** Así es, pero tendrá que abrirse paso por el bosque para ampliar su zona.
```
+--------------------------------------+
| Así es, pero tendrá que abrirse paso | (36)
| por el bosque para ampliar su zona.  | (35)
+--------------------------------------+
```
### [78]  `0327A0`
**ES:** Talar árboles, hacer un puente y atacar, ya lo sé. Hagámoslo ya.
```
+----------------------------------+
| Talar árboles, hacer un puente y | (32)
| atacar, ya lo sé. Hagámoslo ya.  | (31)
+----------------------------------+
```
### [79]  `0327E9`
**ES:** ¡Mi príncipe, aún no he acabado! ¡Espéreme!
```
+----------------------------------+
| ¡Mi príncipe, aún no he acabado! | (32)
| ¡Espéreme!                       | (10)
+----------------------------------+
```
### [80]  `032839`
**ES:** *jadeo* *jadeo* Ya llegué. ¡Mi príncipe! ¡Debe escuchar a sus mayores!
```
+----------------------------+
| *jadeo* *jadeo* Ya llegué. | (26)
| ¡Mi príncipe! ¡Debe        | (19)
| escuchar a sus mayores!    | (23)
+----------------------------+
```
### [81]  `032883`
**ES:** Sí, sí. ¿Qué pasa?
```
+----------------------+
| Sí, sí. ¿Qué pasa?   | (18)
+----------------------+
```
### [82]  `0328A1`
**ES:** Es muy importante pensar cuándo hacer un puente.
```
+--------------------------+
| Es muy importante pensar | (24)
| cuándo hacer un puente.  | (23)
+--------------------------+
```
### [83]  `0328FA`
**ES:** Por ejemplo, aquí...
```
+----------------------+
| Por ejemplo, aquí... | (20)
+----------------------+
```
### [84]  `03291F`
**ES:** ...y aquí. Cuando dé la orden, su soldado irá enseguida a hacer un puente. Si descuida la posición de tropas, podría acabar bajo ataque.
```
+----------------------------+
| ...y aquí.                 | (10)
+- - - página - - -+
| Cuando dé la orden, su     | (22)
| soldado irá enseguida a    | (23)
| hacer un puente.           | (16)
+- - - página - - -+
| Si descuida la posición de | (26)
| tropas, podría acabar      | (21)
| bajo ataque.               | (12)
+----------------------------+
```
### [85]  `0329E8`
**ES:** Ah. Ya veo. Debo esperar a estar listo antes de hacer el puente... Era mi plan. Ja, ja, ja.
```
+----------------------------+
| Ah. Ya veo. Debo esperar a | (26)
| estar listo antes de hacer | (26)
| el puente...               | (12)
+- - - página - - -+
| Era mi plan. Ja, ja, ja.   | (24)
+----------------------------+
```
### [86]  `032A67`
**ES:** Y no es todo. Esta vez hay dos fuerzas enemigas. Debe pensar bien a quién atacar primero. Atacar a ambos a la vez sería una desventaja. Le aconsejo atacar primero al más débil. ¿Entiende?
```
+----------------------------+
| Y no es todo. Esta vez hay | (26)
| dos fuerzas enemigas.      | (21)
+- - - página - - -+
| Debe pensar bien a quién   | (24)
| atacar primero.            | (15)
+- - - página - - -+
| Atacar a ambos a la vez    | (23)
| sería una desventaja.      | (21)
+- - - página - - -+
| Le aconsejo atacar         | (18)
| primero al más débil.      | (21)
| ¿Entiende?                 | (10)
+----------------------------+
```
### [87]  `032B62`
**ES:** Sí, sí.
```
+----------------------+
| Sí, sí.              | (7)
+----------------------+
```
### [88]  `032B71`
**ES:** ¡Lo hicimos! Fácil.
```
+----------------------+
| ¡Lo hicimos! Fácil.  | (19)
+----------------------+
```
### [89]  `032B8C`
**ES:** Jo, jo, jo.
```
+----------------------+
| Jo, jo, jo.          | (11)
+----------------------+
```
### [90]  `032BB1`
**ES:** Bien, sigamos.
```
+----------------------+
| Bien, sigamos.       | (14)
+----------------------+
```
### [91]  `032BD9`
**ES:** Normal Avanzado
```
+----------------------+
| Normal               | (6)
| Avanzado             | (8)
+----------------------+
```
### [92]  `032E51`
**ES:** Mi príncipe... Jejeje...
```
+--------------------------+
| Mi príncipe... Jejeje... | (24)
+--------------------------+
```
### [93]  `032E77`
**ES:** Uh... Me da miedo, abuelo.
```
+----------------------------+
| Uh... Me da miedo, abuelo. | (26)
+----------------------------+
```
### [94]  `032E9E`
**ES:** Por fin te reconocieron como príncipe del reino, y ahora serás un hombre. Je, je...
```
+-----------------------------------+
| Por fin te reconocieron como      | (28)
| príncipe del reino, y ahora serás | (33)
| un hombre. Je, je...              | (20)
+-----------------------------------+
```
### [95]  `032F13`
**ES:** ¡Argh, basta de esa risa! ¿¡Qué pasa ahora!?
```
+---------------------------+
| ¡Argh, basta de esa risa! | (25)
| ¿¡Qué pasa ahora!?        | (18)
+---------------------------+
```
### [96]  `032F4E`
**ES:** Un mensajero trajo una carta del reino vecino de Martika. Martika... Su rey quiere que te cases con su hija.
```
+----------------------------------+
| Un mensajero trajo una carta del | (32)
| reino vecino de Martika.         | (24)
+- - - página - - -+
| Martika... Su rey quiere que te  | (31)
| cases con su hija.               | (18)
+----------------------------------+
```
### [97]  `032FD2`
**ES:** Urgh. Vi a ese hombre una vez. Era un viejo decrépito, como una momia. Si su hija se parece a él... Puaj.
```
+-------------------------------------+
| Urgh. Vi a ese hombre una vez. Era  | (34)
| un viejo decrépito, como una momia. | (35)
| Si su hija se parece a él...        | (28)
+- - - página - - -+
| Puaj.                               | (5)
+-------------------------------------+
```
### [98]  `034C26`
**ES:** ¡Vaya! ¡Destruyeron el nido del Dragón!
```
+--------------------------+
| ¡Vaya!                   | (6)
+- - - página - - -+
| ¡Destruyeron el nido del | (24)
| Dragón!                  | (7)
+--------------------------+
```
### [99]  `034C52`
**ES:** ¿¡Qué!? Nos ayuda... pero adiós al montón de oro...
```
+----------------------------+
| ¿¡Qué!?                    | (7)
+- - - página - - -+
|                            |
+- - - página - - -+
| Nos ayuda... pero adiós al | (26)
| montón de oro...           | (16)
+----------------------------+
```
### [100]  `034CDE`
**ES:** ¡Aaaah! ¡Está lloviendo lava!
```
+-------------------------+
| ¡Aaaah! ¡Está lloviendo | (23)
| lava!                   | (5)
+-------------------------+
```
### [101]  `034D04`
**ES:** ¡El suelo arde!
```
+----------------------+
| ¡El suelo arde!      | (15)
+----------------------+
```
### [102]  `034D1D`
**ES:** ¡Malo! ¡Hay que esperar a que se enfríe! ¡Andar por el suelo en llamas hace muchísimo daño!
```
+---------------------------+
| ¡Malo! ¡Hay que esperar a | (25)
| que se enfríe!            | (14)
+- - - página - - -+
| ¡Andar por el suelo en    | (22)
| llamas hace muchísimo     | (21)
| daño!                     | (5)
+---------------------------+
```
### [103]  `034DAC`
**ES:** Grrr... Grrr... Graaagh...
```
+----------------------------+
| Grrr... Grrr... Graaagh... | (26)
+----------------------------+
```
### [104]  `034DD3`
**ES:** ¡Lo logramos, Al! ¡El Dragón ha caído!
```
+-----------------------+
| ¡Lo logramos, Al! ¡El | (21)
| Dragón ha caído!      | (16)
+-----------------------+
```
### [105]  `034E06`
**ES:** ¡Fiu! Ya no habrá más balas de lava.
```
+-----------------------------+
| ¡Fiu! Ya no habrá más balas | (27)
| de lava.                    | (8)
+-----------------------------+
```
### [106]  `034E41`
**ES:** ¡Todos! ¡Vamos a dar cera!
```
+----------------------+
| ¡Todos! ¡Vamos a dar | (20)
| cera!                | (5)
+----------------------+
```
### [107]  `034E6D`
**ES:** ¡Al ataque!
```
+----------------------+
| ¡Al ataque!          | (11)
+----------------------+
```
### [108]  `034EA6`
**ES:** ¡Eh, eh! ¡Se va a derrumbar!
```
+----------------------+
| ¡Eh, eh! ¡Se va a    | (17)
| derrumbar!           | (10)
+----------------------+
```
### [109]  `034ECC`
**ES:** ¡Cuidado!
```
+----------------------+
| ¡Cuidado!            | (9)
+----------------------+
```
### [110]  `034F04`
**ES:** ¿¡Q-Qué es eso!? ¡Están volando!
```
+----------------------+
| ¿¡Q-Qué es eso!?     | (16)
| ¡Están volando!      | (15)
+----------------------+
```
### [111]  `034F2B`
**ES:** ¡Jinetes de Dragón!
```
+----------------------+
| ¡Jinetes de Dragón!  | (19)
+----------------------+
```
### [112]  `034F47`
**ES:** ¡Sin pánico! ¡Derribadlos!
```
+----------------------------+
| ¡Sin pánico! ¡Derribadlos! | (26)
+----------------------------+
```
### [113]  `034F6D`
**ES:** ¡Aquí no podemos luchar!
```
+--------------------------+
| ¡Aquí no podemos luchar! | (24)
+--------------------------+
```
### [114]  `034F8E`
**ES:** ¿¡Qué!? ¡Aún no! Ampliaremos el territorio como siempre, ¡ya verás!
```
+---------------------------------+
| ¿¡Qué!? ¡Aún no! Ampliaremos    | (28)
| el territorio como siempre, ¡ya | (31)
| verás!                          | (6)
+---------------------------------+
```
### [115]  `034FE6`
**ES:** ¡Qué guay! Al se parece cada vez más a un príncipe.
```
+-----------------------------+
| ¡Qué guay!                  | (10)
+- - - página - - -+
| Al se parece cada vez más a | (27)
| un príncipe.                | (12)
+-----------------------------+
```
### [116]  `03504A`
**ES:** ¡Oh, Djinn! ¡Ven, en nombre del gran Galgundos! ¡Aparece ante mí y lucha por nosotros!
```
+-----------------------------+
| ¡Oh, Djinn! ¡Ven, en nombre | (27)
| del gran Galgundos!         | (19)
+- - - página - - -+
| ¡Aparece ante mí y lucha    | (24)
| por nosotros!               | (13)
+-----------------------------+
```
### [117]  `0350BF`
**ES:** ¿Eh? ¿Quién me llama?
```
+-----------------------+
| ¿Eh? ¿Quién me llama? | (21)
+-----------------------+
```
### [118]  `0350DE`
**ES:** ¡Cierto! ¡Derrota a ese mocoso, por Lord Galgundos!
```
+----------------------------+
| ¡Cierto!                   | (8)
+- - - página - - -+
| ¡Derrota a ese mocoso, por | (26)
| Lord Galgundos!            | (15)
+----------------------------+
```
### [119]  `035135`
**ES:** Vale. Ahora mismito le doy una tunda.
```
+----------------------------+
| Vale. Ahora mismito le doy | (26)
| una tunda.                 | (10)
+----------------------------+
```
### [120]  `035193`
**ES:** ¡Ahora! ¡Cuento contigo, Heynee!
```
+--------------------------+
| ¡Ahora! ¡Cuento contigo, | (24)
| Heynee!                  | (7)
+--------------------------+
```
### [121]  `0351B7`
**ES:** ¡Vamos! ¡Le enseñaré a esa puerta quién manda!
```
+---------------------------+
| ¡Vamos!                   | (7)
+- - - página - - -+
| ¡Le enseñaré a esa puerta | (25)
| quién manda!              | (12)
+---------------------------+
```
### [122]  `035214`
**ES:** Si recitas el hechizo dentro de la marca de Koh Monn, el Djinn aparecerá.
```
+------------------------------+
| Si recitas el hechizo dentro | (28)
| de la marca de Koh Monn, el  | (27)
| Djinn aparecerá.             | (16)
+------------------------------+
```
### [123]  `035261`
**ES:** Vale, vamos allá. ¡Oh, Djinn! ¡Ven, en nombre del príncipe Alfred!
```
+-----------------------------+
| Vale, vamos allá.           | (17)
+- - - página - - -+
| ¡Oh, Djinn! ¡Ven, en nombre | (27)
| del príncipe Alfred!        | (20)
+-----------------------------+
```
### [124]  `0352C1`
**ES:** *bostezo* Ohhh, parece que me ha invocado otro niñito adorable.
```
+----------------------------+
| *bostezo* Ohhh, parece que | (26)
| me ha invocado otro niñito | (26)
| adorable.                  | (9)
+----------------------------+
```
### [125]  `03530A`
**ES:** ¡Oye, que no soy un niño! Me llamo Alfred y soy tu amo.
```
+------------------------------+
| ¡Oye, que no soy un niño! Me | (28)
| llamo Alfred y soy tu amo.   | (26)
+------------------------------+
```
### [126]  `035344`
**ES:** Entendido. Soy Heynee. ¿Y qué quieres que haga?
```
+--------------------------+
| Entendido. Soy Heynee.   | (22)
+- - - página - - -+
| ¿Y qué quieres que haga? | (24)
+--------------------------+
```
### [127]  `03537B`
**ES:** ¡Ve y dales una tunda! Son esbirros de Galgundos. ¿Puedes, Heynee?
```
+------------------------+
| ¡Ve y dales una tunda! | (22)
+- - - página - - -+
| Son esbirros de        | (15)
| Galgundos. ¿Puedes,    | (19)
| Heynee?                | (7)
+------------------------+
```
### [128]  `0353D2`
**ES:** ¿Galgundos, has dicho? Me vale. Odio a ese tío, es un negrero.
```
+--------------------------------+
| ¿Galgundos, has dicho?         | (22)
+- - - página - - -+
| Me vale. Odio a ese tío, es un | (30)
| negrero.                       | (8)
+--------------------------------+
```
### [129]  `035428`
**ES:** ¡Genial! ¡Somos cien veces más fuertes!
```
+----------------------------+
| ¡Genial! ¡Somos cien veces | (26)
| más fuertes!               | (12)
+----------------------------+
```
### [130]  `035455`
**ES:** Llévame conmigo hasta Galgundos. Está tras un portón haciendo sus hechizos. Es enorme. Nadie puede abrirlo.
```
+------------------------+
| Llévame conmigo hasta  | (21)
| Galgundos.             | (10)
+- - - página - - -+
| Está tras un portón    | (19)
| haciendo sus hechizos. | (22)
+- - - página - - -+
| Es enorme. Nadie puede | (22)
| abrirlo.               | (8)
+------------------------+
```
### [131]  `0354F0`
**ES:** ¿Eh? ¿Y cómo lo derrotamos entonces?
```
+----------------------------+
| ¿Eh? ¿Y cómo lo derrotamos | (26)
| entonces?                  | (9)
+----------------------------+
```
### [132]  `03551F`
**ES:** Esa puerta es tocha, ¡pero mis brazos no son broma! ¡Puedo abrirla!
```
+----------------------------+
| Esa puerta es tocha, ¡pero | (26)
| mis brazos no son broma!   | (24)
| ¡Puedo abrirla!            | (15)
+----------------------------+
```
### [133]  `035579`
**ES:** Ya veo. Entonces cuento contigo, Heynee.
```
+-------------------------+
| Ya veo. Entonces cuento | (23)
| contigo, Heynee.        | (16)
+-------------------------+
```
### [134]  `0355A8`
**ES:** ¡Divertido! Pero si me agoto abriendo la puerta, no llegarás hasta él.
```
+---------------------------+
| ¡Divertido!               | (11)
+- - - página - - -+
|                           |
+- - - página - - -+
| Pero si me agoto abriendo | (25)
| la puerta, no llegarás    | (22)
| hasta él.                 | (9)
+---------------------------+
```
### [135]  `035649`
**ES:** Urgh. No me siento bien. Me desvanezco.
```
+-----------------------------+
| Urgh. No me siento bien. Me | (27)
| desvanezco.                 | (11)
+-----------------------------+
```
### [136]  `035697`
**ES:** ¿¡A qué esperan!? ¡Sigan luchando!
```
+----------------------+
| ¿¡A qué esperan!?    | (17)
| ¡Sigan luchando!     | (16)
+----------------------+
```
### [137]  `0356BF`
**ES:** Urgh. Aquí acabó... ¡Bleurgh!
```
+-------------------------------+
| Urgh. Aquí acabó... ¡Bleurgh! | (29)
+-------------------------------+
```
### [138]  `0356E0`
**ES:** ¡Argh, menuda decepción! ¡Yo me ocuparé!
```
+--------------------------+
| ¡Argh, menuda decepción! | (24)
+- - - página - - -+
| ¡Yo me ocuparé!          | (15)
+--------------------------+
```
### [139]  `035740`
**ES:** *snif* Lo siento. No puedo seguir.
```
+----------------------------+
| *snif* Lo siento. No puedo | (26)
| seguir.                    | (7)
+----------------------------+
```
### [140]  `035767`
**ES:** ¡No digas eso, Heynee! ¡Tú puedes!
```
+----------------------------+
| ¡No digas eso, Heynee! ¡Tú | (26)
| puedes!                    | (7)
+----------------------------+
```
### [141]  `035790`
**ES:** *suspiro* Quería ver a Galgundos morder el polvo...
```
+------------------------------+
| *suspiro* Quería ver a       | (22)
| Galgundos morder el polvo... | (28)
+------------------------------+
```
### [142]  `0357D0`
**ES:** ¡No puedes morir ahora! ¡Reacciona!
```
+-------------------------+
| ¡No puedes morir ahora! | (23)
| ¡Reacciona!             | (11)
+-------------------------+
```
### [143]  `0357FD`
**ES:** Jejeje... Fue divertido luchar contigo...
```
+--------------------------------+
| Jejeje... Fue divertido luchar | (30)
| contigo...                     | (10)
+--------------------------------+
```
### [144]  `035829`
**ES:** ...Bleurgh!
```
+----------------------+
| ...Bleurgh!          | (11)
+----------------------+
```
### [145]  `035851`
**ES:** Urgh... ¿Cómo derrotaré ahora a Galgundos...? Se acabó...
```
+-------------------------+
| Urgh... ¿Cómo derrotaré | (23)
| ahora a Galgundos...?   | (21)
+- - - página - - -+
| Se acabó...             | (11)
+-------------------------+
```
### [146]  `0358A4`
**ES:** ¡Todos! ¡La batalla final! ¡Dad lo mejor! ¡Sin arrepentimientos!
```
+-------------------------+
| ¡Todos!                 | (7)
+- - - página - - -+
| ¡La batalla final! ¡Dad | (23)
| lo mejor! ¡Sin          | (14)
| arrepentimientos!       | (17)
+-------------------------+
```
### [147]  `035901`
**ES:** ¡A cargar!
```
+----------------------+
| ¡A cargar!           | (10)
+----------------------+
```
### [148]  `03592E`
**ES:** Vale, debería poder abrir esta puertecita...
```
+---------------------------+
| Vale, debería poder abrir | (25)
| esta puertecita...        | (18)
+---------------------------+
```
### [149]  `03596B`
**ES:** ¡Empujad!
```
+----------------------+
| ¡Empujad!            | (9)
+----------------------+
```
### [150]  `035977`
**ES:** ¡Empujad!
```
+----------------------+
| ¡Empujad!            | (9)
+----------------------+
```
### [151]  `03599D`
**ES:** *criiiic*
```
+----------------------+
| *criiiic*            | (9)
+----------------------+
```
### [152]  `0359C9`
**ES:** ¡Sí! ¡Puerta abierta!
```
+-----------------------+
| ¡Sí! ¡Puerta abierta! | (21)
+-----------------------+
```
### [153]  `0359E5`
**ES:** ¡Adelante! ¡A por Galgundos!
```
+----------------------+
| ¡Adelante! ¡A por    | (17)
| Galgundos!           | (10)
+----------------------+
```
### [154]  `035A11`
**ES:** ¡A ellos!
```
+----------------------+
| ¡A ellos!            | (9)
+----------------------+
```
### [155]  `035A46`
**ES:** ¡Aaaah! ¡Los caídos vuelven como zombis!
```
+-----------------------------+
| ¡Aaaah! ¡Los caídos vuelven | (27)
| como zombis!                | (12)
+-----------------------------+
```
### [156]  `035A80`
**ES:** Urgh... ¡Maldito Geis! ¡Qué bajo cae!?
```
+------------------------+
| Urgh... ¡Maldito Geis! | (22)
| ¡Qué bajo cae!?        | (15)
+------------------------+
```
### [157]  `035ADA`
**ES:** Hora de volar cosas. ¡Aparta!
```
+----------------------+
| Hora de volar cosas. | (20)
| ¡Aparta!             | (8)
+----------------------+
```
### [158]  `035B0B`
**ES:** ¡Ah! ¡Al! ¡Esa tropa lleva una bomba!
```
+--------------------------------+
| ¡Ah! ¡Al! ¡Esa tropa lleva una | (30)
| bomba!                         | (6)
+--------------------------------+
```
### [159]  `035B34`
**ES:** ¡Maldito Geis! ¡Vaya planes más raros! Chicos, derrotadlo antes de que explote, ¿vale?
```
+--------------------------+
| ¡Maldito Geis! ¡Vaya     | (20)
| planes más raros!        | (17)
+- - - página - - -+
| Chicos, derrotadlo antes | (24)
| de que explote, ¿vale?   | (22)
+--------------------------+
```
### [160]  `035B91`
**ES:** ¡Uoooo--
```
+----------------------+
| ¡Uoooo--             | (8)
+----------------------+
```
### [161]  `035B9C`
**ES:** ...¿Eh?
```
+----------------------+
| ...¿Eh?              | (7)
+----------------------+
```
### [162]  `035BD2`
**ES:** Grrrr... ¡Exploto!
```
+----------------------+
| Grrrr... ¡Exploto!   | (18)
+----------------------+
```
### [163]  `035BEC`
**ES:** ¡Uwaaah! ¡Corred!
```
+----------------------+
| ¡Uwaaah! ¡Corred!    | (17)
+----------------------+
```
### [164]  `035C2B`
**ES:** ¡Bien! ¡Una Piedra Clave sellada!
```
+--------------------------+
| ¡Bien! ¡Una Piedra Clave | (24)
| sellada!                 | (8)
+--------------------------+
```
### [165]  `035C5C`
**ES:** Hemos sellado
```
+----------------------+
| Hemos sellado        | (13)
+----------------------+
```
### [166]  `035C7A`
**ES:** de 8 Piedras Clave, y Geis ha destruido
```
+-------------------------------+
| de 8 Piedras Clave, y Geis ha | (29)
| destruido                     | (9)
+-------------------------------+
```
### [167]  `035CAE`
**ES:** de ellas.
```
+----------------------+
| de ellas.            | (9)
+----------------------+
```
### [168]  `035CBB`
**ES:** ¡Ánimo!
```
+----------------------+
| ¡Ánimo!              | (7)
+----------------------+
```
### [169]  `035CF4`
**ES:** ¡Por fin!
```
+----------------------+
| ¡Por fin!            | (9)
+----------------------+
```
### [170]  `035D02`
**ES:** ¡Lo logramos! ¡Ocho sellos activos!
```
+----------------------------+
| ¡Lo logramos! ¡Ocho sellos | (26)
| activos!                   | (8)
+----------------------------+
```
### [171]  `035E07`
**ES:** ¡Wajajaja! ¡Ya estamos a salvo! ¡Todos! ¡Hora de dar cera!
```
+--------------------------+
| ¡Wajajaja! ¡Ya estamos a | (24)
| salvo! ¡Todos! ¡Hora de  | (23)
| dar cera!                | (9)
+--------------------------+
```
### [172]  `035E66`
**ES:** ¡A ellos!
```
+----------------------+
| ¡A ellos!            | (9)
+----------------------+
```
### [173]  `035E81`
**ES:** Mnngh, no te creas tanto... ¡No necesito subordinados para derrotarte! ¡Charly, el soldado bomba! ¡Es tu turno!
```
+--------------------------------+
| Mnngh, no te creas tanto...    | (27)
+- - - página - - -+
| ¡No necesito subordinados      | (25)
| para derrotarte!               | (16)
+- - - página - - -+
| ¡Charly, el soldado bomba! ¡Es | (30)
| tu turno!                      | (9)
+--------------------------------+
```
### [174]  `035EFF`
**ES:** ¡Urgh! ¡Otra vez ese tío!
```
+---------------------------+
| ¡Urgh! ¡Otra vez ese tío! | (25)
+---------------------------+
```
### [175]  `035F46`
**ES:** ¡Oh, no! ¡Príncipe, una Piedra Clave!
```
+-------------------------+
| ¡Oh, no! ¡Príncipe, una | (23)
| Piedra Clave!           | (13)
+-------------------------+
```
### [176]  `035F8F`
**ES:** Jejeje. ¡He destruido
```
+-----------------------+
| Jejeje. ¡He destruido | (21)
+-----------------------+
```
### [177]  `035FAC`
**ES:** Piedras Clave! Deseo ver la cara llorosa de Alfred al destruir las ocho...
```
+---------------------------+
| Piedras Clave!            | (14)
+- - - página - - -+
| Deseo ver la cara llorosa | (25)
| de Alfred al destruir las | (25)
| ocho...                   | (7)
+---------------------------+
```
### [178]  `03600F`
**ES:** ¡Oh, no! ¡La última!
```
+----------------------+
| ¡Oh, no! ¡La última! | (20)
+----------------------+
```
### [179]  `03602B`
**ES:** ¡Ujajajaja! ¡Más te vale prepararte!
```
+--------------------------+
| ¡Ujajajaja! ¡Más te vale | (24)
| prepararte!              | (11)
+--------------------------+
```
### [180]  `03605C`
**ES:** ¡E-Estás loco! ¿¡Sabes lo que acabas de hacer!?
```
+---------------------------+
| ¡E-Estás loco! ¿¡Sabes lo | (25)
| que acabas de hacer!?     | (21)
+---------------------------+
```
### [181]  `036091`
**ES:** Lo sé... Por eso lo hice. Si yo no tengo a Rubia, nadie la tendrá...
```
+---------------------------+
| Lo sé... Por eso lo hice. | (25)
+- - - página - - -+
| Si yo no tengo a Rubia,   | (23)
| nadie la tendrá...        | (18)
+---------------------------+
```
### [182]  `0360E3`
**ES:** Tu alianza con Geis acabó. ¡Enfréntate a él como un hombre!
```
+----------------------------+
| Tu alianza con Geis acabó. | (26)
| ¡Enfréntate a él como un   | (24)
| hombre!                    | (7)
+----------------------------+
```
### [183]  `036143`
**ES:** No olvides colocarte en el centro de la marca de Koh Monn para invocar al Djinn.
```
+-----------------------------+
| No olvides colocarte en el  | (26)
| centro de la marca de Koh   | (25)
| Monn para invocar al Djinn. | (27)
+-----------------------------+
```
### [184]  `0361A0`
**ES:** ¡Se acabó la espera! Rubia está a salvo. Céntrate en tu disputa con Geis.
```
+------------------------------+
| ¡Se acabó la espera!         | (20)
+- - - página - - -+
| Rubia está a salvo. Céntrate | (28)
| en tu disputa con Geis.      | (23)
+------------------------------+
```
### [185]  `036202`
**ES:** Te cuento mi plan. ¡Derrota al Ejército Azul en 5 días!
```
+------------------------------+
| Te cuento mi plan.           | (18)
+- - - página - - -+
| ¡Derrota al Ejército Azul en | (28)
| 5 días!                      | (7)
+------------------------------+
```
### [186]  `036265`
**ES:** ¿¡5 días!?
```
+----------------------+
| ¿¡5 días!?           | (10)
+----------------------+
```
### [187]  `036275`
**ES:** ¡Ajá! Al empezar, abrete paso hasta el campamento del Ejército Azul. Luego ve tú y destruye sus territorios. Si insistes, caerá en un abrir y cerrar de ojos.
```
+----------------------------+
| ¡Ajá! Al empezar, abrete   | (24)
| paso hasta el campamento   | (24)
| del Ejército Azul.         | (18)
+- - - página - - -+
| Luego ve tú y destruye sus | (26)
| territorios.               | (12)
+- - - página - - -+
| Si insistes, caerá en un   | (24)
| abrir y cerrar de ojos.    | (23)
+----------------------------+
```
### [188]  `036345`
**ES:** ¿Y los monstruos...?
```
+----------------------+
| ¿Y los               | (6)
| monstruos...?        | (13)
+----------------------+
```
### [189]  `036367`
**ES:** Por ahora ignóralos. Cuando seas lo bastante fuerte, podrás ir a derrotarlos.
```
+-----------------------------+
| Por ahora ignóralos. Cuando | (27)
| seas lo bastante fuerte,    | (24)
| podrás ir a derrotarlos.    | (24)
+-----------------------------+
```
### [190]  `0363C1`
**ES:** Entiendo. Probad.
```
+----------------------+
| Entiendo. Probad.    | (17)
+----------------------+
```
### [191]  `03872B`
**ES:** ¡Geis está desesperado! Si el Gigante despierta, se acaba todo, ¡para nosotros y para todos!
```
+------------------------------+
| ¡Geis está desesperado!      | (23)
+- - - página - - -+
| Si el Gigante despierta, se  | (27)
| acaba todo, ¡para nosotros y | (28)
| para todos!                  | (11)
+------------------------------+
```
### [192]  `038795`
**ES:** ¡Completa los ocho sellos para evitarlo! El ejército de Geis intentará destruirlos, así que debes llevar la iniciativa. Si Geis destruye todas las Piedras Clave, el Gigante despertará de verdad y... Lo pasaremos muy mal.
```
+-------------------------------+
| ¡Completa los ocho sellos     | (25)
| para evitarlo!                | (14)
+- - - página - - -+
| El ejército de Geis intentará | (29)
| destruirlos, así que debes    | (26)
| llevar la iniciativa.         | (21)
+- - - página - - -+
| Si Geis destruye todas las    | (26)
| Piedras Clave, el Gigante     | (25)
| despertará de verdad y...     | (25)
+- - - página - - -+
| Lo pasaremos muy mal.         | (21)
+-------------------------------+
```
### [193]  `038885`
**ES:** ¡Vaya lío! Aquí los enemigos son muy fuertes. Urdí un plan, pero...
```
+---------------------------+
| ¡Vaya lío! Aquí los       | (19)
| enemigos son muy fuertes. | (25)
+- - - página - - -+
| Urdí un plan, pero...     | (21)
+---------------------------+
```
### [194]  `0388D9`
**ES:** ¿Quieres escucharlo?
```
+----------------------+
| ¿Quieres escucharlo? | (20)
+----------------------+
```
### [195]  `0388FB`
**ES:** Nah, ya se me ocurrirá algo.
```
+------------------------------+
| Nah, ya se me ocurrirá algo. | (28)
+------------------------------+
```
### [196]  `03891E`
**ES:** ¡Sí! ¡Cuéntamelo!
```
+----------------------+
| ¡Sí! ¡Cuéntamelo!    | (17)
+----------------------+
```
### [197]  `038947`
**ES:** Cree en ti y salva a la princesa Rubia.
```
+-------------------------+
| Cree en ti y salva a la | (23)
| princesa Rubia.         | (15)
+-------------------------+
```
### [198]  `03897D`
**ES:** Si Heynee cae derrotado, ¡nunca podremos abrir esa puerta pesada!
```
+--------------------------+
| Si Heynee cae derrotado, | (24)
| ¡nunca podremos abrir    | (21)
| esa puerta pesada!       | (18)
+--------------------------+
```
### [199]  `0389C4`
**ES:** Heynee debe caer ante Galgundos. Si Heynee cae, todo acabó.
```
+----------------------------+
| Heynee debe caer ante      | (21)
| Galgundos.                 | (10)
+- - - página - - -+
| Si Heynee cae, todo acabó. | (26)
+----------------------------+
```
### [200]  `038A1F`
**ES:** Si Rubia muere, todo acaba. Primero, derrota a los bandidos. Lucharás junto a Sir Geis: no puedes atacarlo.
```
+----------------------------+
| Si Rubia muere, todo       | (20)
| acaba.                     | (6)
+- - - página - - -+
| Primero, derrota a los     | (22)
| bandidos.                  | (9)
+- - - página - - -+
| Lucharás junto a Sir Geis: | (26)
| no puedes atacarlo.        | (19)
+----------------------------+
```
### [201]  `038AB2`
**ES:** ¡Tu objetivo aquí es salvar a más gente que tu rival! Veamos...
```
+-------------------------------+
| ¡Tu objetivo aquí es salvar a | (29)
| más gente que tu rival!       | (23)
+- - - página - - -+
| Veamos...                     | (9)
+-------------------------------+
```
### [202]  `038B00`
**ES:** ¡La princesa se enfadará si no tienes 50.000 G al vencer a todos los enemigos! Mientras tengas dinero suficiente, haz lo que sueles hacer.
```
+--------------------------------+
| ¡La princesa se enfadará si    | (27)
| no tienes 50.000 G al vencer a | (30)
| todos los enemigos!            | (19)
+- - - página - - -+
|                                |
+- - - página - - -+
| Mientras tengas dinero         | (22)
| suficiente, haz lo que         | (22)
| sueles hacer.                  | (13)
+--------------------------------+
```
### [203]  `038BAB`
**ES:** ¡Debes ordenar a tus soldados que completen los sellos!
```
+-------------------------------+
| ¡Debes ordenar a tus soldados | (29)
| que completen los sellos!     | (25)
+-------------------------------+
```
### [204]  `038BF2`
**ES:** Simple: derrotar a todos los enemigos... ¡Pero esta vez cuesta más! ¡Cuidado!
```
+------------------------------+
| Simple: derrotar a todos los | (28)
| enemigos...                  | (11)
+- - - página - - -+
| ¡Pero esta vez cuesta más!   | (26)
| ¡Cuidado!                    | (9)
+------------------------------+
```
### [205]  `038C5E`
**ES:** Aquí hay un enemigo temible... ¡Charly, el bomba! Se acercará sigilosamente a tus soldados... Y cuando llegue a su objetivo... ¡BOOM! ¡Explotará!
```
+-----------------------------+
| Aquí hay un enemigo         | (19)
| temible...                  | (10)
+- - - página - - -+
| ¡Charly, el bomba!          | (18)
+- - - página - - -+
| Se acercará sigilosamente a | (27)
| tus soldados...             | (15)
+- - - página - - -+
| Y cuando llegue a su        | (20)
| objetivo...                 | (11)
+- - - página - - -+
| ¡BOOM! ¡Explotará!          | (18)
+-----------------------------+
```
### [206]  `038D04`
**ES:** ¡Son... zombis! Si tus soldados caen ante ellos, se convertirán también en zombis. Manda a tus soldados más fuertes a luchar contra ellos y no debería haber problema.
```
+-------------------------------+
| ¡Son...                       | (7)
+- - - página - - -+
| zombis! Si tus soldados caen  | (28)
| ante ellos, se convertirán    | (26)
| también en zombis.            | (18)
+- - - página - - -+
| Manda a tus soldados más      | (24)
| fuertes a luchar contra ellos | (29)
| y no debería haber problema.  | (28)
+-------------------------------+
```
### [207]  `038DC2`
**ES:** Puerta demasiado pesada: solo Heynee la mueve.
```
+--------------------------+
| Puerta demasiado pesada: | (24)
| solo Heynee la mueve.    | (21)
+--------------------------+
```
### [208]  `038E0B`
**ES:** Coloca a Heynee ante la puerta para abrirla.
```
+-------------------------+
| Coloca a Heynee ante la | (23)
| puerta para abrirla.    | (20)
+-------------------------+
```
### [209]  `038E62`
**ES:** ¡Puedes invocar a un Djinn si vas al centro de la marca de Koh Monn! Mientras estés en el centro, podrás dar órdenes al Djinn, Al. ¡Pero cuidado con tu propia salud mientras lo controlas!
```
+-------------------------------+
| ¡Puedes invocar a un Djinn si | (29)
| vas al centro de la marca de  | (28)
| Koh Monn!                     | (9)
+- - - página - - -+
| Mientras estés en el          | (20)
| centro, podrás dar            | (18)
| órdenes al Djinn, Al.         | (21)
+- - - página - - -+
| ¡Pero cuidado con tu propia   | (27)
| salud mientras lo controlas!  | (28)
+-------------------------------+
```
### [210]  `038F3A`
**ES:** Todo a oscuras... Vemos un poco en torno al territorio. Avanzando con cuidado, bastará.
```
+----------------------+
| Todo a oscuras...    | (17)
+- - - página - - -+
| Vemos un poco en     | (16)
| torno al territorio. | (20)
+- - - página - - -+
| Avanzando con        | (13)
| cuidado, bastará.    | (17)
+----------------------+
```
### [211]  `038FDC`
**ES:** ¡Mira, son fuentes de magma! El suelo de alrededor se convertirá en lava. Tendrás que acercarte tú mismo a la fuente de magma, Al. ¡La Gota Fría detendrá la fuente por un tiempo!
```
+-----------------------------+
| ¡Mira, son fuentes de       | (21)
| magma!                      | (6)
+- - - página - - -+
| El suelo de alrededor se    | (24)
| convertirá en lava.         | (19)
+- - - página - - -+
| Tendrás que acercarte tú    | (24)
| mismo a la fuente de magma, | (27)
| Al.                         | (3)
+- - - página - - -+
| ¡La Gota Fría detendrá la   | (25)
| fuente por un tiempo!       | (21)
+-----------------------------+
```
### [212]  `0390A0`
**ES:** En esa pequeña isla del centro hay un objeto que Shakuren nos dejó... la Gota Fría. Con ese objeto, Al puede andar sobre la lava... ¡y convertirla en suelo normal!
```
+--------------------------+
| En esa pequeña isla del  | (23)
| centro hay un objeto que | (24)
| Shakuren nos dejó...     | (20)
+- - - página - - -+
| la Gota Fría.            | (13)
+- - - página - - -+
| Con ese objeto, Al puede | (24)
| andar sobre la lava...   | (22)
+- - - página - - -+
| ¡y convertirla en suelo  | (23)
| normal!                  | (7)
+--------------------------+
```
### [213]  `039155`
**ES:** Hay un Dragón de Fuego. ¡Escupirá lava a tus tropas más fuertes! ¡Esas balas son muy peligrosas! Al impactar, causan mucho daño... ¡Además, el suelo seguirá ardiendo un tiempo! No hay más remedio que esperar a que el suelo deje de arder.
```
+-----------------------------+
| Hay un Dragón de Fuego.     | (23)
+- - - página - - -+
| ¡Escupirá lava a tus tropas | (27)
| más fuertes!                | (12)
+- - - página - - -+
| ¡Esas balas son muy         | (19)
| peligrosas!                 | (11)
+- - - página - - -+
| Al impactar, causan mucho   | (25)
| daño...                     | (7)
+- - - página - - -+
| ¡Además, el suelo seguirá   | (25)
| ardiendo un tiempo!         | (19)
+- - - página - - -+
| No hay más remedio que      | (22)
| esperar a que el suelo deje | (27)
| de arder.                   | (9)
+-----------------------------+
```
### [214]  `039277`
**ES:** En esta isla hay una Salamandra monstruosa. Les encanta el oro... Robarán en tu castillo y en tus ciudades. Para ahuyentarla, ¡destruye su nido! ¡Pero cuidado! ¡Lo protege una cría!
```
+-----------------------------+
| En esta isla hay una        | (20)
| Salamandra monstruosa.      | (22)
+- - - página - - -+
| Les encanta el oro...       | (21)
+- - - página - - -+
| Robarán en tu castillo y en | (27)
| tus ciudades.               | (13)
+- - - página - - -+
| Para ahuyentarla, ¡destruye | (27)
| su nido!                    | (8)
+- - - página - - -+
| ¡Pero cuidado! ¡Lo protege  | (26)
| una cría!                   | (9)
+-----------------------------+
```
### [215]  `039388`
**ES:** Lo más difícil es lidiar con las consecuencias del tsunami. Tendrás que construir un puente laaargo para llegar a las otras islas. ¡Usa barcos siempre que puedas!
```
+------------------------------+
|                              |
+- - - página - - -+
| Lo más difícil es lidiar con | (28)
| las consecuencias del        | (21)
| tsunami.                     | (8)
+- - - página - - -+
| Tendrás que construir un     | (24)
| puente laaargo para llegar   | (26)
| a las otras islas.           | (18)
+- - - página - - -+
| ¡Usa barcos siempre          | (19)
| que puedas!                  | (11)
+------------------------------+
```
### [216]  `039435`
**ES:** El tsunami se lo llevará todo, amigo o enemigo. Pero ¡tranquilo! En terreno alto estarás a salvo.
```
+-----------------------------+
| El tsunami se lo llevará    | (24)
| todo, amigo o enemigo.      | (22)
+- - - página - - -+
|                             |
+- - - página - - -+
| Pero ¡tranquilo! En terreno | (27)
| alto estarás a salvo.       | (21)
+-----------------------------+
```
### [217]  `0394BD`
**ES:** La corriente de esta zona es muy fuerte. Los puentes se romperán al cabo de un tiempo. ¡Si tus tropas están en un puente cuando se rompa, caerán al vacío! Repara los puentes continuamente para evitarlo.
```
+------------------------------+
| La corriente de esta zona    | (25)
| es muy fuerte.               | (14)
+- - - página - - -+
| Los puentes se romperán al   | (26)
| cabo de un tiempo.           | (18)
+- - - página - - -+
| ¡Si tus tropas están en un   | (26)
| puente cuando se rompa,      | (23)
| caerán al vacío!             | (16)
+- - - página - - -+
| Repara los puentes           | (18)
| continuamente para evitarlo. | (28)
+------------------------------+
```
### [218]  `0395C0`
**ES:** Ese es Piper-Man. ¡Su flauta hechiza a tus tropas! Si quedan hechizadas, irán a su tienda... ¡y volverán como enemigos! Para evitarlo, destruye la tienda. Sin la tienda, Piper-Man se marchará.
```
+------------------------------+
| Ese es Piper-Man. ¡Su flauta | (28)
| hechiza a tus tropas!        | (21)
+- - - página - - -+
| Si quedan hechizadas, irán   | (26)
| a su tienda... ¡y volverán   | (26)
| como enemigos!               | (14)
+- - - página - - -+
| Para evitarlo, destruye      | (23)
| la tienda.                   | (10)
+- - - página - - -+
| Sin la tienda, Piper-Man se  | (27)
| marchará.                    | (9)
+------------------------------+
```
### [219]  `0396C6`
**ES:** Los árboles de esta zona son peligrosos. Se retuercen y, si los ignoras, ¡se multiplicarán! Usa vallas para frenar el bosque. Si matas los árboles del centro, los pequeños se marchitarán. Pero ¡los grandes se fortalecen con el tiempo!
```
+-----------------------------+
| Los árboles de esta zona    | (24)
| son peligrosos.             | (15)
+- - - página - - -+
| Se retuercen y, si los      | (22)
| ignoras, ¡se multiplicarán! | (27)
+- - - página - - -+
| Usa vallas para frenar el   | (25)
| bosque.                     | (7)
+- - - página - - -+
| Si matas los árboles del    | (24)
| centro, los pequeños se     | (23)
| marchitarán.                | (12)
+- - - página - - -+
| Pero ¡los grandes se        | (20)
| fortalecen con el tiempo!   | (25)
+-----------------------------+
```
### [220]  `03980B`
**ES:** Esas estatuas horribles se llaman Cabezas del Bosque. Protegen el bosque. Si talas alrededor, se enfadarán y el bosque volverá a crecer. Si los talas otra vez, ¡se enfadarán DE VERDAD y te escupirán fuego!
```
+------------------------------+
| Esas estatuas horribles se   | (26)
| llaman Cabezas del Bosque.   | (26)
+- - - página - - -+
| Protegen el bosque. Si talas | (28)
| alrededor, se enfadarán y el | (28)
| bosque volverá a crecer.     | (24)
+- - - página - - -+
| Si los talas otra vez, ¡se   | (26)
| enfadarán DE VERDAD y te     | (24)
| escupirán fuego!             | (16)
+------------------------------+
```
### [221]  `039900`
**ES:** Sus cuevas se ocultan en el bosque. ¡Reclámalo y búscalas!
```
+--------------------------+
| Sus cuevas se ocultan en | (24)
| el bosque.               | (10)
+- - - página - - -+
| ¡Reclámalo y búscalas!   | (22)
+--------------------------+
```
### [222]  `03995B`
**ES:** Cuando empiece la ventisca hará mucho frío y tus tropas se moverán despacio. Con esquís se moverían con normalidad.
```
+------------------------------+
| Cuando empiece la ventisca   | (26)
| hará mucho frío y tus tropas | (28)
| se moverán despacio.         | (20)
+- - - página - - -+
| Con esquís se moverían con   | (26)
| normalidad.                  | (11)
+------------------------------+
```
### [223]  `0399F8`
**ES:** El terreno de por aquí es muy accidentado. ¡Ahí no podrás construir tu territorio! Busca suelo normal.
```
+---------------------------+
| El terreno de por aquí es | (25)
| muy accidentado.          | (16)
+- - - página - - -+
| ¡Ahí no podrás construir  | (24)
| tu territorio!            | (14)
+- - - página - - -+
| Busca suelo normal.       | (19)
+---------------------------+
```
### [224]  `039A89`
**ES:** Alíate con Geis para salvar a Rubia. No lo ataques aún. ¡Derrota antes a los bandidos!
```
+-----------------------------+
| Alíate con Geis para salvar | (27)
| a Rubia.                    | (8)
+- - - página - - -+
| No lo ataques aún.          | (18)
+- - - página - - -+
| ¡Derrota antes a los        | (20)
| bandidos!                   | (9)
+-----------------------------+
```
### [225]  `039B20`
**ES:** ¡Mira, el Orbe de los Monstruos! ¡Se aliarán con quien lo posea!
```
+--------------------------+
| ¡Mira, el Orbe de los    | (21)
| Monstruos!               | (10)
+- - - página - - -+
| ¡Se aliarán con quien lo | (24)
| posea!                   | (6)
+--------------------------+
```
### [226]  `039B88`
**ES:** Deja un soldado de guardia junto al Orbe.
```
+----------------------------+
| Deja un soldado de guardia | (26)
| junto al Orbe.             | (14)
+----------------------------+
```
### [227]  `039BC3`
**ES:** Príncipe, aquí no basta vencer. Salva al doctor y asistentes antes que Geis. Si no salvas a más gente que él, la princesa se enfadará. Como con los cofres, ve tú a rescatarlos. ¡Suerte!
```
+------------------------------+
| Príncipe, aquí no basta      | (23)
| vencer.                      | (7)
+- - - página - - -+
| Salva al doctor y            | (17)
| asistentes antes que         | (20)
| Geis.                        | (5)
+- - - página - - -+
| Si no salvas a más gente que | (28)
| él, la princesa se enfadará. | (28)
+- - - página - - -+
| Como con los cofres, ve tú a | (28)
| rescatarlos. ¡Suerte!        | (21)
+------------------------------+
```
### [228]  `039CD7`
**ES:** ¡Un cofre! Solo tú puedes abrirlo, príncipe. ¡Ábrelos cuando puedas!
```
+-------------------------+
| ¡Un cofre!              | (10)
+- - - página - - -+
| Solo tú puedes abrirlo, | (23)
| príncipe.               | (9)
+- - - página - - -+
| ¡Ábrelos cuando puedas! | (23)
+-------------------------+
```
### [229]  `039D6C`
**ES:** ¡Ciudad neutral! Al conquistarla, Johnny trae el dinero. Solo tú conquistas ciudades, príncipe.
```
+------------------------------+
| ¡Ciudad neutral! Al          | (19)
| conquistarla, Johnny trae    | (25)
| el dinero.                   | (10)
+- - - página - - -+
| Solo tú conquistas ciudades, | (28)
| príncipe.                    | (9)
+------------------------------+
```
### [230]  `039E0E`
**ES:** Puedes saber qué país controla la ciudad fijándote en el color de esta bandera.
```
+------------------------------+
| Puedes saber qué país        | (21)
| controla la ciudad fijándote | (28)
| en el color de esta bandera. | (28)
+------------------------------+
```
### [231]  `039E71`
**ES:** Si tienes dudas, ¡pregúntamelo! Jeje.
```
+----------------------+
| Si tienes dudas,     | (16)
| ¡pregúntamelo! Jeje. | (20)
+----------------------+
```
### [232]  `039EB3`
**ES:** Superar la fase
```
+----------------------+
| Superar la fase      | (15)
+----------------------+
```
### [233]  `039ECB`
**ES:** Reglas
```
+----------------------+
| Reglas               | (6)
+----------------------+
```
### [234]  `039EDE`
**ES:** Oye a Spanky
```
+----------------------+
| Oye a Spanky         | (12)
+----------------------+
```
### [235]  `039F05`
**ES:** ¡Ánimo! ¡Dalo todo!
```
+----------------------+
| ¡Ánimo! ¡Dalo todo!  | (19)
+----------------------+
```
### [236]  `039F29`
**ES:** Si tienes dudas, ¡pregúntame! Te contaré lo que sé.
```
+-------------------------------+
| Si tienes dudas, ¡pregúntame! | (29)
| Te contaré lo que sé.         | (21)
+-------------------------------+
```
### [237]  `039F7B`
**ES:** Superar la fase
```
+----------------------+
| Superar la fase      | (15)
+----------------------+
```
### [238]  `039F93`
**ES:** Reglas
```
+----------------------+
| Reglas               | (6)
+----------------------+
```
### [239]  `039FA6`
**ES:** Escucha a Lance
```
+----------------------+
| Escucha a Lance      | (15)
+----------------------+
```
### [240]  `039FD1`
**ES:** ¡Estoy de tu parte, mi príncipe!
```
+------------------------+
| ¡Estoy de tu parte, mi | (22)
| príncipe!              | (9)
+------------------------+
```
### [241]  `039FF6`
**ES:** Esta batalla no tiene nada especial. ¡Relájate y lucha como quieras!
```
+----------------------------+
| Esta batalla no tiene nada | (26)
| especial.                  | (9)
+- - - página - - -+
| ¡Relájate y lucha como     | (22)
| quieras!                   | (8)
+----------------------------+
```
### [242]  `03A048`
**ES:** Cobras impuestos de todo territorio que poseas. Sin camino claro al castillo no cobrarás: puente roto o valla anulan el dinero. Tampoco cobrarás de territorios en islas sueltas. Al enemigo le pasa igual. Si bloqueas su castillo... perderá todo su dinero y se debilitará... ¡Gran estrategia!
```
+-------------------------------+
| Cobras impuestos de todo      | (24)
| territorio que poseas.        | (22)
+- - - página - - -+
| Sin camino claro al castillo  | (28)
| no cobrarás: puente roto o    | (26)
| valla anulan el dinero.       | (23)
+- - - página - - -+
|                               |
+- - - página - - -+
| Tampoco cobrarás de           | (19)
| territorios en islas sueltas. | (29)
+- - - página - - -+
| Al enemigo le pasa igual.     | (25)
+- - - página - - -+
| Si bloqueas su castillo...    | (26)
| perderá todo su dinero y se   | (27)
| debilitará...                 | (13)
+- - - página - - -+
| ¡Gran estrategia!             | (17)
+-------------------------------+
```
### [243]  `03A211`
**ES:** Solo tú abres los cofres, Al. Todos tienen 5000 G. No los ignores.
```
+-------------------------------+
| Solo tú abres los cofres, Al. | (29)
+- - - página - - -+
| Todos tienen 5000 G. No los   | (27)
| ignores.                      | (8)
+-------------------------------+
```
### [244]  `03A271`
**ES:** El enemigo se volverá más listo poco a poco, ¡así que ten cuidado! Atacarán tu castillo si te descuidas. Si dejas el castillo, ¡puede que destruyan un puente para impedirte volver!
```
+------------------------------+
| El enemigo se volverá        | (21)
| más listo poco a poco,       | (22)
| ¡así que ten cuidado!        | (21)
+- - - página - - -+
| Atacarán tu castillo si te   | (26)
| descuidas.                   | (10)
+- - - página - - -+
| Si dejas el castillo, ¡puede | (28)
| que destruyan un puente      | (23)
| para impedirte volver!       | (22)
+------------------------------+
```
### [245]  `03A342`
**ES:** ¡Poner tus impuestos al 0 % y quedarte sin dinero es una estrategia muy divertida! Tus soldados no podrán crear territorio nuevo, ¡e irán al reino enemigo a romperlo todo!
```
+-------------------------------+
| ¡Poner tus impuestos al 0 % y | (29)
| quedarte sin dinero es una    | (26)
| estrategia muy divertida!     | (25)
+- - - página - - -+
| Tus soldados no podrán        | (22)
| crear territorio nuevo,       | (23)
+- - - página - - -+
| ¡e irán al reino enemigo a    | (26)
| romperlo todo!                | (14)
+-------------------------------+
```
### [246]  `03A409`
**ES:** Ve con cuidado, ¡solo tengo 256 años!
```
+-----------------------+
| Ve con cuidado, ¡solo | (21)
| tengo 256 años!       | (15)
+-----------------------+
```
### [247]  `03A433`
**ES:** ¡Derrota a todos los enemigos! Veamos... Un soldado vence al rey enemigo con tres o cuatro veces su salud. Pero la salud baja al caminar.
```
+---------------------------+
| ¡Derrota a todos los      | (20)
| enemigos!                 | (9)
+- - - página - - -+
| Veamos...                 | (9)
+- - - página - - -+
| Un soldado vence al rey   | (23)
| enemigo con tres o cuatro | (25)
| veces su salud.           | (15)
+- - - página - - -+
| Pero la salud baja al     | (21)
| caminar.                  | (8)
+---------------------------+
```
### [248]  `03A507`
**ES:** Golpea primero y vencerás: velocidad es poder. Ambos os fortaleceréis con el tiempo, pero al empezar el enemigo es débil. ¡Victoria rápida!
```
+-------------------------------+
| Golpea primero y vencerás:    | (26)
| velocidad es poder.           | (19)
+- - - página - - -+
| Ambos os fortaleceréis con el | (29)
| tiempo,                       | (7)
+- - - página - - -+
| pero al empezar el enemigo es | (29)
| débil. ¡Victoria rápida!      | (24)
+-------------------------------+
```
### [249]  `03A5FC`
**ES:** ¡Tengo 68 años, pero no perderé contra jovenzuelos!
```
+-----------------------------+
| ¡Tengo 68 años, pero no     | (23)
| perderé contra jovenzuelos! | (27)
+-----------------------------+
```
### [250]  `03A63A`
**ES:** ¡La clave de la victoria eres tú! Intenta destruir el territorio enemigo en persona siempre que puedas. ¡Puedes volver a tu castillo a recuperar salud casi de inmediato!
```
+--------------------------------+
| ¡La clave de la                | (15)
| victoria eres tú!              | (17)
+- - - página - - -+
| Intenta destruir el territorio | (30)
| enemigo en persona siempre     | (26)
| que puedas.                    | (11)
+- - - página - - -+
| ¡Puedes volver a tu castillo a | (30)
| recuperar salud casi de        | (23)
| inmediato!                     | (10)
+--------------------------------+
```
### [251]  `03A6FD`
**ES:** Si un soldado fuerte protege territorio ante el castillo enemigo...
```
+----------------------------+
| Si un soldado fuerte       | (20)
| protege territorio ante el | (26)
| castillo enemigo...        | (19)
+----------------------------+
```
### [252]  `03A750`
**ES:** El enemigo no podrá recaudar impuestos y perderá todos sus fondos.
```
+---------------------------+
| El enemigo no podrá       | (19)
| recaudar impuestos y      | (20)
| perderá todos sus fondos. | (25)
+---------------------------+
```
### [253]  `03A79B`
**ES:** ¡Sigue luchando como siempre! ¡No te preocupes y hazlo lo mejor posible!
```
+-----------------------------+
| ¡Sigue luchando como        | (20)
| siempre!                    | (8)
+- - - página - - -+
| ¡No te preocupes y hazlo lo | (27)
| mejor posible!              | (14)
+-----------------------------+
```
### [254]  `03A7FA`
**ES:** Para ganar debes derrotar a todos los enemigos. Sin embargo... Si no amplías tu territorio, tu tasa de ocupación será baja. Recibirás una penalización en los días restantes.
```
+-------------------------------+
| Para ganar debes derrotar     | (25)
| a todos los enemigos.         | (21)
+- - - página - - -+
| Sin embargo... Si no amplías  | (28)
| tu territorio, tu tasa de     | (25)
| ocupación será baja.          | (20)
+- - - página - - -+
| Recibirás una penalización en | (29)
| los días restantes.           | (19)
+-------------------------------+
```
### [255]  `03A8B0`
**ES:** Si te quedas sin días o el príncipe muere, perderás. No dejes que el valor de tus soldados o territorio caiga a cero. Ten cuidado.
```
+-------------------------------+
| Si te quedas sin días o el    | (26)
| príncipe muere,               | (15)
| perderás.                     | (9)
+- - - página - - -+
| No dejes que el valor de tus  | (28)
| soldados o territorio caiga a | (29)
| cero. Ten cuidado.            | (18)
+-------------------------------+
```
### [256]  `03A97D`
**ES:** ¿Has visto eso? ¡Es un cofre del tesoro!
```
+------------------------+
| ¿Has visto eso? ¡Es un | (22)
| cofre del tesoro!      | (17)
+------------------------+
```
### [257]  `03A9C1`
**ES:** ¡Una cueva de monstruos!
```
+----------------------+
| ¡Una cueva de        | (13)
| monstruos!           | (10)
+----------------------+
```
### [258]  `03A9E3`
**ES:** ¡No pararán de salir monstruos!
```
+----------------------+
| ¡No pararán de salir | (20)
| monstruos!           | (10)
+----------------------+
```
### [259]  `03AA16`
**ES:** Pero sin alarmarse.
```
+----------------------+
| Pero sin alarmarse.  | (19)
+----------------------+
```
### [260]  `03AA31`
**ES:** ¡Ordenaré a mis soldados sellarla!
```
+--------------------------+
| ¡Ordenaré a mis soldados | (24)
| sellarla!                | (9)
+--------------------------+
```
### [261]  `03AA71`
**ES:** Es una ciudad neutral.
```
+------------------------+
| Es una ciudad neutral. | (22)
+------------------------+
```
### [262]  `03AA8E`
**ES:** Si conquisto esto, ¡recibiré tributos!
```
+----------------------+
| Si conquisto esto,   | (18)
| ¡recibiré tributos!  | (19)
+----------------------+
```
### [263]  `03AACD`
**ES:** ¿Agua? ¡Claro! Haremos un puente.
```
+------------------------+
| ¿Agua? ¡Claro! Haremos | (22)
| un puente.             | (10)
+------------------------+
```
### [264]  `03AB0B`
**ES:** ¡Destruid esa valla y avanzad!
```
+-----------------------+
| ¡Destruid esa valla y | (21)
| avanzad!              | (8)
+-----------------------+
```
### [265]  `03AB38`
**ES:** ¡Doy todo tipo de órdenes!
```
+----------------------+
| ¡Doy todo tipo de    | (17)
| órdenes!             | (8)
+----------------------+
```
### [266]  `03AB6A`
**ES:** De momento, les ordenaré talar ese bosque para poder expandirnos por ahí.
```
+----------------------------+
| De momento, les ordenaré   | (24)
| talar ese bosque para      | (21)
| poder expandirnos por ahí. | (26)
+----------------------------+
```
### [267]  `03ABCD`
**ES:** Amplía nuestro territorio para crear tropas.
```
+---------------------------+
| Amplía nuestro territorio | (25)
| para crear tropas.        | (18)
+---------------------------+
```
### [268]  `03AC09`
**ES:** Soldados muy trabajadores, ¿sabes?
```
+-----------------------+
| Soldados muy          | (12)
| trabajadores, ¿sabes? | (21)
+-----------------------+
```
### [269]  `03AC4D`
**ES:** ¡Vamos, chicos!
```
+----------------------+
| ¡Vamos, chicos!      | (15)
+----------------------+
```
### [270]  `03AC6A`
**ES:** ¡Al ataque!
```
+----------------------+
| ¡Al ataque!          | (11)
+----------------------+
```
### [271]  `03AC8C`
**ES:** Primero, una paliza a este.
```
+-----------------------------+
| Primero, una paliza a este. | (27)
+-----------------------------+
```
### [272]  `03ACCE`
**ES:** Hola. Soy Alfred, el príncipe del reino de Monarch.
```
+-------------------------------+
| Hola. Soy Alfred, el príncipe | (29)
| del reino de Monarch.         | (21)
+-------------------------------+
```
### [273]  `03AD0E`
**ES:** ¡Te mostraré cómo luchamos en Lord Monarch!
```
+----------------------------+
| ¡Te mostraré cómo luchamos | (26)
| en Lord Monarch!           | (16)
+----------------------------+
```
### [274]  `03ED6E`
**ES:** ¿Eh? ¡¿Ya van tantos?! ¡Debo darme prisa!
```
+------------------------+
| ¿Eh? ¡¿Ya van tantos?! | (22)
| ¡Debo darme prisa!     | (18)
+------------------------+
```
### [275]  `04A00A`
**ES:** ¡Hurra! ¡Hurraaa!
```
+----------------------+
| ¡Hurra!              | (7)
| ¡Hurraaa!            | (9)
+----------------------+
```
### [276]  `04A044`
**ES:** ¡Viva el reino de Monarch!
```
+----------------------------+
| ¡Viva el reino de Monarch! | (26)
+----------------------------+
```
### [277]  `04A07B`
**ES:** ¡Por fin! ¡Hemos ganado!
```
+--------------------------+
| ¡Por fin! ¡Hemos ganado! | (24)
+--------------------------+
```
### [278]  `04A0A0`
**ES:** ¡Al ataque!
```
+----------------------+
| ¡Al ataque!          | (11)
+----------------------+
```
### [279]  `04A0BD`
**ES:** Mira. Amanece un nuevo día...
```
+-------------------------------+
| Mira. Amanece un nuevo día... | (29)
+-------------------------------+
```
### [280]  `04A0E7`
**ES:** Es tan hermoso...
```
+----------------------+
| Es tan hermoso...    | (17)
+----------------------+
```
### [281]  `04A102`
**ES:** Con esto, los reinos de Monarch y Martika están a salvo.
```
+-----------------------------------+
| Con esto, los reinos de Monarch y | (33)
| Martika están a salvo.            | (22)
+-----------------------------------+
```
### [282]  `04A146`
**ES:** Así es. Nadie se mete con nuestros reinos.
```
+------------------------------------+
| Así es. Nadie se mete con nuestros | (34)
| reinos.                            | (7)
+------------------------------------+
```
### [283]  `04A17D`
**ES:** ¡JAJAJA!
```
+----------------------+
| ¡JAJAJA!             | (8)
+----------------------+
```
### [284]  `04A18E`
**ES:** *snif* Soy tan feliz...
```
+-------------------------+
| *snif* Soy tan feliz... | (23)
+-------------------------+
```
### [285]  `04A1AC`
**ES:** Incluso nosotras, las hadas, podremos vivir en paz.
```
+------------------------------+
| Incluso nosotras, las hadas, | (28)
| podremos vivir en paz.       | (22)
+------------------------------+
```
### [286]  `04A1EA`
**ES:** Gracias.
```
+----------------------+
| Gracias.             | (8)
+----------------------+
```
### [287]  `04A1FB`
**ES:** Spanky, gracias por todo.
```
+---------------------------+
| Spanky, gracias por todo. | (25)
+---------------------------+
```
### [288]  `04A221`
**ES:** No sé qué habría pasado si no te hubiéramos conocido...
```
+----------------------------------+
| No sé qué habría pasado si no te | (32)
| hubiéramos conocido...           | (22)
+----------------------------------+
```
### [289]  `04A267`
**ES:** Ay, me vais a sonrojar.
```
+-------------------------+
| Ay, me vais a sonrojar. | (23)
+-------------------------+
```
### [290]  `04A297`
**ES:** ¿Y mis gracias? ¿Eh?
```
+----------------------+
| ¿Y mis gracias? ¿Eh? | (20)
+----------------------+
```
### [291]  `04A2D3`
**ES:** Me seguiste tú solo. Menudo pesado.
```
+-----------------------------+
| Me seguiste tú solo. Menudo | (27)
| pesado.                     | (7)
+-----------------------------+
```
### [292]  `04A318`
**ES:** ¿Ah, sí!? ¡Como sea! ¡Hmpf!
```
+----------------------+
| ¿Ah, sí!? ¡Como sea! | (20)
| ¡Hmpf!               | (6)
+----------------------+
```
### [293]  `04A349`
**ES:** Jajaja. Es broma, Rubia...
```
+----------------------------+
| Jajaja. Es broma, Rubia... | (26)
+----------------------------+
```
### [294]  `04A375`
**ES:** Gracias. Si no fuera por ti, ahora no estaría aquí.
```
+---------------------------------------+
| Gracias. Si no fuera por ti, ahora no | (37)
| estaría aquí.                         | (13)
+---------------------------------------+
```
### [295]  `04A3BD`
**ES:** Ay, Alfred...
```
+----------------------+
| Ay, Alfred...        | (13)
+----------------------+
```
### [296]  `04A3E0`
**ES:** En fin, ¡final feliz!
```
+-----------------------+
| En fin, ¡final feliz! | (21)
+-----------------------+
```
### [297]  `04A407`
**ES:** ¡WAJAJAJA!
```
+----------------------+
| ¡WAJAJAJA!           | (10)
+----------------------+
```
### [298]  `04A458`
**ES:** Ay ay ay...
```
+----------------------+
| Ay ay ay...          | (11)
+----------------------+
```
### [299]  `04A46D`
**ES:** ¡Aaaah!
```
+----------------------+
| ¡Aaaah!              | (7)
+----------------------+
```
### [300]  `04A48D`
**ES:** ¡Aaaaw! ¡Es Galgundos!
```
+------------------------+
| ¡Aaaaw! ¡Es Galgundos! | (22)
+------------------------+
```
### [301]  `04A4A8`
**ES:** ¡Ha vuelto a la vida!
```
+-----------------------+
| ¡Ha vuelto a la vida! | (21)
+-----------------------+
```
### [302]  `04A4D1`
**ES:** ¿¡Quéeeee!?
```
+----------------------+
| ¿¡Quéeeee!?          | (11)
+----------------------+
```
### [303]  `04A4ED`
**ES:** Nada mal, mocoso. Como mi tonto hijo.
```
+---------------------------+
| Nada mal, mocoso. Como mi | (25)
| tonto hijo.               | (11)
+---------------------------+
```
### [304]  `04A539`
**ES:** ¡No soy tonto!
```
+----------------------+
| ¡No soy tonto!       | (14)
+----------------------+
```
### [305]  `04A54F`
**ES:** ¡¿Y a qué viene eso de 'hijo'?!
```
+---------------------------------+
| ¡¿Y a qué viene eso de 'hijo'?! | (31)
+---------------------------------+
```
### [306]  `04A581`
**ES:** ¿No te has dado cuenta?
```
+-------------------------+
| ¿No te has dado cuenta? | (23)
+-------------------------+
```
### [307]  `04A59D`
**ES:** ¡Qué tonto eres!
```
+----------------------+
| ¡Qué tonto eres!     | (16)
+----------------------+
```
### [308]  `04A5C5`
**ES:** ...¿Papá? ¿Eres tú?
```
+----------------------+
| ...¿Papá? ¿Eres tú?  | (19)
+----------------------+
```
### [309]  `04A5F3`
**ES:** Así es.
```
+----------------------+
| Así es.              | (7)
+----------------------+
```
### [310]  `04A603`
**ES:** Soy yo.
```
+----------------------+
| Soy yo.              | (7)
+----------------------+
```
### [311]  `04A61D`
**ES:** P-Pero...
```
+----------------------+
| P-Pero...            | (9)
+----------------------+
```
### [312]  `04A630`
**ES:** ¿Los Cuatro Temibles...
```
+-------------------------+
| ¿Los Cuatro Temibles... | (23)
+-------------------------+
```
### [313]  `04A65E`
**ES:** ...eran gente del reino de Monarch...?
```
+----------------------------+
| ...eran gente del reino de | (26)
| Monarch...?                | (11)
+----------------------------+
```
### [314]  `04A6A3`
**ES:** ¡ASÍ ES!
```
+----------------------+
| ¡ASÍ ES!             | (8)
+----------------------+
```
### [315]  `04A6B8`
**ES:** Era la tradición de nuestro país.
```
+-----------------------------------+
| Era la tradición de nuestro país. | (33)
+-----------------------------------+
```
### [316]  `04A6EF`
**ES:** Al llegar el príncipe a la mayoría de edad...
```
+---------------------------------------+
| Al llegar el príncipe a la mayoría de | (37)
| edad...                               | (7)
+---------------------------------------+
```
### [317]  `04A735`
**ES:** ...debe superar una prueba.
```
+-----------------------------+
| ...debe superar una prueba. | (27)
+-----------------------------+
```
### [318]  `04A75F`
**ES:** O sea...
```
+----------------------+
| O sea...             | (8)
+----------------------+
```
### [319]  `04A773`
**ES:** Todos fingimos ser malos sin que lo supieras...
```
+-------------------------------------+
| Todos fingimos ser malos sin que lo | (35)
| supieras...                         | (11)
+-------------------------------------+
```
### [320]  `04A7B3`
**ES:** Y luchamos contigo, uno a uno.
```
+--------------------------------+
| Y luchamos contigo, uno a uno. | (30)
+--------------------------------+
```
### [321]  `04A7E9`
**ES:** Perdón por engañarte.
```
+-----------------------+
| Perdón por engañarte. | (21)
+-----------------------+
```
### [322]  `04A805`
**ES:** Soy el cocinero del castillo.
```
+-------------------------------+
| Soy el cocinero del castillo. | (29)
+-------------------------------+
```
### [323]  `04A833`
**ES:** Jardinero del castillo.
```
+-------------------------+
| Jardinero del castillo. | (23)
+-------------------------+
```
### [324]  `04A852`
**ES:** ¡Goho!
```
+----------------------+
| ¡Goho!               | (6)
+----------------------+
```
### [325]  `04A869`
**ES:** Dirijo un circo de verdad.
```
+----------------------------+
| Dirijo un circo de verdad. | (26)
+----------------------------+
```
### [326]  `04A89B`
**ES:** Mi troupe y yo pasábamos por aquí, y aceptamos el trabajo.
```
+--------------------------------------+
| Mi troupe y yo pasábamos por aquí, y | (36)
| aceptamos el trabajo.                | (21)
+--------------------------------------+
```
### [327]  `04A8EA`
**ES:** Nunca me lo pasé tan bien.
```
+----------------------------+
| Nunca me lo pasé tan bien. | (26)
+----------------------------+
```
### [328]  `04A911`
**ES:** Por cierto, felicidades, príncipe.
```
+------------------------------------+
| Por cierto, felicidades, príncipe. | (34)
+------------------------------------+
```
### [329]  `04A945`
**ES:** Dama del castillo.
```
+----------------------+
| Dama del castillo.   | (18)
+----------------------+
```
### [330]  `04A966`
**ES:** Ya nos hemos visto muchas veces, príncipe...
```
+----------------------------------+
| Ya nos hemos visto muchas veces, | (32)
| príncipe...                      | (11)
+----------------------------------+
```
### [331]  `04A9A7`
**ES:** Y aun así no me reconociste.
```
+------------------------------+
| Y aun así no me reconociste. | (28)
+------------------------------+
```
### [332]  `04A9CC`
**ES:** ¡Casi no pude aguantarme la risa!
```
+-----------------------------+
| ¡Casi no pude aguantarme la | (27)
| risa!                       | (5)
+-----------------------------+
```
### [333]  `04AA3A`
**ES:** ¡Y eso es todo!
```
+----------------------+
| ¡Y eso es todo!      | (15)
+----------------------+
```
### [334]  `04AA55`
**ES:** Sé que luchaste en serio.
```
+---------------------------+
| Sé que luchaste en serio. | (25)
+---------------------------+
```
### [335]  `04AA81`
**ES:** Esta experiencia te hará buen rey.
```
+------------------------------------+
| Esta experiencia te hará buen rey. | (34)
+------------------------------------+
```
### [336]  `04AAC9`
**ES:** ¡Más aún en nuestra era de paz!
```
+---------------------------------+
| ¡Más aún en nuestra era de paz! | (31)
+---------------------------------+
```
### [337]  `04AAF8`
**ES:** ¿No sientes que ahora eres mejor príncipe que antes?
```
+----------------------------------+
| ¿No sientes que ahora eres mejor | (32)
| príncipe que antes?              | (19)
+----------------------------------+
```
### [338]  `04AB41`
**ES:** Aunque sigues tonto como un tronco.
```
+-------------------------------------+
| Aunque sigues tonto como un tronco. | (35)
+-------------------------------------+
```
### [339]  `04AB7B`
**ES:** (¡Guay!)
```
+----------------------+
| (¡Guay!)             | (8)
+----------------------+
```
### [340]  `04AB91`
**ES:** (¡Son divertidos! ¡Me caen bien!)
```
+-----------------------------------+
| (¡Son divertidos! ¡Me caen bien!) | (33)
+-----------------------------------+
```
### [341]  `04ABC6`
**ES:** ¡Su Alteza!
```
+----------------------+
| ¡Su Alteza!          | (11)
+----------------------+
```
### [342]  `04ABD7`
**ES:** ¡Su Alteza!
```
+----------------------+
| ¡Su Alteza!          | (11)
+----------------------+
```
### [343]  `04ABED`
**ES:** ¡Quiero ser la
```
+----------------------+
| ¡Quiero ser la       | (14)
+----------------------+
```
### [344]  `04AC03`
**ES:** su amada
```
+----------------------+
| su amada             | (8)
+----------------------+
```
### [345]  `04AC28`
**ES:** ¿¡Lo habéis oído todos!?
```
+--------------------------+
| ¿¡Lo habéis oído todos!? | (24)
+--------------------------+
```
### [346]  `04AC4C`
**ES:** Jejeje. Qué cara pondrá Lance al saberlo.
```
+----------------------------------+
| Jejeje. Qué cara pondrá Lance al | (32)
| saberlo.                         | (8)
+----------------------------------+
```
### [347]  `04AC8D`
**ES:** ¡GAJAJAJAJA! ¡¿A qué esperáis, chicos!?
```
+--------------------------------+
| ¡GAJAJAJAJA! ¡¿A qué esperáis, | (30)
| chicos!?                       | (8)
+--------------------------------+
```
### [348]  `04ACC1`
**ES:** ¡Preparad la ceremonia!
```
+-------------------------+
| ¡Preparad la ceremonia! | (23)
+-------------------------+
```
### [349]  `04ACF7`
**ES:** ¿Boda?
```
+----------------------+
| ¿Boda?               | (6)
+----------------------+
```
### [350]  `04AD04`
**ES:** ¿Por qué?
```
+----------------------+
| ¿Por qué?            | (9)
+----------------------+
```
### [351]  `04AD1B`
**ES:** Qué tontería.
```
+----------------------+
| Qué tontería.        | (13)
+----------------------+
```
### [352]  `04AD34`
**ES:** ¡Es nuestra boda!
```
+----------------------+
| ¡Es nuestra boda!    | (17)
+----------------------+
```
### [353]  `04AD5B`
**ES:** ¡Qué envidia
```
+----------------------+
| ¡Qué envidia         | (12)
+----------------------+
```
### [354]  `04AD6D`
**ES:** te doy, mujeriego!
```
+----------------------+
| te doy, mujeriego!   | (18)
+----------------------+
```
### [355]  `04ADB3`
**ES:** ¡Espera!
```
+----------------------+
| ¡Espera!             | (8)
+----------------------+
```
### [356]  `04ADC4`
**ES:** ¡NUNCA aceptaré eso!
```
+----------------------+
| ¡NUNCA aceptaré eso! | (20)
+----------------------+
```
### [357]  `04ADEB`
**ES:** ¿¡Sabes todo lo que me costó!?
```
+--------------------------------+
| ¿¡Sabes todo lo que me costó!? | (30)
+--------------------------------+
```
### [358]  `04AE28`
**ES:** Quiero a Rubia desde crío.
```
+----------------------------+
| Quiero a Rubia desde crío. | (26)
+----------------------------+
```
### [359]  `04AE61`
**ES:** NUNCA daré a mi pequeña Rubia a...
```
+------------------------------------+
| NUNCA daré a mi pequeña Rubia a... | (34)
+------------------------------------+
```
### [360]  `04AE90`
**ES:** ...¡ese mocoso del reino de Monarch!
```
+--------------------------------------+
| ...¡ese mocoso del reino de Monarch! | (36)
+--------------------------------------+
```
### [361]  `04AEBE`
**ES:** ¡Ay, no!
```
+----------------------+
| ¡Ay, no!             | (8)
+----------------------+
```
### [362]  `04AEDD`
**ES:** ¡No lo aguantooo más!
```
+-----------------------+
| ¡No lo aguantooo más! | (21)
+-----------------------+
```
### [363]  `04AF0E`
**ES:** ¡Aaaah!
```
+----------------------+
| ¡Aaaah!              | (7)
+----------------------+
```
### [364]  `04AF28`
**ES:** Me marcho con Rubia.
```
+----------------------+
| Me marcho con Rubia. | (20)
+----------------------+
```
### [365]  `04AF57`
**ES:** ¡Socorro!
```
+----------------------+
| ¡Socorro!            | (9)
+----------------------+
```
### [366]  `04AF68`
**ES:** ¿También es del espectáculo, papá?
```
+------------------------------------+
| ¿También es del espectáculo, papá? | (34)
+------------------------------------+
```
### [367]  `04AF9A`
**ES:** ¡Yo nunca planeé esto! Esto ya no es ninguna broma...
```
+-----------------------------+
| ¡Yo nunca planeé esto! Esto | (27)
| ya no es ninguna broma...   | (25)
+-----------------------------+
```
### [368]  `04AFD9`
**ES:** ¿¡Qué!? ¡Todos! ¡Tras ese dragón!
```
+-----------------------------------+
| ¿¡Qué!? ¡Todos! ¡Tras ese dragón! | (33)
+-----------------------------------+
```
### [369]  `04B00F`
**ES:** Al, sube a mi mano.
```
+----------------------+
| Al, sube a mi mano.  | (19)
+----------------------+
```
### [370]  `04B02B`
**ES:** ¡¿Heynee! ¿¡Vuelas!?
```
+----------------------+
| ¡¿Heynee! ¿¡Vuelas!? | (20)
+----------------------+
```
### [371]  `04B048`
**ES:** ¡Claro que sí! ¡Déjamelo a mí!
```
+--------------------------------+
| ¡Claro que sí! ¡Déjamelo a mí! | (30)
+--------------------------------+
```
### [372]  `04B07D`
**ES:** ¡¡Vamos!!
```
+----------------------+
| ¡¡Vamos!!            | (9)
+----------------------+
```
### [373]  `04B0A9`
**ES:** ¿Hm? ¡Maldito Alfred!
```
+-----------------------+
| ¿Hm? ¡Maldito Alfred! | (21)
+-----------------------+
```
### [374]  `04B0C9`
**ES:** Ya lo verá.
```
+----------------------+
| Ya lo verá.          | (11)
+----------------------+
```
### [375]  `04B113`
**ES:** ¡Tú puedes, Heynee!
```
+----------------------+
| ¡Tú puedes, Heynee!  | (19)
+----------------------+
```
### [376]  `04B144`
**ES:** ¡Gwaaaaaaah!
```
+----------------------+
| ¡Gwaaaaaaah!         | (12)
+----------------------+
```
### [377]  `04B178`
**ES:** ¡Heynee! ¡Aguanta!
```
+----------------------+
| ¡Heynee! ¡Aguanta!   | (18)
+----------------------+
```
### [378]  `04B194`
**ES:** Bien... Pero no puedo moverme.
```
+--------------------------------+
| Bien... Pero no puedo moverme. | (30)
+--------------------------------+
```
### [379]  `04B1C0`
**ES:** Date prisa tras la princesa Rubia.
```
+------------------------------------+
| Date prisa tras la princesa Rubia. | (34)
+------------------------------------+
```
### [380]  `04B1ED`
**ES:** Gracias por todo, Heynee.
```
+---------------------------+
| Gracias por todo, Heynee. | (25)
+---------------------------+
```
### [381]  `04B212`
**ES:** Cuidado, Al.
```
+----------------------+
| Cuidado, Al.         | (12)
+----------------------+
```
### [382]  `04B23B`
**ES:** ¡Holaaa!
```
+----------------------+
| ¡Holaaa!             | (8)
+----------------------+
```
### [383]  `04B24A`
**ES:** Me llamo Spanky. Como ves, soy un hada.
```
+-----------------------------------------+
| Me llamo Spanky. Como ves, soy un hada. | (39)
+-----------------------------------------+
```
### [384]  `04B281`
**ES:** Tengo un asunto importante en el reino de Monarch.
```
+----------------------------------------+
| Tengo un asunto importante en el reino | (38)
| de Monarch.                            | (11)
+----------------------------------------+
```
### [385]  `04B2BF`
**ES:** ¿Eh?
```
+----------------------+
| ¿Eh?                 | (4)
+----------------------+
```
### [386]  `04B2C8`
**ES:** ¿No conoces el reino de Monarch? ¡Entonces déjamelo explicar!
```
+----------------------------------+
| ¿No conoces el reino de Monarch? | (32)
| ¡Entonces déjamelo explicar!     | (28)
+----------------------------------+
```
### [387]  `04B329`
**ES:** El reino de Monarch lo gobierna un anciano llamado Rey Monarch.
```
+------------------------------------+
| El reino de Monarch lo gobierna un | (34)
| anciano llamado Rey Monarch.       | (28)
+------------------------------------+
```
### [388]  `04B375`
**ES:** Es un país muy pacífico.
```
+--------------------------+
| Es un país muy pacífico. | (24)
+--------------------------+
```
### [389]  `04B398`
**ES:** Cuando era joven lo conocían como un hombre de acero muy guapo. Muy fuerte.
```
+----------------------------------------+
| Cuando era joven lo conocían como un   | (36)
| hombre de acero muy guapo. Muy fuerte. | (38)
+----------------------------------------+
```
### [390]  `04B409`
**ES:** Los ciudadanos son gente buena y trabajadora.
```
+----------------------------------+
| Los ciudadanos son gente buena y | (32)
| trabajadora.                     | (12)
+----------------------------------+
```
### [391]  `04B45F`
**ES:** Y luego está el príncipe, Alfred.
```
+-----------------------------------+
| Y luego está el príncipe, Alfred. | (33)
+-----------------------------------+
```
### [392]  `04B488`
**ES:** Es muy travieso y también divertido...
```
+----------------------------------------+
| Es muy travieso y también divertido... | (38)
+----------------------------------------+
```
### [393]  `04B4C1`
**ES:** Seguro que te preguntas qué asunto tan importante tengo allí.
```
+----------------------------------------+
| Seguro que te preguntas qué asunto tan | (38)
| importante tengo allí.                 | (22)
+----------------------------------------+
```
### [394]  `04B50B`
**ES:** Vale. Te lo contaré.
```
+----------------------+
| Vale. Te lo contaré. | (20)
+----------------------+
```
### [395]  `04B54E`
**ES:** En mi sueño invernal tuve una pesadilla espantosa.
```
+-----------------------------------------+
| En mi sueño invernal tuve una pesadilla | (39)
| espantosa.                              | (10)
+-----------------------------------------+
```
### [396]  `04B594`
**ES:** Monarch era engullido por la oscuridad y destruido.
```
+------------------------------------------+
| Monarch era engullido por la oscuridad y | (40)
| destruido.                               | (10)
+------------------------------------------+
```
### [397]  `04B5D9`
**ES:** Fue muy aterrador.
```
+----------------------+
| Fue muy aterrador.   | (18)
+----------------------+
```
### [398]  `04B5F4`
**ES:** Los sueños de hadas siempre se cumplen, así que voy a informar al Rey.
```
+-----------------------------------------+
| Los sueños de hadas siempre se cumplen, | (39)
| así que voy a informar al Rey.          | (30)
+-----------------------------------------+
```
### [399]  `04B64D`
**ES:** Tengo prisa. ¡Adiós!
```
+----------------------+
| Tengo prisa. ¡Adiós! | (20)
+----------------------+
```
### [400]  `04B67F`
**ES:** ¡Príncipe Alfred! ¡No tenemos dinero! ¡No podemos ampliar la zona ni hacer puentes! ¡Suba los impuestos!
```
+---------------------------------------+
| ¡Príncipe Alfred! ¡No tenemos dinero! | (37)
+- - - página - - -+
| ¡No podemos ampliar la zona ni hacer  | (36)
| puentes!                              | (8)
+- - - página - - -+
| ¡Suba los impuestos!                  | (20)
+---------------------------------------+
```

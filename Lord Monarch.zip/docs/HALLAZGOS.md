# Lord Monarch (Mega Drive) — traducción al castellano

## ROMs
- `roms/Lord Monarch (Japan).md`          — 2 MB, original japonesa. MD5 5e06d2de451ecc57a9a91577bb0dc59c
- `roms/Lord Monarch (English v1.0).md`   — 2 MB, traducción inglesa (referencia). MD5 a6a2118f2cf771ac358de37751e22911
- `roms/Lord Monarch (Espanol).md`        — 2 MB, nuestro trabajo previo. MD5 d3c9869e113ee9bdc45116a5aecf3c8f

## Hechos clave (medidos)
1. La ROM "Español" difiere de la **inglesa** en solo 8.310 bytes (1.066 rangos),
   pero de la **japonesa** en ~978 KB. => **Nuestro trabajo anterior partió de la
   ROM inglesa**, no de la japonesa.
2. El texto del juego es **ASCII plano + códigos de control, terminado en 0x00**.
3. Texto de menú en ancho FIJO rellenado con espacios (por eso "Status"->"Estad").
4. Cabecera MD: "SEGA MEGA DRIVE (C)SEGA 1994.APR", checksum 0x0000.

## LA FUENTE (encontrada)
- **Glifos**: en `0x19AEC0`. Formato **2bpp Mega Drive** (4 bytes/fila: plano0 word
  BE + plano1 word BE; bit 15 = pixel izquierdo). **32 bytes por glifo** (8×8).
- **96 glifos** = ASCII 0x20–0x7F. **índice = byte − 0x20** (las rutinas hacen
  `subi #32`).
- **Tabla de anchos** (fuente PROPORCIONAL): en `0x19ADC0`, 256 bytes.
  índice→ancho en px. Índices 0–95 = 4–9 px; 96–127 = "1"; 128–255 = "0".
- **Espacio libre** tras la fuente: 1.027 bytes a cero desde `0x19BAC0`
  (~32 glifos posibles en índices 96–127). Suficiente para los acentos.

### Rutinas de texto (0x1DE…)
- `0x1DE402`  dibuja UN glifo (d3 = índice). `lea 0x19aec0` + `lslw #5` (×32).
- `0x1DE9CE`  dibuja string: `moveb a0@+,d3` → `subib #32` → `bsr 0x1de402`.
- `0x1DEA1C`  dibuja string con wrap (igual: `subib #32`).
- `0x1DE974`  calcula ANCHO del string: `subiw #32` + suma anchos de 0x19adc0.
- `0x1DE996`  setup: `a1 = 0x1DE402`, a2 = 0xb38.
- `0x215E`    dibuja dígitos (UI): `subib #48`, fuente en 0x19aec0.
- Conversión **byte − 0x20** repetida en 0x1DE9DA / 0x1DEA2E / 0x1DE986.

## Plan para acentos (diseñado)
Como la conversión es `índice = byte − 0x20`, los bytes **0x80–0x8F** caen
automáticamente en índices 96–111. Basta con:
1. Dibujar 16 glifos acentuados en índices 96–111 (en 0x19BAC0+).
2. Poner sus anchos en 0x19ADC0[96..111].
3. Usar bytes 0x80–0x8F en el texto (sin tocar el código).

Asignación códigos→carácter (byte → índice = byte−0x20):
```
0x81 á  0x82 é  0x83 í  0x84 ó  0x85 ú  0x86 ñ  0x87 Ñ  0x88 ü
0x89 Ü  0x8A ¡  0x8B ¿  0x8C Á  0x8D É  0x8E Í  0x8F Ó  0x90 Ú
```
⚠️ El índice **96 está RESERVADO**: es el glifo de relleno que usan 0x1de364 y
0x1de388 (movew #96,d3 + bsr 0x1de402) para rellenar el final de línea. Por eso
los acentos empiezan en el byte 0x81 (índice 97), nunca en 0x80.

✅ La rutina `0x1DE660` (hook de la traducción inglesa) lee byte a byte y:
- `0x00` → fin de string
- `0x01` → rellenar hasta fin de línea (bsr 0x1de364)
- `0x06` → insertar número (bsr 0x1de3aa)
- `0x09` → comando especial (jsr 0x1ee0)
- **cualquier otro byte** → `subib #32` y dibuja glifo (bsr 0x1de402)

⚠️ PERO el diálogo real de partida usa OTRO intérprete: `0x1DE572/0x1DE580`, que
**SALTA los bytes ≥0x80** (`cmpi.w #$7F,d3 ; bpl.b skip` en 0x1DE586). Por eso los
acentos no salían en pantalla aunque la fuente los tuviera.

🔧 [HECHO] PARCHE APLICADO en `work_trad.md`: byte `0x1DE589` = 0x7F → **0x90**.
Ahora 0x81–0x90 caen al camino de dibujo (`subi #32` → glifos 97–112) y los
bytes ≥0x91 se siguen saltando como antes. Verificado en emulador: "Café con
acento / ¡Mañana! / ¿Qué? Óscar." se dibuja perfecto; título y gameplay
pixel-idénticos a la ROM sin parche (sin regresiones).

Los códigos de control del bytecode (0x03,0x04,0x05,0x08,0x11,0x12…) los procesa
el intérprete de escena antes de pasar el texto al de dibujo; no colisionan con 0x80+.

## Estructura de diálogo (script)
Prefijo `04 01 05 08 XX` (XX = nº de diálogo), luego texto ASCII, terminador
`11 03`, fin `00`. Nombres de personaje null-terminated en 0x31920–0x31A2F.

## Cajas de texto (cómo ampliarlas)
Intérprete de escena en `0xFF68`: lee byte de comando; `0x00–0x0E` → tabla de
saltos en `0xFF84` (cmd 0x00 → 0x10084 dibuja ventana desde puntero; cmd 0x03 →
0x10020 cierra/avanza); bytes `≥0x15` → texto al intérprete 0x1DE572. Controles
de texto: `0x00` fin, `0x01` salto de línea, `0x02` wrap/relleno, `0x03` fin de
bocadillo (jsr 0x10020).

🔑 [HECHO] La caja ANCHA de diálogo (con nombre de personaje) **crece sola en
vertical**: cada `0x01` añade una línea y el fondo/borde se dibuja automático
(probado con 3 líneas: borde perfecto). Ancho fijo ~37 caracteres. → Para el
castellano, texto más largo = **más líneas con 0x01**, sin tocar código.

Las rutinas con wrap por columnas (`cmpib #8` en 0x1DEA44 / `cmpib #4` en
0x1DEAB2, contador en $ce9c/$ce9d) NO controlan los paneles de juego: subir sus
#N no cambia nada visible en gameplay (probado). [DESCARTADO] como vía para los
paneles King/GOLD/PLAIN/Od/Distance: esos fondos vienen de otra capa (tilemap de
escena). Para ellos la traducción usará palabras cortas (REY, ORO, MAR, DÍA…).

## Tareas
1. [x] Dibujar glifos acentuados (script `tools/build_font.py`).
2. [x] Verificar tratamiento de bytes ≥0x80 por el intérprete y parchear
       (0x1DE589: 0x7F→0x90 en work_trad.md). Acentos visibles en emulador.
3. [x] Cajas de diálogo: ampliación vertical automática vía 0x01 verificada.
       Paneles fijos → palabras cortas en la traducción.
4. [~] Traducción completa al castellano y maquetación (líneas con 0x01,
       palabras cortas en paneles) para revisión.
       - [HECHO] Intro/tutorial traducido FIEL AL JAPONÉS y verificado en
         emulador (`tools/traduce_intro.py`): narrador (0x4B329, 0x4B488,
         0x4B54E, 0x4B5D9), gritos de carga (0x34E6E, 0x35902, 0x35A12,
         0x35B91, 0x35E68, 0x3AC6A, 0x4A0A0), tributos (0x3AA8E) y ALFRED
         (0x3AD0E). Los 0x03 NO son relleno (son comandos de cierre): la
         longitud se cuadra con espacios finales o con longitud fija si hay
         controles intermedios.
       - [PENDIENTE] resto de escenas, nombres de personaje (0x31920) y paneles.

## Método de traducción: directamente del japonés (decisión de David)
No se traduce de la inglesa (sería traducir una traducción). Flujo:
1. Capturar la ROM japonesa en el emulador con el mismo flujo de inputs.
2. Leer el japonés en pantalla y traducir directo al castellano.
3. Insertar en work_trad.md en los offsets de la ROM inglesa (misma escena).
⚠️ El timing JP difiere del EN/ES (los diálogos caen en otros frames); hay que
barrer más frames para encontrar cada diálogo JP.

### Referencias japonesas capturadas (frame JP → texto → términos)
- f3000: モナーク王国はキング・モナークというおじさんが、治めているんでちゅ。
- f4200: とっても、わんぱくで、おもしろい人なんでちゅって・・・。
- f5000: ぼくが冬眠をしていた時の事なんでちゅけど、すごい夢を見たんでちゅ。
- f5400: すごーく、こわい夢だったんでちゅ。
- f9400: 森を切りひらいて、領地を広げてくれるぞ。(cortar bosque → expandir territorio)
- f13800: ここを取ると、みつぎものが、もらえるんだぜ！(conquistar → tributos)
- Panel JP: おうさま=REY, 城 159日=CASTILLO/días, きょり=DISTANCIA,
  はしをつくる=PUENTE(ROAD en EN), じんちをはる=ACAMPAR(CAMP), がいてき=enemigo,
  オート=AUTO. La fuente ES no tiene glifos japoneses: solo se usan estas
  referencias para traducir; el texto insertado va en castellano con acentos.

## Review de David (2026-09-11) — correcciones aplicadas
- [HECHO] Parche intérprete ampliado: 0x1DE589 = 0x91 (con 0x90 el `bpl`
  firmado seguía saltándose la Ú → "Úsalos bien." salía "salos bien.").
- [HECHO] Glifos ¡ (0x8A) y ¿ (0x8B) rediseñados: punto separado por hueco +
  cuerpo con serifa (método de invertir los de cierre, equilibrado). í (0x83)
  con acento a la altura del de é. Script `tools/fix_glyphs.py`.
- [HECHO] Tipografía: espacio tras !/? antes de otra frase; aperturas ¡/¿ que
  faltaban; "¿A ver...?" → "A ver... ¿Qué hacemos?"; "muestraque" →
  "muestra qué". Script `tools/fix_textos.py`.
- [HECHO] `tools/maqueta.py` genera `docs/MAQUETACION.md`: 399 bloques de las
  regiones de script (0x31920-33000, 0x34C00-3B000, 0x4A000-4B700) con ancho
  en px por línea (tabla 0x19ADC0) y % de uso de la caja (~300 px) para
  revisar maquetación antes de tocar la ROM.
- [PENDIENTE] Fuente TTF alternativa: David mencionó un enlace que NO llegó en
  el mensaje; su PNG manual (uploads/Fuente alternativa.png) tiene estilo más
  fino que la fuente del juego → se usaron versiones espejadas de los glifos
  propios del juego para ¡/¿. Reevaluar cuando llegue el TTF (mockups).

# Escena post-batalla 1 (Manta) y escena Shakuren — traducción al castellano desde el japonés

Estado: **incluida en la entrega 12d** (2026-09-12), pendiente de tu revisión.
Si alguna frase no te convence, dímelo y la cambio antes de la siguiente entrega.
No había ninguna frase aprobada tuya en este bloque: estaba en inglés (residual sin traducir).

## Conversación con Manta (tras la batalla del tutorial)

| # | Castellano (12d) |
|---|------------------|
| 1 | ¡Yo también soy uno de los Cuatro / Emperadores, el conde Manta! — Si tanto me provocáis, no puedo / quedarme callado. ¡Os enseñaré / quién soy! — ¡Cuando pasen 5 días, ya podéis / lamentaros! |
| 2 | ¿Y ahora qué? / ¿Te rindes, Manta? |
| 3 | Uhh... Cómo he podido / perder... yo... |
| 4 | ¡Con esto, el reino de Monarch / está a salvo! |
| 5 | Je, je, je... Qué equivocados / estáis... — Cuando lord Galgundos termine su / hechizo desde la isla Langer, / será vuestro fin... |
| 6 | ¡¿Qué?! |
| 7 | Así es. Mi misión era ganar / tiempo... Y lo he conseguido... / Jo, jo, jo. |
| 8 | ¡Cállate! ¡Derrotaré a Galgundos / antes de que termine ese / hechizo! |
| 9 | Ya veremos... En la isla Langer, / guardando al señor Galgundos, — te aguarda la última de los / Cuatro Emperadores: Shakuren... |
| 10 | ..... |
| 11 | Esfuérzate cuanto quieras... / Nadie detendrá el Cañón Hechizo / del señor Galgundos... / ¡Buaja, ja, ja, ja, ja! ... ¡Ugh! |
| 12 | ¡¿Qué?! ¿¡El Cañón / Hechizo!? |
| 13 | Spanky, ¿tú sabes qué es eso? |
| 14 | Sí... Es una magia terrible que / solo usan los magos más / poderosos. — Tan terrible que puede destruir / un reino entero de un solo / golpe. |
| 15 | Bien. No hay más remedio que ir / a la isla Langer. |
| 16 | ¡Sí! |

## Escena de Shakuren (isla Langer)

| # | Castellano (12d) |
|---|------------------|
| 17 | ¿Cruzando este mar está la isla / Langer, verdad? |
| 18 | ¡Anímate! / No te vengas abajo. |
| 19 | ¡¡Así es!! |
| 20 | ¡Rumbo a la isla Langer! |
| 21 | Oye, Spanky. ¿No será ese cráter / del volcán el Cañón Hechizo...? |
| 22 | T-tal vez... Creo que sí... |
| 23 | No puede ser más obvio... |
| 24 | En fin, entremos por el cráter / e investiguemos. |
| 25 | Pero qué calor hace en esta / isla. Me mareo. |
| 26 | Vamos. Cuidado todos con la / lava. |
| 27 | ¡Alto ahí! |
| 28 | ¡Ah! ¡Apareció! ¡Eres Shakuren, / uno de los Cuatro Emperadores! |
| 29 | Oh, qué alegría. Sabes mi / nombre. Uju, ju. |
| 30 | ¡Eh, Al! ¿¡Por qué te / sonrojas!? |
| 31 | ¿Eh? ¿Qué? N-no es nada... |
| 32 | Ju, ju, qué mono. Hasta dan / ganas de no castigarte. — Pero lo siento: por aquí no os / dejo pasar. |
| 33 | ¡Tenemos que detener el Cañón / Hechizo! |
| 34 | Dentro de 160 días, el cráter se / cerrará y el hechizo entrará en / su fase final. — Entonces, nadie podrá entrar / ahí dentro. — La próxima vez que se abra será / para disparar. Así que, hasta / que se cierre, yo misma jugaré / contigo, pequeñajo. |
| 35 | S-sí... |
| 36 | ¡No te quedes alelado! ¿No le / contestas? Algo como «¡no soy un / pequeñajo!». |
| 37 | N-no soy un pequeñajo... |
| 38 | Ja, ja, ja, ¡qué mono! Me has / caído bien. — De momento, entretente con mi / querida mascota. / Ju, ju. ¡Chao! |

Notas:
- «Cuatro Emperadores» = los 4 generales de Galgundos (4天王), coherente con el reparto ya aprobado.
- «Cañón Hechizo» para 呪文砲 (Spell Cannon en el parche inglés).
- Los saltos de línea (/) respetan el máximo de 3 líneas por página del motor.

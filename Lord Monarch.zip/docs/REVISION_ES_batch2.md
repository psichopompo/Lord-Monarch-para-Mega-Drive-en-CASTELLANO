# Lote 2 de revisión — traducción nueva desde el JP (portero, pruebas y Geis)

Propuestas fieles al japonés. David: aprobar o corregir cada una.
Nombres ya fijados en lotes anteriores: Geis (imperio Blighty), Rubia, Martika, Lance, Heynee, Galgundos.
(Se omite el símbolo ♥ del JP por no existir en la fuente; se puede añadir glifo si se desea.)

### 0x0341FD
**JP:** お待ち下さい！
**ES propuesto:** ¡Esperad, por favor!

### 0x034216
**JP:** おれは、モナーク王国の王子アルフレッドだ。あやしいもんじゃないぞ。
**ES propuesto:** Soy Alfred, príncipe del reino de Monarch. ¡No soy nadie sospechoso!

### 0x03423A
**JP:** わかっております。/じつは、ルビア姫とお見合いされる方には、お城にいたるまでの道すがらで、腕試しをお願いしているのです。/１２０日後にお見合いの儀がありますので、それまでに、３つの腕試しをすべてクリアしてください。
**ES propuesto:** Lo sé. /-----/ Quien desee desposar a la princesa Rubia debe superar una prueba de habilidad en el camino al castillo. /-----/ La ceremonia será dentro de 120 días. Completad las tres pruebas antes de esa fecha.

### 0x0342AD
**JP:** なに！
**ES propuesto:** ¿¡Qué!?

### 0x0342B3
**JP:** すでに隣国のゲッシュー王子も腕試しに参加されています。/あなたも急いだ方が良いですよ。
**ES propuesto:** El príncipe Geis del reino vecino ya participa en la prueba. / Más os vale daros prisa.

### 0x0342E5
**JP:** アルフレッド様。/王子の証を立てたあなたなら、造作もないことでしょうぞ。
**ES propuesto:** Lord Alfred. / Para vos, que obtenisteis la prueba de príncipe, esto será coser y cantar.

### 0x03430E
**JP:** いやいや、我が国の腕試しを甘く見ない方がよろしいですぞ。/ここで道が３つに分かれておりますので、お好きな腕試しをえらんで、いかれるのがよいでしょう。
**ES propuesto:** No, no; mejor no subestiméis nuestras pruebas. /-----/ Aquí el camino se divide en tres. Elegid la prueba que prefiráis y seguid.

### 0x034393
**JP:** よーし、つぎいくぞ。
**ES propuesto:** Bien, ¡a por la siguiente!

### 0x0343B2
**JP:** 王子様、ここの腕試しは、もうすみましたですじゃ。
**ES propuesto:** Joven amo, esta prueba ya la superasteis.

### 0x0343CD
**JP:** ああ。そうだったな。/もどろうか・・・。
**ES propuesto:** Ah, es verdad. / Volvamos...

### 0x034409
**JP:** お。立て札があるぞ。/どれどれ・・・。
**ES propuesto:** Oh, hay un cartel. / A ver...

### 0x034420
**JP:** ようこそ、第一の腕試しはここよ。やっぱり、王様になる人はお金持ちのほうがいいわよね。/というわけで、ここでは一番先に５万Ｇためた人が勝ちよ。がんばってね！/うふふ♥　ルビアより
**ES propuesto:** Bienvenido a la primera prueba. Quien vaya a ser rey debe ser rico, ¿no crees? /-----/ Así que aquí gana quien reúna antes 50.000 G. ¡Suerte! /-----/ Ufufufu. De tu Rubia.

### 0x03448D
**JP:** うん、うん、がんばっちゃうよ！
**ES propuesto:** ¡Sí, sí, me esforzaré!

### 0x03449F
**JP:** ５万Ｇなど、すぐですじゃ。
**ES propuesto:** 50.000 G estarán listos enseguida.

### 0x0344C6
**JP:** なにごとも、用心、用心、ですじゃ。
**ES propuesto:** Ante todo, prudencia, prudencia.

### 0x0344ED
**JP:** さすが、アルフレッド王子ですじゃ。/まいりましょうぞ！
**ES propuesto:** Como era de esperar del príncipe Alfred. / ¡Vamos!

### 0x03452A
**JP:** さて、この腕試しに挑戦しますか？
**ES propuesto:** ¿Aceptas esta prueba?

### 0x03453D
**JP:** ああ、今すぐ、やってやるぜ！
**ES propuesto:** ¡Sí, ahora mismo!

### 0x03454E
**JP:** いや、ちょっとやめとこう
**ES propuesto:** No, mejor lo dejo.

### 0x03457B
**JP:** あれ？/なんだか、へんなこえが/聞こえるぞ・・・
**ES propuesto:** ¿Eh? / Se oye una voz extraña...

### 0x0345BA
**JP:** やあやあ、我こそは、ブライティー帝国の第１王子ゲッシューだ。/この僕に挑戦するとは、命しらずだねー。ま、ルビアちゃんのことはあきらめたまえ。
**ES propuesto:** Vaya, vaya. Soy Geis, primer príncipe del imperio Blighty. /-----/ Desafiarme a mí es no apreciar tu vida. Ríndete y olvida a Rubia.

### 0x03460A
**JP:** てやんでい、気持ち悪いやろうだな。よーし、勝負してやろうじゃんか。
**ES propuesto:** Bah, qué tipo tan repugnante. ¡Bien, te aceptaré el duelo!

### 0x034631
**JP:** ははは、まあ、せいぜいがんばりたまえ。
**ES propuesto:** Jajaja. Bien, esforzaos cuanto podáis.

### 0x034649
**JP:** むきー！！
**ES propuesto:** ¡¡Grrr!!

### 0x03465F
**JP:** 王子！落ち着くのですじゃ！/まずは、ここでの作戦が/第一ですじゃ。
**ES propuesto:** ¡Príncipe! ¡Calmaos! /-----/ Lo primero es la estrategia / en esta batalla.

### 0x034686
**JP:** わかってるってば。
**ES propuesto:** Sí, sí, ya lo sé.

### 0x03469A
**JP:** ここでの目的は、お金か。/めんどうだな。いっきに/攻めるだけでいいなら、/得意なんだけど。
**ES propuesto:** Así que el objetivo es el dinero. /-----/ Qué lata. Si bastara con / atacar de golpe, / eso se me da bien.

### 0x0346DB
**JP:** 中立都市は、ここと・・・
**ES propuesto:** Las ciudades neutrales están aquí y...

### 0x0346FB
**JP:** ここですじゃ。/あわせて２つですじゃ。
**ES propuesto:** ...aquí. / Dos en total.

### 0x03471F
**JP:** そして、このモンスターを、なんとかいたしませぬと、あとあとが、めんどうですじゃ。
**ES propuesto:** Y habrá que hacer algo con este monstruo, o dará problemas más adelante.

### 0x034757
**JP:** 王子、ここでは、都市の確保と宝箱が重要ですじゃ。/いつものように、攻めの一手だけでは、かないませぬぞ！
**ES propuesto:** Príncipe, aquí asegurar ciudades y cofres es esencial. /-----/ ¡Como siempre, solo atacar no bastará!

### 0x0347A1
**JP:** ほーっほっほっ！/キミー、お金ってのはね、/徳の高い者に、自然と集まるものなんだ。/すまないね、/アルフレッド君。
**ES propuesto:** ¡Jo, jo, jo! /-----/ Verás, Alfred: el dinero / acude solo a quienes son / de alta virtud. /-----/ Lo siento.

### 0x0347E3
**JP:** しゃらくせえ！/いくぜ！
**ES propuesto:** ¡Qué absurdo! / ¡Allá voy!

### 0x0347F3
**JP:** アルフレッド様！/５万Ｇ・・・/たまりましたぞ！
**ES propuesto:** ¡Lord Alfred! / ¡50.000 G... / reunidos!

### 0x034812
**JP:** あーっはっはっは！/どうだ！まいったか！
**ES propuesto:** ¡Ja, ja, ja, ja! / ¡Toma! ¿Te rindes?

### 0x03482B
**JP:** きーっ！くやしいっ！
**ES propuesto:** ¡Grr! ¡Qué rabia!

### 0x034838
**JP:** しかし、まあ、金のことなど、/しょせんはしもじもの話。/わたくしの高貴な徳がじゃまになってしまったのかな。/ははは・・・
**ES propuesto:** Aunque, en fin, el dinero / es al final cosa de plebeyos. /-----/ Quizá mi noble virtud resultó / ser un estorbo. / Jajaja...

### 0x0348CB
**JP:** 楽勝、楽勝！/しかし、爺。あのゲッシューってやつも、たいしたことないな。
**ES propuesto:** ¡Victoria fácil, victoria fácil! / Pero, viejo, ese Geis no era para tanto.

### 0x0348F4
**JP:** ゆだんはなりませぬぞ。/でも実は、爺もそう思っておりましたですじゃ。ふぉっふぉっ。
**ES propuesto:** No bajéis la guardia. / Pero, en verdad, este viejo pensaba igual. Jo, jo.

### 0x034920
**JP:** わーっはっはっは！/よーし、つぎいくぞ！
**ES propuesto:** ¡Ja, ja, ja, ja! / ¡Bien, a por la siguiente!

### 0x034937
**JP:** ・・・聞こえたぞ。聞こえたぞ。/あんなげれつなアルフレッドに/ルビアちゃんを渡すわけにはいかない。/次こそは本気だ。/覚悟するがいい。
**ES propuesto:** ...Lo he oído. Lo he oído. / No permitiré que Rubia caiga / en manos de un Alfred tan ruin. /-----/ Esta vez voy en serio. / Prepárate.

### 0x03499B
**JP:** よーし、これで、３つの腕試しを全部クリアしたぞ！/うひょー、ルビア姫に会える！
**ES propuesto:** ¡Bien, con esto supero las tres pruebas! / ¡Uju! ¡Veré a la princesa Rubia!

### 0x0349C7
**JP:** では、あの番兵のところへいって、城への道を開けてもらうのですじゃ。
**ES propuesto:** Vamos, pues, ante el guardia, para que nos abra el camino al castillo.

### 0x034A10
**JP:** お、お、おおおお。
**ES propuesto:** O, o, ooooh.

### 0x034A1C
**JP:** ん？/腕試しはぜんぶおわったよ。/ルビア姫に会わせておくれ。
**ES propuesto:** ¿Mm? / Ya terminé todas las pruebas. / Dejadme ver a la princesa Rubia.

### 0x034A3E
**JP:** お、お、おろ、おろ、おろ。
**ES propuesto:** O, o, oro, oro, oro.

### 0x034A4E
**JP:** どうしたのじゃ。落ちつきなされ。
**ES propuesto:** ¿Qué ocurre? Tranquilizaos.

### 0x034A62
**JP:** じ、実は、城にいらっしゃるルビア様が、手ごわい山賊の一軍に襲われまして・・。
**ES propuesto:** E-en verdad, la princesa Rubia, en el castillo, ha sido atacada por una temible banda de bandidos...

### 0x034A8D
**JP:** なにっ！？/ルビア姫は無事なのか？
**ES propuesto:** ¿¡Qué!? / ¿Está a salvo la princesa Rubia?

### 0x034AA1
**JP:** い、いえ。我が国にはさしたる軍隊もないので、ルビア様が殺されるのも時間の問題かと、おろおろしているのです。
**ES propuesto:** N-no lo sé. Nuestro reino no tiene ejército que valga, y me temo que es cuestión de tiempo que la princesa muera.

### 0x034ADD
**JP:** ばかっ！早く門を開けろ！/爺。急ぐぞ。
**ES propuesto:** ¡Idiota! ¡Abre la puerta de una vez! /-----/ Viejo, date prisa.

### 0x034AF5
**JP:** はい、ただいま。
**ES propuesto:** Sí, ahora mismo.

### 0x034B09
**JP:** ルビアちゃん、/このゲッシューが助けにいくから、安心してね。
**ES propuesto:** Rubia, querida: / este Geis va a salvarte, así que tranquilo.

### 0x034B2B
**JP:** わあっ！？おまえまだいたのか？/ややこしいから、ついてくるなっ。
**ES propuesto:** ¿¡Uau!? ¿¡Aún estabas ahí? / No me sigas, que estorbas.

### 0x034B4E
**JP:** うるさい、ルビアちゃんを守れるのは、このゲッシュー様だけだ。/さらば！
**ES propuesto:** ¡Silencio! Solo yo, el gran Geis, puedo proteger a Rubia. / ¡Adiós!

### 0x034B7D
**JP:** あ、まて！/ゲッシューなんかに、てがらをよこどりされてたまるか！
**ES propuesto:** ¡Eh, espera! / ¡No dejaré que Geis me robe la gloria!

### 0x034BCB
**JP:** お。立て札だ。/どれどれ・・・。
**ES propuesto:** Oh, un cartel. / A ver...

### 0x034BDF
**JP:** ようこそ、第２の腕試しはここよ。/ここの森には、マルティカ国きっての錬金術師ジョゼッぺマイヤーとその助手たちが幽閉されているの。/かわいそうに、彼の持つ強大な力が、山賊を引きつけてしまったのね。/私たちのためにも、彼らを助けてあげてちょうだい。/この腕試しは、いちばん多く助けた人が勝ちね♥　ルビアより
**ES propuesto:** Bienvenido a la segunda prueba. /-----/ En este bosque están recluidos el mejor alquimista de Martika, Jozeppemaier, y sus asistentes. /-----/ Qué pena: su enorme poder atrajo a los bandidos. /-----/ Por nosotros, sálvalos, te lo ruego. /-----/ Gana quien más personas salve. De tu Rubia.

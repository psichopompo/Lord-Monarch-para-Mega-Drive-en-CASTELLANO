# Lote 1 de revisión — traducción nueva desde el JP (castillo, fin del tutorial y boda)

Propuestas fieles al japonés. David: aprobar o corregir cada una.

### 0x033728
**JP:** ふぉっふぉふぉ。さすがのアルフレッド様も今度は、苦戦したとみえる。
**ES propuesto:** Jo, jo, jo. Parece que hasta nuestro Lord Alfred pasó apuros esta vez.

### 0x03374E
**JP:** へっ！ / 爺の相手をするのに骨がおれるだけさ。
**ES propuesto:** ¡Hmp! Solo cansa tener que lidiar contigo, viejo.

### 0x033769
**JP:** きーっ！口の減らないお子ですじゃ。
**ES propuesto:** ¡Grrr! Menuda labia tenéis, joven amo.

### 0x033799
**JP:** アルフレッド様、この土地にも２つの山賊がおりますじゃ。 / 用心、用心。
**ES propuesto:** Joven amo, en estas tierras también hay dos bandas de bandidos. Cuidado, cuidado.

### 0x0337C2
**JP:** なーに、ザコが、たばになっても、 / しょせんは、ザコ。 / これまた、攻めの一手だな。
**ES propuesto:** Bah, aunque los debiluchos se junten en manada, siguen siendo debiluchos. Atacar es lo único que hace falta.

### 0x0337EF
**JP:** 王子！ / まじめにやってくだされ！ /  / ----- / この戦いは、王子が王子として認められるための、だいじな戦いなのですぞ。
**ES propuesto:** ¡Joven amo! ¡Hágalo en serio! Esta batalla es importante para que lo reconozcan como príncipe.

### 0x033840
**JP:** 王子、お気をつけください。
**ES propuesto:** Joven amo, tenga cuidado.

### 0x033850
**JP:** なんのことさ？
**ES propuesto:** ¿Qué quieres decir?

### 0x03385A
**JP:** ここにあるどうくつのことですじゃ。 / ----- / 
**ES propuesto:** Me refiero a la cueva que hay aquí.

### 0x03388A
**JP:** このどうくつからは、やっかいなモンスターが、出てくるのですじゃ。 / ----- / 
**ES propuesto:** De esta cueva salen monstruos muy problemáticos.

### 0x0338B8
**JP:** ほおっておくと、モンスターが、どんどん強くなってしまいますぞ。
**ES propuesto:** Si los deja en paz, los monstruos se volverán cada vez más fuertes.

### 0x0338DA
**JP:** ふ~ん。じゃあ、どうくつを、封印しないといけないな。
**ES propuesto:** Ya veo. Entonces habrá que sellar la cueva.

### 0x0338F7
**JP:** そうですとも！ / 兵たちに、早めに命令するのですじゃ！！ / ----- / 
**ES propuesto:** ¡Así es! ¡Dé la orden a los soldados cuanto antes!

### 0x033921
**JP:** そして・・・、よくごらんくださいまし。ここでも、２つの敵軍がおるのですじゃ。 / ----- / いくつもの敵と戦うには、まず、弱い方の敵を先に滅ぼすのがよろしいですじゃ。 / ----- / 
**ES propuesto:** Y... fíjese bien. Aquí también hay dos ejércitos enemigos. / ----- / Para luchar contra varios enemigos, conviene destruir primero al más débil.

### 0x03398C
**JP:** こいつと・・・。 / ----- / 
**ES propuesto:** Con este...

### 0x0339A3
**JP:** こいつか。 / ----- / う~ん、 / どっちも弱そうだから、 / まとめてやっつけよう！ / 
**ES propuesto:** O con este. Mmm, los dos parecen flojos, ¡así que los venceré a la vez!

### 0x0339CA
**JP:** とほほ、爺は寿命がちぢまる思いですじゃ。
**ES propuesto:** Ay ay ay... este viejo siente que se le acorta la vida.

### 0x0339E4
**JP:** やっつけたぜ！ / かんたん、かんたん。
**ES propuesto:** ¡Los vencí! Fácil, fácil.

### 0x0339FB
**JP:** ふぉっふぉっふぉっ。
**ES propuesto:** Jo, jo, jo.

### 0x033A27
**JP:** ど～～だい。 / なかなか、うまくいったろう？
**ES propuesto:** Y bien. ¿No lo hice de maravilla?

### 0x033A3F
**JP:** ふぉっふぉふぉっ。 / あまい、あまいですじゃ。 / ----- / まだまだ、王子の証をわたすわけにはいきませんですじゃ。
**ES propuesto:** Jo, jo, jo. Ingenuo, ingenuo. / ----- / Aún no puedo entregarle la prueba de príncipe.

### 0x033A8F
**JP:** 王子様、ここは今までの戦いとはわけが違いますじゃ。まさに、本当の男のいくさですじゃ。覚悟するですじゃ。
**ES propuesto:** Joven amo, esto es diferente a las batallas de hasta ahora. Es una auténtica guerra de hombres. Prepárese.

### 0x033ACA
**JP:** やっと、本気であばれられそうだな。 / 山賊ども、まってろよ。
**ES propuesto:** Por fin podré luchar en serio. Bandidos, esperadme.

### 0x033AEB
**JP:** このいくさに勝てたら、爺も安心して王様に報告できますじゃ。
**ES propuesto:** Si vence en esta batalla, este viejo podrá informar al Rey tranquilo.

### 0x033B26
**JP:** 王子さま、いくさの墓本は / お金ですじゃ。 / そのために・・・ / ----- / 
**ES propuesto:** Joven amo, la base de la guerra es el dinero. Por eso...

### 0x033B62
**JP:** 王様が中立都市に入れば、 / その都市を自分のものにできるのですじゃ。 / ----- / 自分のものになった都市は、みつぎものを送ってくれるので、もうかりますぞ！
**ES propuesto:** Si entra en una ciudad neutral, la ciudad pasará a ser suya. / ----- / Las ciudades suyas envían tributos, ¡así que será rentable!

### 0x033BB6
**JP:** このおれが、そこに入れば、いいのか。 / なるほど。
**ES propuesto:** O sea, que solo tengo que entrar ahí. Ya veo.

### 0x033BD1
**JP:** さて、作戦のほうは、どうするのですじゃ？
**ES propuesto:** Bien. ¿Qué haremos con la estrategia?

### 0x033BE8
**JP:** まずは、どこから攻めるかだなあ・・・。 / ----- / 
**ES propuesto:** Primero, por dónde atacar...

### 0x033C15
**JP:** こいつから攻めようか？ / ----- / 
**ES propuesto:** ¿Ataco a este?

### 0x033C2C
**JP:** いやいや、まてよ・・・ / ----- / 
**ES propuesto:** No, no, espera...

### 0x033C47
**JP:** こいつかな？
**ES propuesto:** ¿A este?

### 0x033C50
**JP:** （王子も少しは策をめぐらすようにおなりじゃ。 / たのもしいことじゃて）
**ES propuesto:** (El príncipe ya empieza a trazar estrategias. Qué alentador.)

### 0x033C79
**JP:** よし、いくぜ。爺！ / おれの戦いぶりをとくと / 見ておけよ。
**ES propuesto:** Bien, ¡allá voy! ¡Viejo! Observa bien cómo lucho.

### 0x033CBB
**JP:** ふーっ！ぎりぎりセーフ！
**ES propuesto:** ¡Fiu! ¡Por los pelos!

### 0x033CCB
**JP:** ふぉっふぉふぉっ。爺も時間切れになるかと、ハラハラしましたぞ。
**ES propuesto:** Jo, jo, jo. Este viejo estuvo nervioso pensando que se acababa el tiempo.

### 0x033CF1
**JP:** 楽勝だぜ。 / どうだ、どうだ！
**ES propuesto:** Victoria fácil. ¡Y bien, y bien!

### 0x033D05
**JP:** ふぉっふぉっふぉっ。 / 見事ですじゃ。王様の若いころ以上の戦いぶりですじゃ。
**ES propuesto:** Jo, jo, jo. Espléndido. Lucha mejor que el Rey en su juventud.

### 0x033D3E
**JP:** よし、これでオヤジにでかいかおができるな！ / ゆかい、ゆかい！
**ES propuesto:** Bien, ¡ahora podré presumir ante el viejo! ¡Qué divertido!

### 0x033D5F
**JP:** ううう。あのやんちゃぼうずだったアルフレッド様が、ここまでりっぱに成長されたとは・・。
**ES propuesto:** Uuh... Aquel travieso de Lord Alfred ha crecido hasta convertirse en alguien admirable...

### 0x033D8F
**JP:** 爺は・・・爺はうれしいですじゃ！
**ES propuesto:** Este viejo... ¡este viejo está feliz!

### 0x033DA2
**JP:** 爺！城に戻ろう。
**ES propuesto:** ¡Viejo! Volvamos al castillo.

### 0x033DAE
**JP:** そうですとも。 / きっと、王様も、心配されておいでですじゃ。
**ES propuesto:** Así es. Seguro que el Rey está preocupado.

### 0x033E06
**JP:** 王様、アルフレッド様は伝承どおり４つの試練をクリアして、見事に、王子としての証を、立てられましたぞ。 / ----- / そのあっぱれな戦いぶりは、この爺が、シカと見とどけてございますじゃ。
**ES propuesto:** Majestad, Lord Alfred superó las cuatro pruebas tal como dice la tradición y obtuvo la prueba de príncipe. / ----- / Este viejo contempló su admirable batalla.

### 0x033E62
**JP:** そうか。アルフレッドよ、ご苦労じゃった。この試練は王への道の入り口だ。 / これからも精進するのだぞ。
**ES propuesto:** Ya veo. Alfred, bien hecho. Esta prueba es la entrada al camino del Rey. Sigue esforzándote.

### 0x033E9A
**JP:** へへへっ！ / これで、おれも一人前ってことだな。 / ----- / これからは、思いっきり暴れさせてもらうぜ。おやじ！
**ES propuesto:** ¡Jejeje! Con esto ya soy mayor de edad. / ----- / De ahora en adelante me desataré a gusto. ¡Viejo!

### 0x033ECF
**JP:** うぬ。ほんとうなら、おまえのようにうかれた者には、ワシのヘッドロックをくらわせるところだが・・・
**ES propuesto:** Hmp. Lo normal sería darte uno de mis coscorrones por payaso...

### 0x033F03
**JP:** まあ、よい。 / 今日はめでたい日じゃ。 / わっはっはっはっは。
**ES propuesto:** Bah, está bien. Hoy es un día de celebración. ¡Ja, ja, ja, ja, ja!

### 0x033F23
**JP:** 王様、爺はうれしゅうございます。 / 肩の荷がおりた思いですじゃ。これで、爺は安心してあの世へいけますぞ。
**ES propuesto:** Majestad, este viejo está feliz. Siento que me quito un peso de encima. Así podré irme al otro mundo tranquilo.

### 0x033F5D
**JP:** わっはっは！ / ばかをいっちゃいかん。この暴れんぼうには、まだまだお目つけ役が必要だ。 / ----- / こいつの面倒を、見てやってくれ。
**ES propuesto:** ¡Ja, ja, ja! No digas tonterías. Este alborotador aún necesita un vigilante. / ----- / Ocupaos de él.

### 0x033FA1
**JP:** ひーっ。王様、ごかんべんを。 / この老いぼれには、荷が重いですじゃ。
**ES propuesto:** Iiih. Majestad, apiadaos de mí. Para este viejo decrépito es demasiada carga.

### 0x033FC8
**JP:** くそー。みんな好きかっていいやがって。
**ES propuesto:** Maldita sea. Todos hacen lo que les da la gana.

### 0x033FDF
**JP:** よいではないか。 / よし、宴のしたくをいたせ。 / こよいは、はめをはずすぞ。 / ----- / わははははー―――－っ！
**ES propuesto:** ¿No está bien? / Bien, preparad el banquete. Esta noche nos desmadraremos. / ----- / ¡Juajuajuajuajua!

### 0x034021
**JP:** 王子様、王子様、 / ふえっへっへっ・・・
**ES propuesto:** Joven amo, joven amo... jejeje...

### 0x034037
**JP:** 何だ、爺。 / 気持ち悪いなあ。
**ES propuesto:** ¿Qué pasa, viejo? Me das grima.

### 0x03404A
**JP:** 王子様も見事、王子の証を立てたわけですから、もうこれは、一人前のおとこ。 / ふえっへっへっ・・・・。
**ES propuesto:** El joven amo obtuvo la prueba de príncipe, así que ya es un hombre hecho y derecho. Jejeje...

### 0x03407F
**JP:** あー、もう！ / まだるっこしいな！ / 何なんだよ！
**ES propuesto:** ¡Aaah, basta! ¡Qué pesado! ¡¿Qué quieres?!

### 0x03409A
**JP:** 実は、隣のマルティカ国より、使者が / やってきまして・・・ / ----- / それが、なんとお見合いの申し込みなのですじゃ！
**ES propuesto:** En verdad, llegó un mensajero del reino vecino de Martika... / ----- / ¡Y trae una propuesta de matrimonio!

### 0x0340D5
**JP:** げげっ。あの国の王様なら、見たことあるけど、ガリガリのミイラみたいなおじさんだったぜ。あれのむすめかぁ・・・。ちょっとなあ、きついなあ。
**ES propuesto:** Ugh. Vi al Rey de ese país: era un viejo flaco como una momia. Si su hija se le parece... qué pena.

### 0x03411D
**JP:** めっそうもございません。 / まあ、この絵をご覧くださいまし。 / ----- / この爺までも、年がいもなく、 / ときめきましたぞ。
**ES propuesto:** Ni hablar. Bien, mire este retrato. Hasta el corazón de este viejo se emocionó, olvidando su edad.

### 0x034159
**JP:** じゃ、じゃあ、とりあえず、 / 見るだけだぞ。
**ES propuesto:** B-bueno, de momento, solo miraré.

### 0x034171
**JP:** さ、さ、これでございます。
**ES propuesto:** A-aquí lo tiene.

### 0x034181
**JP:** どれどれ・[03]・[03]・[03]・[03]
**ES propuesto:** A ver・[03]・[03]・[03]・[03]

### 0x034190
**JP:** ・・・！。 / ----- / 
**ES propuesto:** ...！

### 0x0341A1
**JP:** うひょ~、かわいい~！！
**ES propuesto:** ¡Uau, qué mona...!

### 0x0341B0
**JP:** 爺、なにをぐずぐずしている。 / さあ、マルティカ国へ向かうぞ！ / 急げ！
**ES propuesto:** Viejo, deja de refunfuñar. ¡Rumbo a Martika! ¡Date prisa!

### 0x0341D6
**JP:** ふえっ[03]へっ[03]へっ[03]・・・・。
**ES propuesto:** Je[03]je[03]je[03]...

